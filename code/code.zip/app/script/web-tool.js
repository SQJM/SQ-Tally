/**
 * @name web-tool
 * @description 网页工具
 * @version 1.0.0
 * @author Wang Jia Ming
 * @createDate 2025-3-20
 * @license AGPL-3.0
 *
 * https://opensource.org/licenses/AGPL-3.0
 */
const WebTool = ( function () {
    'use strict';

    // 代码错误
    const Code_Error = {
        // 参数不匹配
        ParameterMismatch : ( ...arg ) => {
            return new Error( `CODE Error : <${ arg }> Parameter mismatch` );
        },
        // 不存在的项
        NotExistItem : ( ...arg ) => {
            return new Error( `CODE Error : <${ arg }> Not exist item` );
        }
    }

    /**
     * 定义常见的DOM事件类型
     */
    const Event = {
        // 鼠标点击事件
        click : "click",
        // 右键菜单事件
        contextmenu : "contextmenu",
        // 双击事件
        dblclick : "dblclick",
        // 拖拽放下事件
        drop : "drop",
        // 拖拽开始事件
        dragstart : "dragstart",
        // 拖拽中事件
        drag : "drag",
        // 拖拽中在目标上方移动事件
        dragover : "dragover",
        // 拖拽结束事件
        dragend : "dragend",
        // 拖拽进入目标事件
        dragenter : "dragenter",
        // 拖拽离开目标事件
        dragleave : "dragleave",
        // 鼠标按下事件
        mousedown : "mousedown",
        // 触摸开始
        touchstart : "touchstart",
        // 触摸移动
        touchmove : "touchmove",
        // 触摸结束
        touchend : "touchend",
        // 输入事件
        input : "input",
        // 表单变化事件
        change : "change",
        // 提交事件
        submit : "submit",
        // 鼠标移入事件
        mouseover : "mouseover",
        // 鼠标移动事件
        mousemove : "mousemove",
        // 鼠标移出事件
        mouseout : "mouseout",
        // 键盘按下事件
        keydown : "keydown",
        // 键盘松开事件
        keyup : "keyup",
        // 键盘释放事件
        keypress : "keypress",
        // 元素获得焦点事件
        focus : "focus",
        // 元素失去焦点事件
        blur : "blur"
    };

    const VarType = {
        string : "string",
        number : "number",
        float : "float",
        boolean : "boolean",
        null : "null",
        undefined : "undefined",
        symbol : "symbol",
        bigInt : "bigInt",
        object : "object",
        array : "array",
        set : "set",
        map : "map",
        class : "class",
        function : "function"
    };

    /**
     * 用于类型转换或获取的工具类
     */
    class TypeCast {

        /**
         * 将字符串自动转换为相应的数据类型
         * @param {string} str - 要转换的字符串
         * @returns {any} - 转换后的数据类型
         */
        static strAutoType( str ) {
            str = str.trim();
            if ( str === "true" || str === "false" ) return TypeCast.strToBool( str );
            if ( str === "undefined" || str === "void 0" ) return undefined;
            if ( str === "null" ) return null;
            const number = Number( str );
            if ( !isNaN( number ) ) return number;
            try {
                const parsed = JSON.parse( str );
                if ( typeof parsed === 'object' && parsed !== null ) return parsed;
            } catch ( e ) { }
        }

        /**
         * 字符串转 innerHTML
         * @param {String} str - 要转换的字符串
         * @returns {innerHTML} - 解析后的 innerHTML
         */
        static strToinnerHTML( str ) {
            const div = document.createElement( "div" );
            div.innerHTML = str;
            return div.innerHTML;
        }

        /**
         * 将字符串转换为布尔值,
         * @param {string} str - 要转换的字符串,只能是 "true"`"false"`"1" 或 "0"
         * @returns {boolean|undefined} 如果字符串为 "true" 或 "1",则返回 true;如果字符串为 "false" 或 "0",则返回 false;否则返回 null
         */
        static strToBool( str ) {
            if ( str === "true" || str === "1" ) {
                return true;
            } else if ( str === "false" || str === "0" ) {
                return false;
            }
            return null;
        }

        /**
         * 将给定的值转换为布尔值
         *
         * 如果传入的值是真值,则返回true;否则返回false
         * 真值包括:任何非假值的值,如非空字符串,非零数字,非null对象等
         * 假值包括:false,0,"",null,undefined,NaN
         *
         * @param {any} value - 需要被转换为布尔值的任意值
         * @returns {boolean} - 转换后的布尔值
         */
        static toBoolean( value ) {
            if ( value ) return true;
            return false;
        }

        /**
         * 获取第一个数组中包含但第二个数组中不包含的额外项
         * @param {Array} arr1 - 第一个数组
         * @param {Array} arr2 - 第二个数组
         * @returns {Array|null} 包含额外项的数组,如果不存在额外项则返回 null
         */
        static findExtraItemsInFirstArray( arr1, arr2 ) {
            const set = new Set( arr2 );

            const arr = [];
            for ( let item of arr1 ) {
                if ( !set.has( item ) ) arr.push( item );
            }

            if ( arr.length === 0 ) return null;
            return arr;
        }
    }

    /**
     * 获取指定的父级返回 true 或者直到 MainWindow 结束
     * @param {Element} element - 要获取指定父级的元素
     * @param {function} fn - 验证功能 如果当前的父级是与预期一样的则需要返回 true
     */
    function getAppointParent( element, fn = () => { } ) {
        if ( element === document.body ) {
            return false;
        }
        if ( !fn( element ) && element.parentNode )
            return getAppointParent( element.parentNode, fn ) || false;
        else
            return element;
    }

    /**
     * 检查给定类及其原型链上是否存在指定方法名
     * @param {function} klass 给定的类
     * @param {string} functionName 指定的方法名
     * @returns {boolean} 是否存在指定方法名
     */
    function checkClassHasFunction( klass, functionName ) {
        // 获取类原型对象
        const proto = klass.prototype;
        // 检查类原型对象和类本身是否具有该方法
        if (
            proto.hasOwnProperty( functionName ) ||
            klass.hasOwnProperty( functionName )
        ) {
            return true;
        }
        // 遍历原型链,查找是否具有该方法
        let currentProto = proto;
        while ( currentProto !== null ) {
            if ( currentProto.hasOwnProperty( functionName ) ) {
                return true;
            }
            currentProto = Object.getPrototypeOf( currentProto );
        }
        return false;
    }

    /**
     * 函数用于获取当前时间的格式化字符串
     *
     * @return {String} 当前时间的格式化字符串,格式为 "YYYY-MM-DD HH:mm:ss"
     * @param time
     * @param template
     */
    function getNowFormatDate( time = Date.now(), template = "YYYY-MM-DD HH:mm:ss" ) {
        const date = new Date( time );
        const year = date.getFullYear();
        const month = ( "0" + ( date.getMonth() + 1 ) ).slice( -2 );
        const day = ( "0" + date.getDate() ).slice( -2 );
        const hour = ( "0" + date.getHours() ).slice( -2 );
        const minute = ( "0" + date.getMinutes() ).slice( -2 );
        const second = ( "0" + date.getSeconds() ).slice( -2 );

        return template
        .replace( "YYYY", year )
        .replace( "MM", month )
        .replace( "DD", day )
        .replace( "HH", hour )
        .replace( "mm", minute )
        .replace( "ss", second );
    }

    /**
     * 生成唯一ID
     * @returns {string} 生成的唯一ID
     */
    function generateUniqueId( length = 18 ) {
        const letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
        const numbers = '0123456789';
        let t1 = '';
        let t2 = '';
        for ( let i = 0; i < 9; i++ ) {
            t1 += letters.charAt( Math.floor( Math.random() * letters.length ) );
            t2 += numbers.charAt( Math.floor( Math.random() * numbers.length ) );
        }
        return `ID_${ t1 }_${ t2 }`.substring( 0, length );
    }

    /**
     * 获取设备方向函数
     * @returns {number} 设备方向指示 0:竖屏 1:横屏 -1:无法确定
     */
    function getDeviceOrientation() {
        if ( window.matchMedia( "(orientation: portrait)" ).matches ) {
            return 0;
        } else if ( window.matchMedia( "(orientation: landscape)" ).matches ) {
            return 1;
        } else {
            return -1;
        }
    }

    /**
     * 更新网站 Favicon 的链接
     * @param {string} newIconUrl 新的 Favicon 的 URL
     */
    function updateFavicon( newIconUrl ) {
        // 获取 link 元素
        let linkElement =
            document.querySelector( 'link[rel="shortcut icon"]' ) ||
            document.querySelector( 'link[rel="icon"]' );

        // 创建一个新 link 元素
        let newLinkElement = document.createElement( "link" );
        newLinkElement.rel = "shortcut icon";
        newLinkElement.type = "image/x-icon";
        newLinkElement.href = newIconUrl;

        // 替换或添加 link 元素
        if ( linkElement ) {
            linkElement.parentNode.replaceChild( newLinkElement, linkElement );
        } else {
            document.head.appendChild( newLinkElement );
        }
    }

    /**
     * 获取浏览器信息
     * @returns {Object} 返回一个包含浏览器信息的对象
     */
    function getBrowserInfo() {
        return {
            userAgent : navigator.userAgent,
            platform : navigator.platform,
            language : navigator.language,
            isOnline : navigator.onLine,
            isCookieEnabled : navigator.cookieEnabled,
            colorScheme : window.matchMedia && window.matchMedia( "(prefers-color-scheme: dark)" ).matches ? "Dark" : "Light"
        };
    }

    /**
     * 返回柔和亮的随机颜色
     * @returns {string} 返回一个颜色字符串
     */
    function getRandomColor( type = 'rgba' ) {
        let hue = Math.floor( Math.random() * 360 );  // 随机生成色相值 (0 - 359)
        hue = hue - Math.floor( Math.random() * 99 ) + Math.floor( Math.random() * 66 );
        let saturation = Math.floor( Math.random() * 30 + 70 );  // 随机生成饱和度值 (70 - 100)
        let lightness = Math.floor( Math.random() * 10 + 60 );  // 随机生成亮度值 (60 - 70)

        let color;

        if ( type === 'rgb' ) {
            color = `rgb(${ hue }, ${ saturation }, ${ lightness })`;
        } else if ( type === 'rgba' ) {
            let alpha = ( Math.random() * ( 1 - 0.2 ) + 0.2 ).toFixed( 2 );  // 随机生成透明度值 (0.2 - 1)
            color = `rgba(${ hue }, ${ saturation }, ${ lightness }, ${ alpha })`;
        } else if ( type === 'hsl' ) {
            color = `hsl(${ hue }$, ${ saturation }%, ${ lightness }%)`;
        } else {
            throw new Error( 'Invalid color type' );
        }

        return color;
    }

    /**
     * easyStorageTool - Web Storage 工具函数
     *
     * 这个工具函数用于简化对 Web StoragelocalStorage 或 sessionStorage的操作
     * @returns {Object} - 一个包含 setItem`getItem`removeItem 和 clear 方法的对象
     */
    function easyStorageTool() {
        // 设置键值对
        function setItem( key, value ) {
            try {
                localStorage.setItem( key, JSON.stringify( value ) );
                return true;
            } catch ( error ) {
                console.error( '存储错误:', error );
                return false;
            }
        }

        // 获取指定键的值
        function getItem( key ) {
            try {
                const value = localStorage.getItem( key );
                return value ? JSON.parse( value ) : null;
            } catch ( error ) {
                console.error( '读取错误:', error );
                return null;
            }
        }

        // 删除指定键值对
        function removeItem( key ) {
            try {
                localStorage.removeItem( key );
                return true;
            } catch ( error ) {
                console.error( '删除错误:', error );
                return false;
            }
        }

        // 清空存储
        function clear() {
            try {
                localStorage.clear();
                return true;
            } catch ( error ) {
                console.error( '清空错误:', error );
                return false;
            }
        }

        // 返回公共方法
        return {
            setItem,
            getItem,
            removeItem,
            clear
        };
    }

    /**
     * Cookie 工具函数,用于设置`获取和删除 Cookie
     * @param {string} cookieName - Cookie 名称前缀
     * @returns {object} - 包含 set`get 和 Delete 方法的对象
     */
    function cookieUtil( cookieName ) {
        return {
            set : function ( name, value, days, path = "/" ) {
                var expires = "";
                if ( days ) {
                    var date = new Date();
                    date.setTime( date.getTime() + days * 24 * 60 * 60 * 1000 );
                    expires = "; expires=" + date.toUTCString();
                }
                document.cookie = cookieName + "_" + name + "=" + value + expires + "; path=" + path;
            },

            get : function ( name ) {
                var fullNameEQ = cookieName + "_" + name + "=";
                var ca = document.cookie.split( ";" );

                for ( var i = 0; i < ca.length; i++ ) {
                    var c = ca[ i ];
                    while ( c.charAt( 0 ) === " " ) c = c.substring( 1, c.length );
                    if ( c.indexOf( fullNameEQ ) === 0 )
                        return c.substring( fullNameEQ.length, c.length );
                }
                return null;
            },

            Delete : function ( name, path = "/" ) {
                this.set( name, "", -1, path );
            }
        };
    }

    /**
     * AudioPlayer 音频播放器对象
     */
    class AudioPlayer {
        constructor() {
            this.audio = new Audio();
            this.audioFileList = new Map();
            this.progressCallback = null;
            this.currentAudioName = null;
            this.handleProgressUpdate = this.handleProgressUpdate.bind( this );
            this.audio.addEventListener( "timeupdate", this.handleProgressUpdate );
        }

        addAudioFile( src ) {
            this.audioFileList.set(
                src.split( "/" ).pop().split( "." ).slice( 0, -1 ).join( "." ),
                src
            );
        }

        removeAudioFile( audioName ) {
            this.audioFileList.delete( audioName );
        }

        loadAudio( audioName ) {
            this.currentAudioName = audioName;
            const audioInfo = this.audioFileList.get( audioName );
            if ( audioInfo ) {
                this.audio.src = audioInfo;
                this.audio.load();
            } else {
                console.log( "not audio" );
            }
        }

        play() {
            this.audio.play();
        }

        player( audioName ) {
            this.loadAudio( audioName );
            this.audio.play();
        }

        pause() {
            this.audio.pause();
        }

        setProgressCallback( callback ) {
            this.progressCallback = callback;
        }

        handleProgressUpdate() {
            if ( this.progressCallback ) {
                const currentTime = this.audio.currentTime;
                const duration = this.audio.duration;
                this.progressCallback( currentTime, duration );
            }
        }
    }

    /**
     * 格式化日期字符串为"YYYY-MM-DD"格式
     * @param {string} dateString - 需要格式化的日期字符串,格式为"YYYY-M-D"
     * @returns {string} 格式化后的日期字符串,格式为"YYYY-MM-DD"
     */
    function formatDateString( dateString ) {
        let parts = dateString.split( "-" );
        let year = parts[ 0 ];
        let month = ( "0" + parts[ 1 ] ).slice( -2 ); // 补零
        let day = ( "0" + parts[ 2 ] ).slice( -2 ); // 补零

        return year + "-" + month + "-" + day;
    }

    /**
     * 函数防抖
     * @param {Function} fn - 要执行的函数
     * @param {number} delay - 延迟时间
     * @returns {Function} - 包装后的防抖函数
     */
    function debounce( fn, delay ) {
        let timerId;
        return function ( ...args ) {
            clearTimeout( timerId );
            timerId = setTimeout( () => {
                fn.apply( this, args );
            }, delay );
        };
    }

    /**
     * 递归设置元素及其子元素的原型链
     * @param {HTMLElement} element - 要设置原型链的根元素
     * @param {Object} prototype - 要设置的原型对象
     */
    function setElementInAllPrototypeRecursive( element, prototype ) {
        // 设置当前元素的原型
        Object.setPrototypeOf( element, prototype );

        // 遍历当前元素的子元素
        const childNodes = element.childNodes;
        for ( let i = 0; i < childNodes.length; i++ ) {
            const child = childNodes[ i ];

            // 递归调用,将子元素的原型也设置为相同的原型
            if ( child.nodeType === Node.ELEMENT_NODE ) {
                setElementInAllPrototypeRecursive( child, prototype );
            }
        }
    }

    /**
     * 触发指定元素上的事件
     * @param {Element} element 要触发事件的元素
     * @param {string} eventName 要触发的事件名称
     * @param {number} [btn=0] 鼠标按钮值,默认为 0
     */
    function eventTrigger( element, eventName, btn = 0 ) {
        if ( element ) {
            element.dispatchEvent( new MouseEvent( eventName, {
                bubbles : true,     // 事件是否冒泡
                cancelable : true,  // 是否可以被取消
                view : window,      // 与事件相关的抽象视图
                button : btn        // 按下哪个鼠标键
            } ) );
            return true;
        }
        return false;
    }

    /**
     * @class VitalEvent
     * 用于监听一个元素是否被从 MainWindow 中移除
     * 如果元素被移除,则自动调用结束函数
     */
    class VitalEvent {
        constructor( element = document.body, init = () => { }, end = () => { } ) {
            this._intervalId = null;
            this.end = end;

            init();

            this._intervalId = setInterval( () => {
                if ( !MainWindow.contains( element ) ) this.dispose();
            }, 100 );
        }

        dispose() {
            if ( this._intervalId ) {
                clearInterval( this._intervalId );
                this._intervalId = null;
            }
            this.end();
        }
    }

    /**
     * 修正控件内部元素的位置,确保不超出控件的边界范围
     *
     * @param {number} x - 弹出框的 X 轴坐标
     * @param {number} y - 弹出框的 Y 轴坐标
     * @param {HTMLElement} element - 元素
     * @param {HTMLElement} [Control=MainWindow] - 元素所在的父级控件,默认为 MainWindow
     * @returns {number[]} 返回修正后的元素坐标 [y, x]
     */
    function RangeCorrection( [ x = null, y = null ], element, Control = MainWindow ) {
        const {
            width : ControlW,
            height : ControlH
        } = Control.getClientRects();
        const {
            width : elementW,
            height : elementH
        } = element.getClientRects();
        let resultX = null, resultY = null;

        // 修正 X 轴坐标
        if ( x && x + elementW >= ControlW ) {
            resultX = ControlW - elementW;
        }

        // 修正 Y 轴坐标
        if ( y && y + elementH >= ControlH ) {
            resultY = ControlH - elementH;
        }

        return {
            x : resultX || 0,
            y : resultY || 0
        };
    }

    /**
     * 全天候日期变更检测器 跨时区/跨月/跨年安全
     *
     * 智能检测自然日变化,支持动态频率调整和页面状态感知
     *
     * @class DayChangeDetector
     * @example
     * // 基本使用
     * const detector = new DayChangeDetector(({ previousDay, currentDay }) => {
     *   console.log(`日期变更：${previousDay} → ${currentDay}`);
     * });
     *
     * // 带配置项的使用
     * const detector = new DayChangeDetector(callback, {
     *   timeZone: 'Asia/Shanghai',
     *   immediateCheck: true
     * });
     */
    class DayChangeDetector {
        constructor( callback, options = {} ) {
            this.lastCheckedDay = this.getCurrentDayIdentifier( options.timeZone );
            this.callback = callback;
            this.options = {
                timeZone : Intl.DateTimeFormat().resolvedOptions().timeZone,
                immediateCheck : true,
                ...options
            };
            this.initListener();
        }

        getCurrentDayIdentifier( timeZone ) {
            return new Date().toLocaleDateString( 'en-CA', timeZone ? { timeZone } : undefined );
        }

        initListener() {
            if ( this.options.immediateCheck ) this.check();
            this.interval = setInterval( () => this.check(), this.calculateOptimalInterval() );
        }

        calculateOptimalInterval() {
            try {
                const now = new Date();
                const timeZone = this.options.timeZone;

                // 计算目标时区当前时间组件
                const formatter = new Intl.DateTimeFormat( 'en-US', {
                    timeZone,
                    hour : 'numeric',
                    minute : 'numeric',
                    second : 'numeric',
                    hour12 : false
                } );

                const parts = formatter.formatToParts( now );
                const getPart = type => parseInt( parts.find( p => p.type === type )?.value || 0 );

                const hour = getPart( 'hour' ),
                    minute = getPart( 'minute' ),
                    second = getPart( 'second' ),
                    msUntilMidnight = ( ( 24 - hour ) * 3600 - minute * 60 - second ) * 1000 - now.getMilliseconds();

                // 处理跨天边界情况
                const remaining = msUntilMidnight > 0 ? msUntilMidnight :
                    24 * 3600 * 1000 + msUntilMidnight;

                // 动态间隔算法
                let interval = remaining / 10;
                interval = Math.min( interval, 3600000 );  // 最大1小时
                interval = Math.max( interval, 1000 );      // 最小1秒

                return interval;

            } catch ( error ) {
                console.error( 'Interval calculation error:', error );
                return 60000; // 异常时回退1分钟
            }
        }

        check( force = false ) {
            const currentDay = this.getCurrentDayIdentifier( this.options.timeZone );
            if ( currentDay !== this.lastCheckedDay || force ) {
                this.callback( {
                    previousDay : this.lastCheckedDay,
                    currentDay : currentDay,
                    transitionTime : new Date()
                } );
                this.lastCheckedDay = currentDay;
                this.resetInterval();
            }
        }

        resetInterval() {
            clearInterval( this.interval );
            this.interval = setInterval( () => this.check(), this.calculateOptimalInterval() );
        }

        destroy() {
            clearInterval( this.interval );
        }
    }

    /**
     * Algorithm 类提供了一系列静态方法的算法操作
     */
    class Algorithm {

        /**
         * 计算百分比并确保四舍五入后总和为100%
         *
         * @static
         * @param {number[]} values - 需要计算百分比的数值数组
         * @param {number} total - 所有数值的总和
         * @returns {number[]} 返回整数百分比数组,确保总和为100%
         */
        static calculatePercentages( values, total ) {
            if ( !values || values.length === 0 ) {
                return [];
            }
            if ( total === 0 ) {
                return new Array( values.length ).fill( 0 );
            }

            const percentages = values.map( value => {
                const raw = ( value / total ) * 100;
                return {
                    value : value,
                    raw : raw,
                    integer : Math.floor( raw ),
                    fraction : raw % 1
                };
            } );

            let sum = percentages.reduce( ( acc, p ) => acc + p.integer, 0 );
            const difference = 100 - sum;
            percentages.sort( ( a, b ) => b.fraction - a.fraction );

            for ( let i = 0; i < difference; i++ ) {
                percentages[ i ].integer += 1;
            }
            return percentages.map( p => p.integer );
        }

        /**
         * 计算给定起始日期与指定日期之间的天数差
         * @param {string} strStartDate - 起始日期,格式通常为 'YYYY-MM-DD'
         * @param {string} [strEndtDate=new Date] - 结束日期,格式通常为 'YYYY-MM-DD',默认为当前日期
         * @returns {number} - 两个日期之间的天数差
         */
        static calculateDaysDiff( strStartDate, strEndtDate = new Date ) {
            let startDate = new Date( strStartDate ); // 将字符串转换为日期对象
            let todayDate = new Date( strEndtDate ); // 默认为当前日期
            let timeDiff = Math.abs( todayDate.getTime() - startDate.getTime() ); // 获取两个日期的时间差（毫秒）
            let daysDiff = Math.ceil( timeDiff / ( 1000 * 3600 * 24 ) ); // 将时间差转换为天数，并向上取整
            return daysDiff; // 返回天数差
        }

        /**
         * 获取指定范围内的所有整数
         * @param {number} start - 范围的起始值
         * @param {number} end - 范围的结束值
         * @returns {number[]} - 包含范围内所有整数的数组
         */
        static getNumbersBetween( start, end ) {
            let numbers = []; // 存储结果的数组
            // 确保start不大于end
            let min = Math.min( start, end );
            let max = Math.max( start, end );

            // 使用循环从min遍历到max(包括max)
            for ( let i = min; i <= max; i++ ) {
                numbers.push( i ); // 将每个整数添加到数组中
            }
            return numbers; // 返回结果数组
        }

        /**
         * 生成分页列表,返回一个连续页码的数组
         *
         * @param {number} currentPage - 当前的页码
         * @param {number} totalPages - 总页数
         * @param {number} [pageSize=5] - 要返回的连续页码的数量，默认为5
         * @returns {number[]} - 包含连续页码的数组
         */
        static getPaginationList( currentPage, totalPages, pageSize = 5 ) {
            // 确保当前页码是一个正整数，并且不大于总页数
            currentPage = Math.max( 1, Math.min( Math.floor( currentPage ), totalPages ) );

            // 计算序列的起始点
            let start = Math.max( 1, currentPage - Math.floor( ( pageSize - 1 ) / 2 ) );
            let end = start + pageSize - 1;

            // 如果结束点超过了总页数，调整结束点和起始点
            if ( end > totalPages ) {
                start = Math.max( 1, totalPages - pageSize + 1 );
                end = totalPages;
            }

            // 如果起始点小于1，调整起始点和结束点
            while ( start < 1 ) {
                start++;
                end++;
            }

            let paginationList = [];
            for ( let i = start; i <= end; i++ ) {
                paginationList.push( i );
            }
            return paginationList;
        }

        /**
         * 获取指定范围内的所有整数,允许指定步长
         * @param {number} start - 范围的起始值
         * @param {number} end - 范围的结束值
         * @param {number} [step=1] - 步长,默认为1
         * @returns {number[]} - 包含范围内所有整数的数组，按照指定步长
         */
        static getNumbersBetweenWithStep( start, end, step = 1 ) {
            let numbers = []; // 存储结果的数组
            // 确保start不大于end,且step为正数
            if ( start > end && step > 0 ) {
                [ start, end ] = [ end, start ]; // 交换start和end的值
                step = -step; // 如果start大于end,则反向遍历并改变步长
            }

            // 使用循环从start遍历到end(包括end)
            for ( let i = start; ( step > 0 && i <= end ) || ( step < 0 && i >= end ); i += step ) {
                numbers.push( i ); // 将每个整数添加到数组中
            }
            return numbers; // 返回结果数组
        }

        /**
         * 计算当前值相对于最大值的百分比
         * @param {number} currentValue - 当前值
         * @param {number} maxValue - 最大值
         * @param {number} [fixed=0] - 小数点后保留的位数,默认为0
         * @returns {string} - 百分比值,保留指定位数的小数
         */
        static calculatePercentage( currentValue, maxValue, fixed = 0 ) {
            let percentage = ( currentValue / maxValue ) * 100;
            return percentage.toFixed( fixed );
        }

        /**
         * 获取文件的扩展名
         * @param {string} fileName - 文件的完整名称
         * @returns {string} - 文件的扩展名,如果没有扩展名则返回空字符串
         */
        static getFileExtension( fileName ) {
            const parts = fileName.split( '.' );

            if ( parts.length <= 1 ) {
                return '';
            }

            return parts[ parts.length - 1 ];
        }

        /**
         * 判断给定的日期是否在指定的日期范围内.支持年,月,日的任意组合
         * @param {Object} givenDate - 给定日期对象
         * @param {Object} startDate - 起始日期对象
         * @param {Object} endDate - 结束日期对象
         * @returns {boolean} - 如果给定日期在范围内,则返回 true,否则返回 false
         */
        static isDateInRange( {
                                  year : givenYear = 1970,
                                  month : givenMonth = 1,
                                  day : givenDay = 1
                              }, {
                                  year : startYear = 1970,
                                  month : startMonth = 1,
                                  day : startDay = 1
                              }, {
                                  year : endYear = 1970,
                                  month : endMonth = 12,
                                  day : endDay = 31
                              } ) {
            const givenDateObj = new Date( givenYear, givenMonth, givenDay );
            const startDateObj = new Date( startYear, startMonth, startDay );
            const endDateObj = new Date( endYear, endMonth, endDay );
            return givenDateObj >= startDateObj && givenDateObj <= endDateObj;
        }
    }

    /**
     * 获取元素指定层级的父元素
     * @param {HTMLElement} element - 起始的HTML元素
     * @param {number} index - 要获取的父级层级数（必须是非负整数）
     * @returns {HTMLElement | null} - 返回对应的父元素，若不存在则返回null
     */
    function getParent( element, index ) {
        if ( typeof index !== 'number' || index < 0 || !Number.isInteger( index ) ) {
            throw new Error( 'Index must be a non-negative integer' );
        }
        if ( !( element instanceof HTMLElement ) ) {
            throw new Error( 'First argument must be an HTML element' );
        }

        let current = element;

        for ( let i = 0; i < index; i++ ) {
            current = current.parentElement;
            if ( !current ) return null;
        }

        return current;
    }

    return {
        checkClassHasFunction,
        cookieUtil,
        debounce,
        easyStorageTool,
        eventTrigger,
        formatDateString,
        generateUniqueId,
        getAppointParent,
        getBrowserInfo,
        getDeviceOrientation,
        getRandomColor,
        getNowFormatDate,
        getParent,
        setElementInAllPrototypeRecursive,
        updateFavicon,
        RangeCorrection,
        DayChangeDetector,

        AudioPlayer,
        TypeCast,
        Algorithm,
        VitalEvent,

        VarType
    };
} )();
// web-tool SQJM 2025