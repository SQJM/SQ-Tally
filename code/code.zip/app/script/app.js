const App = ( function () {
    const Current = new Proxy( {
        "远程服务器状态" : false,
        "ai服务器状态" : false,
        "第一次进入应用" : false
    }, {
        set : function ( target, p, newValue ) {
            target[ p ] = newValue;
            if ( p === "远程服务器状态" ) {
                if ( newValue && Setting.get( "应用设置.远程服务器状态" ) === Setting.FALSE ) {
                    target[ p ] = !newValue;
                    return;
                }
                EventList.emit( EventListName.REMOTE_SERVER_STATUS_CHANGE, newValue );
            }
            if ( p === "ai服务器状态" ) {
                if ( newValue && Setting.get( "ai设置.AI服务器状态" ) === Setting.FALSE ) {
                    target[ p ] = !newValue;
                    return;
                }
                EventList.emit( EventListName.AI_SERVER_STATUS_CHANGE, newValue );
            }
        },
        get : function ( target, p ) {
            return target[ p ];
        }
    } );

    function animationVisibility() {
        if ( Setting.get( "应用设置.快速应用动画" ) === Setting.TRUE ) {
            document.getElementById( "app-animation-style" ).innerHTML = `* { transition: none !important; animation-delay: 0.1s !important; }`;
        } else {
            document.getElementById( "app-animation-style" ).innerHTML = ``;
        }
    }

    function start() {
        if ( Setting.get( "是否第一次进入应用" ) === Setting.NOP ) {
            Setting.set( "是否第一次进入应用", "no" );
            App.Current[ "第一次进入应用" ] = true;
            console.log( "第一次进入应用" );
            if ( Setting.get( "用户ID" ) === Setting.NOP ) {
                Setting.set( "用户ID", `${ window.crypto.randomUUID() }[:]${ Date.now() }` );
            }
        } else {
            while ( Setting.get( "用户ID" ) === Setting.NOP ) if ( Setting.get( "用户ID" ) !== Setting.NOP ) return;
        }

        marked.use( markedHighlight( {
            highlight : ( code, lang ) => {
                const language = hljs.getLanguage( lang ) ? lang : 'plaintext';
                return hljs.highlight( code, { language } ).value;
            },
            langPrefix : 'hljs language-',
            gfm : true,
            breaks : false,
            pedantic : false,
            sanitize : false,
            smartLists : true,
            smartypants : false
        } ) );

        new WebTool.DayChangeDetector( () => {
            console.log( EventListName.DAY_CHANGE )
            EventList.emit( EventListName.DAY_CHANGE );
        } );

        // 检测远程服务器
        if ( Setting.get( "应用设置.远程服务器状态" ) === Setting.TRUE && Setting.get( "应用设置.设置远程服务器.ip" ) !== Setting.NOP )
            TallyServer.test_link().then( r => {
                MagicUi.feedback.message( {
                    text : "远程服务器,连接通过",
                    eventLevel : MagicUi.previa.feedback.message.EventLevel.pass
                } );
                Current[ "远程服务器状态" ] = true;
                TallyServer.init_SSEServer();
            } ).catch( ( e ) => {
                MagicUi.feedback.message( {
                    text : `远程服务器,连接失败 ${ e }`,
                    eventLevel : MagicUi.previa.feedback.message.EventLevel.error
                } );
            } );

        // 检测ai服务器
        if ( Setting.get( "ai设置.AI服务器状态" ) === Setting.TRUE && Setting.get( "ai设置.设置ai服务器.ip" ) !== Setting.NOP )
            Ai.test_link().then( r => {
                MagicUi.feedback.message( {
                    text : "ai服务器,连接通过",
                    eventLevel : MagicUi.previa.feedback.message.EventLevel.pass
                } );
                Current[ "ai服务器状态" ] = true;
            } ).catch( ( e ) => {
                MagicUi.feedback.message( {
                    text : `ai服务器,连接失败 ${ e }`,
                    eventLevel : MagicUi.previa.feedback.message.EventLevel.error
                } );
            } );

        window.addEventListener( 'resize', function () {
            document.querySelectorAll( "[_echarts_instance_]" ).forEach( item => {
                item.echarts.resize();
            } );
        } );
    }

    return {
        animationVisibility,
        start,
        Current
    };
} )();

const Setting = ( function () {
    const pr = `TALLY_SETTING_`;

    const NOP = "";

    const TRUE = "TRUE";
    const FALSE = "FALSE";

    const norm = {
        "用户ID" : [ "用户ID", NOP ],
        "用户名" : [ "用户名", "Super Cat" ],
        "当前账本密码" : [ "当前账本密码", NOP ],
        "当前账本" : [ "当前账本", NOP ],
        "当前账本存储类型" : [ "当前账本存储类型", NOP ],
        "是否第一次进入应用" : [ "是否第一次进入应用", NOP ],
        "ai设置" : {
            "当前ai模型" : [ "当前ai模型", NOP ],
            "AI服务器状态" : [ "AI服务器状态", TRUE ],
            "设置ai服务器" : {
                "ip" : [ "ip", NOP ],
                "通行证" : [ "通行证", NOP ]
            }
        },
        "应用设置" : {
            "快速应用动画" : [ "快速应用动画", FALSE ],
            "金额单位显示" : [ "金额单位显示", TRUE ],
            "远程服务器状态" : [ "远程服务器状态", TRUE ],
            "设置远程服务器" : {
                "ip" : [ "ip", NOP ],
                "通行证" : [ "通行证", NOP ]
            }
        }
    };

    function remove( key ) {
        localStorage.removeItem( pr + key.replaceAll( ".", "_" ) );
        EventList.emit( EventListName.SETTINGS_CHANGE, "remove", key );
    }

    function set( key, value ) {
        localStorage.setItem( pr + key.replaceAll( ".", "_" ), value );
        EventList.emit( EventListName.SETTINGS_CHANGE, "set", key, value );
    }

    function get( key ) {
        return localStorage.getItem( pr + key.replaceAll( ".", "_" ) ) || NOP;
    }

    function init() {
        function it( o, r = "" ) {
            for ( const k in o ) {
                const v = o[ k ];
                if ( Array.isArray( v ) ) {
                    let t = v[ 0 ];
                    if ( r !== "" ) t = r + "_" + v[ 0 ];
                    if ( localStorage.getItem( pr + t.replaceAll( ".", "_" ) ) !== null ) continue;
                    set( t, v[ 1 ] );
                } else if ( typeof v === "object" ) {
                    if ( r === "" )
                        it( v, k );
                    else
                        it( v, r + "_" + k );
                }
            }
        }

        it( norm );
    }

    return {
        remove,
        set,
        get,
        init,
        NOP,
        TRUE,
        FALSE
    };
} )();