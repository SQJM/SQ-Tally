const TallyRecord = ( function () {
    function getInfo( tallyId, id ) {
        return new Promise( async ( resolve, reject ) => {
            const type = await Tally.getTallyStorageType( tallyId );
            if ( type === "cloud" ) {
                TallyRecordServer.getInfo( tallyId, id ).then( r => resolve( r ) ).catch( r => reject( r ) );
            } else if ( type === "locality" ) {
                const transaction = EasyStorage.IDB.transaction( [ 'TallyRecord' ], 'readwrite' );
                const objectStore = transaction.objectStore( 'TallyRecord' );
                objectStore.get( id ).onsuccess = ( e ) => {
                    resolve( e.target.result );
                };
                transaction.onerror = function ( event ) {
                    reject( event );
                };
            } else {
                reject( "Unknown Tally" );
            }
        } );
    }

    function remove( tallyId, id ) {
        return new Promise( async ( resolve, reject ) => {
            const type = await Tally.getTallyStorageType( tallyId );
            if ( type === "cloud" ) {
                TallyRecordServer.remove( tallyId, id ).then( r => resolve( r ) ).catch( r => reject( r ) );
            } else if ( type === "locality" ) {
                const transaction = EasyStorage.IDB.transaction( [ 'TallyRecord' ], 'readwrite' );
                const objectStore = transaction.objectStore( 'TallyRecord' );
                objectStore.delete( id );
                transaction.oncomplete = function () {
                    resolve();
                    EventList.emit( EventListName.TALLY_RECORD_CHANGE, "remove", tallyId, id );
                    Log.log( `账本记录移除: ${ id }` );
                };
                transaction.onerror = function ( event ) {
                    reject( event );
                };
            } else {
                reject( "Unknown Tally" );
            }
        } );
    }

    function update( tallyId, password, data ) {
        return new Promise( async ( resolve, reject ) => {
            const type = await Tally.getTallyStorageType( tallyId );
            const ecData = await Confuse.encryptString( JSON.stringify( data ), password );
            const newData = {
                id : data.id,
                tally : tallyId,
                time : data.time,
                year : WebTool.getNowFormatDate( data.time, "YYYY" ),
                month : WebTool.getNowFormatDate( data.time, "MM" ),
                day : WebTool.getNowFormatDate( data.time, "DD" ),
                type : data.type,
                data : ecData
            };
            if ( type === "cloud" ) {
                TallyRecordServer.update( newData ).then( r => resolve( r ) ).catch( r => reject( r ) );
            } else if ( type === "locality" ) {
                const transaction = EasyStorage.IDB.transaction( [ 'TallyRecord' ], 'readwrite' );
                const objectStore = transaction.objectStore( 'TallyRecord' );
                objectStore.get( data.id ).onsuccess = async ( e ) => {
                    objectStore.put( newData ).onsuccess = ( e ) => {
                        resolve();
                        EventList.emit( EventListName.TALLY_RECORD_CHANGE, "update", newData );
                        Log.log( `账本记录更新: ${ data.id }` );
                    };
                };
                transaction.onerror = function ( event ) {
                    reject( event );
                };
            } else {
                reject( "Unknown Tally" );
            }
        } );
    }

    function add( obj, password ) {
        return new Promise( async ( resolve, reject ) => {
            const data = await Confuse.encryptString( JSON.stringify( obj ), password );
            const to = await Tally.getInfo( obj.tally );
            if ( !to ) {
                reject( "账本不存在" );
                return;
            }
            const d = {
                id : obj.id,
                tally : obj.tally,
                time : obj.time,
                year : WebTool.getNowFormatDate( obj.time, "YYYY" ),
                month : WebTool.getNowFormatDate( obj.time, "MM" ),
                day : WebTool.getNowFormatDate( obj.time, "DD" ),
                type : obj.type,
                data : data
            };
            if ( to.storage.type === "cloud" ) {
                TallyRecordServer.add( d ).then( r => resolve( r ) ).catch( r => reject( r ) );
            } else if ( to.storage.type === "locality" ) {
                const transaction = EasyStorage.IDB.transaction( [ 'TallyRecord' ], 'readwrite' );
                transaction.oncomplete = function () {
                    resolve();
                    EventList.emit( EventListName.TALLY_RECORD_CHANGE, "add", obj );
                };
                transaction.onerror = function ( event ) {
                    reject( event );
                };
                const objectStore = transaction.objectStore( 'TallyRecord' );
                objectStore.add( d );
                Log.log( `账本记录添加: ${ JSON.stringify( d ) }` );
            } else {
                reject( "Unknown Tally" );
            }
        } );
    }

    function getTallyRecord( tallyId ) {
        return new Promise( async ( resolve, reject ) => {
            const type = await Tally.getTallyStorageType( tallyId );
            if ( type === "cloud" ) {
                resolve( {
                    year( year ) {
                        return TallyRecordServer.getTallyRecord.year( tallyId, year );
                    },
                    month( year, month ) {
                        return TallyRecordServer.getTallyRecord.month( tallyId, year, month );
                    },
                    day( year, month, day ) {
                        return TallyRecordServer.getTallyRecord.day( tallyId, year, month, day );
                    }
                } );
            } else if ( type === "locality" ) {
                resolve( {
                    year( year ) {
                        return new Promise( ( resolve ) => {
                            const tx = EasyStorage.IDB.transaction( [ 'TallyRecord' ], 'readonly' );
                            const index = tx.objectStore( 'TallyRecord' ).index( 'ix_year' );

                            const range = IDBKeyRange.bound(
                                [ tallyId, year ],
                                [ tallyId, year + 1 ],
                                false, true
                            );

                            const years = new Set();
                            const cursor = index.openCursor( range );

                            cursor.onsuccess = ( e ) => {
                                const cursor = e.target.result;
                                if ( cursor ) {
                                    years.add( cursor.value );
                                    cursor.continue();
                                } else {
                                    resolve( Array.from( years ).sort( ( a, b ) => b.time - a.time ) );
                                }
                            };
                        } );
                    },
                    month( year, month ) {
                        return new Promise( ( resolve ) => {
                            const tx = EasyStorage.IDB.transaction( [ 'TallyRecord' ], 'readonly' );
                            const index = tx.objectStore( 'TallyRecord' ).index( 'ix_month' );

                            const range = IDBKeyRange.bound(
                                [ tallyId, year, month ],
                                [ tallyId, year, month + 1 ],
                                false, true
                            );

                            const months = new Set();
                            const cursor = index.openCursor( range );

                            cursor.onsuccess = ( e ) => {
                                const cursor = e.target.result;
                                if ( cursor ) {
                                    months.add( cursor.value );
                                    cursor.continue();
                                } else {
                                    resolve( Array.from( months ).sort( ( a, b ) => b.time - a.time ) );
                                }
                            };
                        } );
                    },
                    day( year, month, day ) {
                        return new Promise( ( resolve ) => {
                            const tx = EasyStorage.IDB.transaction( [ 'TallyRecord' ], 'readonly' );
                            const index = tx.objectStore( 'TallyRecord' ).index( 'ix_day' );

                            const range = IDBKeyRange.bound(
                                [ tallyId, year, month, day ],
                                [ tallyId, year, month, day + 1 ],
                                false, true
                            );

                            const days = new Set();
                            const cursor = index.openCursor( range );

                            cursor.onsuccess = ( e ) => {
                                const cursor = e.target.result;
                                if ( cursor ) {
                                    days.add( cursor.value );
                                    cursor.continue();
                                } else {
                                    resolve( Array.from( days ).sort( ( a, b ) => b.time - a.time ) );
                                }
                            };
                        } );
                    }
                } );
            } else {
                reject( "Unknown Tally" );
            }
        } );
    }

    return {
        remove,
        getInfo,
        update,
        add,
        getTallyRecord
    }
} )();