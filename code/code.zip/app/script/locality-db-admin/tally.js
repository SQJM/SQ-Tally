const Tally = ( function () {
    const State = {
        // 正常
        "normal" : "normal",
        // 移除
        "remove" : "remove"
    };

    function getTallyStorageType( id ) {
        return new Promise( async ( resolve ) => {
            new Promise( async ( resolve, reject ) => {
                const transaction = EasyStorage.IDB.transaction( [ 'Tally' ], 'readwrite' );
                const objectStore = transaction.objectStore( 'Tally' );
                objectStore.get( id ).onsuccess = ( e ) => {
                    resolve( !!e.target.result );
                };
                transaction.onerror = function ( event ) {
                    resolve( false );
                };
            } ).then( r => {
                if ( r ) return resolve( "locality" )
                TallyServer.existTally( id ).then( r => {
                    if ( r ) resolve( "cloud" ); else resolve( null );
                } ).catch( err => {
                    resolve( null );
                } );
            } );
        } )
    }

    function getInfo( id ) {
        return new Promise( async ( resolve, reject ) => {
            const type = await getTallyStorageType( id );
            if ( type === "cloud" ) {
                TallyServer.getInfo( id ).then( r => resolve( r ) ).catch( r => reject( r ) );
            } else if ( type === "locality" ) {
                const transaction = EasyStorage.IDB.transaction( [ 'Tally' ], 'readwrite' );
                const objectStore = transaction.objectStore( 'Tally' );
                objectStore.get( id ).onsuccess = ( e ) => {
                    resolve( e.target.result );
                };
                transaction.onerror = function ( event ) {
                    reject( event );
                };
            } else {
                reject( "Unknown Tally" );
            }
        } );
    }

    function remove( id ) {
        if ( id === Setting.get( "当前账本" ) ) {
            Setting.set( "当前账本", Setting.NOP );
            Setting.set( "当前账本密码", Setting.NOP );
        }
        return new Promise( async ( resolve, reject ) => {
            const type = await getTallyStorageType( id );
            if ( type === "cloud" ) {
                TallyServer.remove( id ).then( r => resolve( r ) ).catch( r => reject( r ) );
            } else if ( type === "locality" ) {
                const transaction = EasyStorage.IDB.transaction( [ 'Tally' ], 'readwrite' );
                const objectStore = transaction.objectStore( 'Tally' );
                objectStore.delete( id );
                transaction.oncomplete = function () {
                    resolve();
                    EventList.emit( EventListName.TALLY_CHANGE, "remove", id );
                    Log.log( `账本删除: ${ id }` );
                };
                transaction.onerror = function ( event ) {
                    reject( event );
                };
            } else {
                reject( "Unknown Tally" );
            }
        } );
    }

    function recover( id ) {
        return new Promise( async ( resolve, reject ) => {
            const type = await getTallyStorageType( id );
            if ( type === "cloud" ) {
                TallyServer.recover( id ).then( r => resolve( r ) ).catch( r => reject( r ) );
            } else if ( type === "locality" ) {
                const transaction = EasyStorage.IDB.transaction( [ 'Tally' ], 'readwrite' );
                const objectStore = transaction.objectStore( 'Tally' );
                objectStore.get( id ).onsuccess = ( e ) => {
                    const obj = e.target.result;
                    obj.state = Tally.State.normal;
                    objectStore.put( obj ).onsuccess = ( e ) => {
                        resolve();
                        EventList.emit( EventListName.TALLY_CHANGE, "recover", obj );
                        Log.log( `账本恢复成功: ${ id }` );
                    };
                };
                transaction.onerror = function ( event ) {
                    reject( event );
                };
            } else {
                reject( "Unknown Tally" );
            }
        } );
    }

    function recycle( id ) {
        if ( id === Setting.get( "当前账本" ) ) {
            Setting.set( "当前账本", Setting.NOP );
            Setting.set( "当前账本密码", Setting.NOP );
        }
        return new Promise( async ( resolve, reject ) => {
            const type = await getTallyStorageType( id );
            if ( type === "cloud" ) {
                TallyServer.recycle( id ).then( r => resolve( r ) ).catch( r => reject( r ) );
            } else if ( type === "locality" ) {
                const transaction = EasyStorage.IDB.transaction( [ 'Tally' ], 'readwrite' );
                const objectStore = transaction.objectStore( 'Tally' );
                objectStore.get( id ).onsuccess = ( e ) => {
                    const obj = e.target.result;
                    obj.state = Tally.State.remove;
                    objectStore.put( obj ).onsuccess = ( e ) => {
                        resolve();
                        EventList.emit( EventListName.TALLY_CHANGE, "recycle", obj );
                        Log.log( `账本回收: ${ id }` );
                    };
                };
                transaction.onerror = function ( event ) {
                    reject( event );
                };
            } else {
                reject( "Unknown Tally" );
            }
        } );
    }

    function getData( id ) {
        return new Promise( async ( resolve, reject ) => {
            const type = await getTallyStorageType( id );
            const tallyId = id;
            if ( type === "cloud" ) {
                resolve( {
                    getYears() {
                        return TallyServer.getData.getYears( tallyId );
                    },
                    getMonths( year ) {
                        return TallyServer.getData.getMonths( tallyId, year );
                    },
                    getDays( year, month ) {
                        return TallyServer.getData.getDays( tallyId, year, month );
                    }
                } );
            } else if ( type === "locality" ) {
                resolve( {
                    getYears() {
                        return new Promise( ( resolve ) => {
                            const tx = EasyStorage.IDB.transaction( [ 'TallyRecord' ], 'readonly' );
                            const index = tx.objectStore( 'TallyRecord' ).index( 'ix_year' );

                            // 构造范围：tallyId <= [tally, year] < tallyId+1
                            const range = IDBKeyRange.bound(
                                [ tallyId ],
                                [ tallyId + '\uffff' ]
                            );

                            const years = new Set();
                            const cursor = index.openCursor( range );

                            cursor.onsuccess = ( e ) => {
                                const cursor = e.target.result;
                                if ( cursor ) {
                                    years.add( cursor.value.year );
                                    cursor.continue();
                                } else {
                                    resolve( Array.from( years ).sort() );
                                }
                            };
                        } );
                    },
                    getMonths( year ) {
                        return new Promise( ( resolve ) => {
                            const tx = EasyStorage.IDB.transaction( [ 'TallyRecord' ], 'readonly' );
                            const index = tx.objectStore( 'TallyRecord' ).index( 'ix_month' );

                            // 范围：[tallyId, year] <= [tally, year, month] < [tallyId, year+1]
                            const range = IDBKeyRange.bound(
                                [ tallyId, year ],
                                [ tallyId, year + 1 ],
                                false, true
                            );

                            const months = new Set();
                            const cursor = index.openCursor( range );

                            cursor.onsuccess = ( e ) => {
                                const cursor = e.target.result;
                                if ( cursor ) {
                                    months.add( cursor.value.month );
                                    cursor.continue();
                                } else {
                                    resolve( Array.from( months ).sort( ( a, b ) => a - b ) );
                                }
                            };
                        } );
                    },
                    getDays( year, month ) {
                        return new Promise( ( resolve ) => {
                            const tx = EasyStorage.IDB.transaction( [ 'TallyRecord' ], 'readonly' );
                            const index = tx.objectStore( 'TallyRecord' ).index( 'ix_day' );

                            // 范围：[tallyId, year, month] <= [tally, year, month, day] < [tallyId, year, month+1]
                            const range = IDBKeyRange.bound(
                                [ tallyId, year, month ],
                                [ tallyId, year, month + 1 ],
                                false, true
                            );

                            const days = new Set();
                            const cursor = index.openCursor( range );

                            cursor.onsuccess = ( e ) => {
                                const cursor = e.target.result;
                                if ( cursor ) {
                                    days.add( cursor.value.day );
                                    cursor.continue();
                                } else {
                                    resolve( Array.from( days ).sort( ( a, b ) => a - b ) );
                                }
                            };
                        } );
                    }
                } );
            } else {
                reject( "Unknown Tally" );
            }
        } );
    }

    function update( newObj ) {
        return new Promise( async ( resolve, reject ) => {
            if ( !newObj.id ) {
                reject( "未知账本" );
                return;
            }
            const type = await getTallyStorageType( newObj.id );
            if ( type === "cloud" ) {
                TallyServer.update( newObj ).then( r => resolve( r ) ).catch( r => reject( r ) );
            } else if ( type === "locality" ) {
                const transaction = EasyStorage.IDB.transaction( [ 'Tally' ], 'readwrite' );
                const objectStore = transaction.objectStore( 'Tally' );
                objectStore.get( newObj.id ).onsuccess = ( e ) => {
                    const obj = {
                        ...e.target.result,
                        ...newObj
                    };
                    objectStore.put( obj ).onsuccess = ( e ) => {
                        resolve();
                        EventList.emit( EventListName.TALLY_CHANGE, "update", obj );
                        Log.log( `账本更新: ${ newObj.id }` );
                    };
                };
                transaction.onerror = function ( event ) {
                    reject( event );
                };
            } else {
                reject( "Unknown Tally" );
            }
        } );
    }

    function create( obj, password ) {
        return new Promise( async ( resolve, reject ) => {
            obj.metadata.who = await Confuse.encryptString( obj.metadata.who, password );
            if ( obj.storage.type === "cloud" ) {
                TallyServer.create( obj ).then( () => {
                    resolve();
                    EventList.emit( EventListName.TALLY_CHANGE, "add", obj );
                    Log.log( `云账本创建: ${ JSON.stringify( obj ) }` );
                } ).catch( e => {
                    reject( e )
                } );
            } else if ( obj.storage.type === "locality" ) {
                const transaction = EasyStorage.IDB.transaction( [ 'Tally' ], 'readwrite' );
                transaction.oncomplete = function () {
                    resolve();
                    EventList.emit( EventListName.TALLY_CHANGE, "add", obj );
                    Log.log( `账本创建: ${ JSON.stringify( obj ) }` );
                };
                transaction.onerror = function ( event ) {
                    reject( event );
                };
                const objectStore = transaction.objectStore( 'Tally' );
                objectStore.add( obj );
            }
        } );
    }

    function getAllTally( state = Tally.State.normal ) {
        return new Promise( async ( resolve, reject ) => {
            const result = [];
            if ( App.Current[ "远程服务器状态" ] ) {
                try {
                    const cr = await TallyServer.getAllTally( state );
                    result.push( ...cr );
                } catch ( e ) {
                    reject( e );
                }
            }
            EasyStorage.IDB.transaction( "Tally" ).objectStore( "Tally" ).getAll().onsuccess = ( e ) => {
                e.target.result.sort( ( a, b ) => a.createTime - b.createTime ).forEach( o => {
                    if ( o.state === state ) result.push( o );
                } );
                resolve( result );
            };
        } )
    }

    return {
        create,
        remove,
        recycle,
        recover,
        getInfo,
        update,
        getAllTally,
        getData,
        getTallyStorageType,
        State
    }
} )();