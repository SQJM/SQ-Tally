const AiStorage = ( () => {
    function createMessageObject( role, message = "", opr = {} ) {
        opr = {
            show : true,
            attrs : {},
            ...opr
        };
        return {
            show : opr.show,
            id : window.crypto.randomUUID(),
            role : role,
            time : Date.now(),
            message : message,
            attrs : {
                ...opr.attrs
            }
        }
    }

    function remove( id ) {
        return new Promise( ( resolve, reject ) => {
            const transaction = EasyStorage.IDB.transaction( [ 'Ai' ], 'readwrite' );
            const os = transaction.objectStore( 'Ai' );
            const request = os.delete( id );

            request.onsuccess = () => {
                resolve( true );
                Log.log( `AI聊天记录移除: ${ id }` );
            }
            request.onerror = ( e ) => reject( e.target.error );
        } );
    }

    function clear() {
        return new Promise( ( resolve, reject ) => {
            const transaction = EasyStorage.IDB.transaction( [ 'Ai' ], 'readwrite' );
            const os = transaction.objectStore( 'Ai' );
            const request = os.clear();

            request.onsuccess = () => {
                resolve( true );
                Log.log( `AI聊天记录清除` );
            }
            request.onerror = ( e ) => reject( e.target.error );
        } );
    }

    function add( obj ) {
        return new Promise( ( resolve, reject ) => {
            const os = EasyStorage.IDB.transaction( [ 'Ai' ], 'readwrite' ).objectStore( 'Ai' );
            os.getAllKeys().onsuccess = ( e ) => {
                if ( e.target.result.filter( o => o.show ).length > 100 || e.target.result.length > 500 )
                    os.clear().onsuccess = () => {
                        resolve( os.add( obj ) )
                        Log.log( `AI聊天记录添加: ${ obj.id }` );
                    };
                else {
                    resolve( os.add( obj ) );
                    Log.log( `AI聊天记录添加: ${ obj.id }` );
                }
            }
        } );
    }

    function getHistory( size = 6 ) {
        return new Promise( ( resolve, reject ) => {
            EasyStorage.IDB.transaction( [ 'Ai' ], 'readwrite' )
            .objectStore( 'Ai' )
            .getAll().onsuccess = ( e ) => {
                const arr = e.target.result.sort( ( a, b ) => a.time - b.time );
                resolve( arr.filter( o => o.show ).slice( Math.max( arr.length - size, 0 ) ) );
            };
        } )
    }

    function getAll() {
        return new Promise( ( resolve, reject ) => {
            EasyStorage.IDB.transaction( [ 'Ai' ], 'readwrite' )
            .objectStore( 'Ai' )
            .getAll().onsuccess = ( e ) => {
                resolve( e.target.result.sort( ( a, b ) => a.time - b.time ) );
            };
        } )
    }

    return {
        createMessageObject,
        add,
        getHistory,
        getAll,
        clear,
        remove
    }
} )();