const PageType = {
    bill : "神奇记账",
    statistics : "统计",
    my : "我的"
};

const MoneyUnit = {
    // 基础货币
    // 美元 (USD)
    dollar : "$",
    // 人民币 (CNY)
    cny : "¥",

    // 欧洲地区
    // 欧元 (EUR)
    euro : "€",
    // 英镑 (GBP)
    pound : "£",
    // 瑞士法郎 (CHF, 符号较少用)
    swissFranc : "CHF",
    // 俄罗斯卢布 (RUB)
    ruble : "₽",

    // 亚洲地区
    // 日元 (JPY) - 注意与人民币符号相同但场景不同
    yen : "¥",
    // 韩元 (KRW)
    won : "₩",
    // 印度卢比 (INR)
    rupee : "₹",
    // 泰铢 (THB)
    baht : "฿",

    // 美洲地区
    // 加拿大元 (CAD)
    canadianDollar : "C$",
    // 墨西哥比索 (MXN)
    mexicanPeso : "Mex$",
    // 巴西雷亚尔 (BRL)
    brazilianReal : "R$",

    // 大洋洲
    // 澳元 (AUD)
    australianDollar : "A$",
    // 新西兰元 (NZD)
    newZealandDollar : "NZ$",

    // 中东与非洲
    // 以色列新谢克尔 (ILS)
    shekel : "₪",
    // 南非兰特 (ZAR)
    rand : "R",
    // 尼日利亚奈拉 (NGN)
    naira : "₦",

    // 加密货币
    // 比特币 (BTC)
    bitcoin : "₿",
    // 以太坊 (ETH)
    ethereum : "Ξ"
};

const EventListName = {
    // 账本变化
    TALLY_CHANGE : "tally-change",
    // 账本记录变化
    TALLY_RECORD_CHANGE : "tally-record-change",
    // 远程服务器状态改变
    REMOTE_SERVER_STATUS_CHANGE : "remote-server-status-change",
    // ai服务器状态改变
    AI_SERVER_STATUS_CHANGE : "ai-server-status-change",
    // 设置变化
    SETTINGS_CHANGE : "settings-change",
    // 一天过去
    DAY_CHANGE : "day-change"
}

let CurrentMoneyUnit = "cny";

const NetDataPassword = "QAQ";

class TopBar {
    static title = null;

    static setTitle( title ) {
        TopBar.title.textContent = title;
    }
}

const Task = ( () => {
    const list = new Map();

    const createQueueHandler = () => {
        let isRunning = false;

        return async ( taskId ) => {
            if ( isRunning ) return;
            isRunning = true;

            while ( list.get( taskId )?.status === 'pending' ) {
                const task = list.get( taskId );
                try {
                    task.status = 'running';
                    await task.fn();
                    task.status = 'completed';
                } catch ( e ) {
                    task.status = 'failed';
                    task.error = e;
                } finally {
                    list.delete( taskId );
                    const nextTask = Array.from( list.values() ).find( t => t.status === 'pending' );
                    if ( nextTask ) await createQueueHandler()( nextTask.id );
                }
            }
            isRunning = false;
        };
    };

    return {
        enter : ( id, fn ) => {
            if ( !id || Task.hasTask( id ) ) {
                return;
            }
            const handler = createQueueHandler( 'net' );

            list.set( id, {
                id,
                fn,
                status : 'pending',
                addTime : Date.now()
            } );
            handler( id );
            return id;
        },
        cancel : ( id ) => {
            if ( list.has( id ) ) {
                list.delete( id );
                return true;
            }
            return false;
        },
        getTask : ( id ) => list.get( id ),
        hasTask : ( id ) => list.has( id ),
        getTasks : () => Array.from( list.values() )
    };
} )();

const Page = ( function () {
    const load = magic.importM( "ui/loading" );

    const netLoad = magic.importM( "ui/net-loading" );

    let load_count = 0;
    let netLoad_count = 0;

    return {
        pause() {
            document.body.style.pointerEvents = "none";
            if ( load_count === 0 )
                load.interface.show();
            else ++load_count;
        },
        start() {
            if ( load_count === 0 ) {
                document.body.style.pointerEvents = "all";
                load.interface.hide();
            } else --load_count;
        },
        netLoadShow() {
            document.body.style.pointerEvents = "none";
            if ( netLoad_count === 0 )
                netLoad.interface.show();
            else ++netLoad_count;
        },
        netLoadHide() {
            if ( netLoad_count === 0 ) {
                document.body.style.pointerEvents = "all";
                netLoad.interface.hide();
            } else --netLoad_count;
        }
    }
} )();

const SSEServer = ( () => {
    /**
     * @type {EventSource}
     */
    let eventSource = null;

    const List = {};

    function register( ev, id, cb ) {
        List[ id ] = {
            event : ev,
            callback : cb
        };
    }

    function init( es ) {
        if ( !eventSource ) eventSource = es;
    }

    function message( data ) {
        console.log( data )
        switch ( data.type ) {
            case "/tally/recycle": {
                if ( data.syncUpdate && data.data === Setting.get( "当前账本" ) ) {
                    Setting.set( "当前账本", Setting.NOP );
                    Setting.set( "当前账本密码", Setting.NOP );
                    MagicUi.feedback.message( {
                        text : `当前账本被回收`,
                        eventLevel : MagicUi.previa.feedback.message.EventLevel.warning
                    } );
                }
            }
                break;
            case "/tally/remove": {
                if ( data.syncUpdate && data.data === Setting.get( "当前账本" ) ) {
                    Setting.set( "当前账本", Setting.NOP );
                    Setting.set( "当前账本密码", Setting.NOP );
                    MagicUi.feedback.message( {
                        text : `当前账本被彻底删除`,
                        eventLevel : MagicUi.previa.feedback.message.EventLevel.warning
                    } );
                }
            }
                break;
        }
        for ( const listKey in List ) {
            if ( List[ listKey ].event.includes( data.type ) ) {
                try {
                    List[ listKey ].callback( data );
                } catch ( e ) {
                    Log.error( "SSEServer Error: " + e );
                    delete List[ listKey ];
                }
            }
        }
    }

    return {
        init,
        message,
        register
    }
} )();

const EventList = ( () => {
    const List = {};
    Object.keys( EventListName ).forEach( ( key ) => {
        List[ EventListName[ key ] ] = new Map;
    } );

    function register( en, id, cb ) {
        List[ en ].set( id, cb );
    }

    function logout( en, id ) {
        List[ en ].delete( id );
    }

    function emit( en, ...args ) {
        List[ en ].forEach( c => c( ...args ) );
    }

    return {
        register,
        logout,
        emit,
        List
    }
} )();

const EasyStorage = ( function () {
    /**
     * @type { IDBDatabase}
     */
    let IDB = null;

    let request = null;

    let ok = false;

    let callback = null;

    function rt() {
        request = window.indexedDB.open( "tally", 1 );

        request.onsuccess = ( event ) => {
            ok = true;
            Log.log( `成功打开indexedDB` );
            EasyStorage.IDB = event.target.result;
            callback();
        };

        request.onerror = ( event ) => {
            Log.error( `indexedDB: ${ event.target.error }` );
            alert( `<UNK>indexedDB` );
        };

        request.onupgradeneeded = function ( event ) {
            const db = event.target.result;

            const objectStore = db.createObjectStore( `Tally`, { keyPath : 'id' } );
            objectStore.createIndex( 'ix_name', 'name', { unique : false } );
            objectStore.createIndex( 'ix_description', 'description', { unique : false } );

            const TallyRecordObjectStore = db.createObjectStore( `TallyRecord`, { keyPath : 'id' } );
            TallyRecordObjectStore.createIndex( 'ix_tally', 'tally', { unique : false } );
            TallyRecordObjectStore.createIndex( 'ix_time', 'time', { unique : true } );
            TallyRecordObjectStore.createIndex( 'ix_year', [ 'tally', 'year' ], { unique : false } );
            TallyRecordObjectStore.createIndex( 'ix_month', [ 'tally', 'year', 'month' ], { unique : false } );
            TallyRecordObjectStore.createIndex( 'ix_day', [ 'tally', 'year', 'month', 'day' ], { unique : false } );
            TallyRecordObjectStore.createIndex( 'ix_type', 'type', { unique : false } );

            const LogObjectStore = db.createObjectStore( `Log`, { keyPath : 'id' } );

            const AiChatDataObjectStore = db.createObjectStore( `Ai`, { keyPath : 'id' } );
            AiChatDataObjectStore.createIndex( 'ix_time', 'time', { unique : true } );
        };
    }

    function init( cb ) {
        callback = cb;
        let rTime = setInterval( () => {
            if ( !ok ) {
                rt();
            } else {
                clearInterval( rTime );
            }
        }, 100 );
    }

    return {
        init,
        IDB
    }
} )();