const Pass = ( function () {
    const {
        fetchAuth,
        fetchAuthPost
    } = Fetch( "应用设置.设置远程服务器.ip", "应用设置.设置远程服务器.通行证" );

    function checkPassIsBind() {
        return new Promise( async ( resolve, reject ) => {
            fetchAuthPost( "/pass/checkPassIsBind" ).then( result => {
                resolve( result );
            } ).catch( e => {
                Log.error( e );
                reject( e );
            } );
        } );
    }

    function bindPass() {
        return new Promise( async ( resolve, reject ) => {
            fetchAuthPost( "/pass/bindPass" ).then( result => {
                resolve( result );
            } ).catch( e => {
                Log.error( e );
                reject( e );
            } );
        } );
    }

    function removeBindPass() {
        return new Promise( async ( resolve, reject ) => {
            fetchAuthPost( "/pass/removeBindPass" ).then( result => {
                resolve( result );
            } ).catch( e => {
                Log.error( e );
                reject( e );
            } );
        } );
    }

    function getVip() {
        return new Promise( async ( resolve, reject ) => {
            fetchAuthPost( "/pass/getVip" ).then( result => {
                resolve( result );
            } ).catch( e => {
                Log.error( e );
                reject( e );
            } );
        } );
    }

    function getFamily() {
        return new Promise( async ( resolve, reject ) => {
            fetchAuthPost( "/pass/getFamily" ).then( result => {
                resolve( result );
            } ).catch( e => {
                Log.error( e );
                reject( e );
            } );
        } );
    }

    function updateFamilyAuthority( newAuthority ) {
        return new Promise( async ( resolve, reject ) => {
            fetchAuthPost( "/pass/updateFamilyAuthority", newAuthority ).then( result => {
                resolve( result );
            } ).catch( e => {
                Log.error( e );
                reject( e );
            } );
        } );
    }

    function addFamilyMember( obj ) {
        return new Promise( async ( resolve, reject ) => {
            fetchAuthPost( "/pass/addFamilyMember", obj ).then( result => {
                resolve( result );
            } ).catch( e => {
                Log.error( e );
                reject( e );
            } );
        } );
    }

    function removeFamilyMember( userID ) {
        return new Promise( async ( resolve, reject ) => {
            fetchAuthPost( "/pass/removeFamilyMember", { userID : userID } ).then( result => {
                resolve( result );
            } ).catch( e => {
                Log.error( e );
                reject( e );
            } );
        } );
    }

    return {
        bindPass,
        checkPassIsBind,
        removeBindPass,
        getVip,
        getFamily,
        updateFamilyAuthority,
        addFamilyMember,
        removeFamilyMember
    };
} )();