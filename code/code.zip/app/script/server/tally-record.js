const TallyRecordServer = ( function () {
    const {
        fetchAuthPost
    } = Fetch( "应用设置.设置远程服务器.ip", "应用设置.设置远程服务器.通行证" );

    function add( obj ) {
        return new Promise( async ( resolve, reject ) => {
            fetchAuthPost( "/tally-record/add", obj ).then( result => {
                resolve( result );
            } ).catch( e => {
                Log.error( e );
                reject( e );
            } );
        } );
    }

    function getInfo( tallyID, id ) {
        return new Promise( async ( resolve, reject ) => {
            fetchAuthPost( "/tally-record/getInfo", {
                tallyID : tallyID,
                id : id
            } ).then( result => {
                resolve( result );
            } ).catch( e => {
                Log.error( e );
                reject( e );
            } );
        } );
    }

    function remove( tallyID, id ) {
        return new Promise( async ( resolve, reject ) => {
            fetchAuthPost( "/tally-record/remove", {
                tallyID : tallyID,
                id : id
            } ).then( result => {
                resolve( result );
            } ).catch( e => {
                Log.error( e );
                reject( e );
            } );
        } );
    }

    function update( obj ) {
        return new Promise( async ( resolve, reject ) => {
            fetchAuthPost( "/tally-record/update", obj ).then( result => {
                resolve( result );
            } ).catch( e => {
                Log.error( e );
                reject( e );
            } );
        } );
    }

    function year( id, year ) {
        return new Promise( async ( resolve, reject ) => {
            fetchAuthPost( "/tally-record/year", {
                id : id,
                year : year
            } ).then( result => {
                if ( Array.isArray( result ) ) return resolve( result.sort( ( a, b ) => b.time - a.time ) );
                resolve( result );
            } ).catch( e => {
                Log.error( e );
                reject( e );
            } );
        } );
    }

    function month( id, year, month ) {
        return new Promise( async ( resolve, reject ) => {
            fetchAuthPost( "/tally-record/month", {
                id : id,
                year : year,
                month : month
            } ).then( result => {
                if ( Array.isArray( result ) ) return resolve( result.sort( ( a, b ) => b.time - a.time ) );
                resolve( result );
            } ).catch( e => {
                Log.error( e );
                reject( e );
            } );
        } );
    }

    function day( id, year, month, day ) {
        return new Promise( async ( resolve, reject ) => {
            fetchAuthPost( "/tally-record/day", {
                id : id,
                year : year,
                month : month,
                day : day
            } ).then( result => {
                if ( Array.isArray( result ) ) return resolve( result.sort( ( a, b ) => b.time - a.time ) );
                resolve( result );
            } ).catch( e => {
                Log.error( e );
                reject( e );
            } );
        } );
    }

    return {
        add,
        remove,
        getInfo,
        update,
        getTallyRecord : {
            year,
            month,
            day
        }
    };
} )();