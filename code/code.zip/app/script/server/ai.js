const Ai = ( () => {
    /**
     *
     * @param name{string}
     * @param data{object}
     * @param summarizeTemplate{string}
     * @param summarizeArgv{object}
     * @returns {string}
     */
    function createExampleSystemReturn( name, data, summarizeTemplate, summarizeArgv ) {
        let str = "";
        let i = 0;
        for ( const key in summarizeArgv ) {
            str += `${ i }.[${ key }]: ${ summarizeArgv[ key ] }\n`;
            ++i;
        }
        return `我的${ name }的json格式数据:` + JSON.stringify( {
            name : name,
            data : data,
            summarize : `${ summarizeTemplate }\n${ str }`
        } ) + "绝对不可以对[${ name }的json格式数据]造假、歪曲扭实.";
    }

    const {
        fetchAuth,
        fetchAuthPost
    } = Fetch( "ai设置.设置ai服务器.ip", "ai设置.设置ai服务器.通行证" );

    function test_link( url = "", tempPass = null ) {
        return new Promise( ( resolve, reject ) => {
            fetchAuth( url, tempPass ).then( result => {
                resolve( result );
            } ).catch( e => {
                Log.error( e );
                reject( e );
            } );
        } )
    }

    function getModels() {
        return new Promise( ( resolve, reject ) => {
            if ( !App.Current[ "ai服务器状态" ] ) {
                reject( "未连接AI服务器" );
                return;
            }
            fetchAuth( "/models" ).then( r => {
                resolve( r );
            } ).catch( e => {
                reject( e );
            } )
        } );
    }

    function chat( messages ) {
        if ( !App.Current[ "ai服务器状态" ] ) {
            MagicUi.feedback.message( {
                text : `未连接AI服务器`,
                eventLevel : MagicUi.previa.feedback.message.EventLevel.warning
            } );
            return;
        }
        if ( Setting.get( "ai设置.当前ai模型" ) === Setting.NOP ) {
            MagicUi.feedback.message( {
                text : `当前没有设置AI模型`,
                eventLevel : MagicUi.previa.feedback.message.EventLevel.warning
            } );
            return;
        }
        messages = messages.map( m => {
            return {
                role : m.role,
                content : m.message
            }
        } );
        return fetchAuthPost( "/chat", {
            model : Setting.get( "ai设置.当前ai模型" ),
            messages : messages
        } );
    }

    return {
        test_link,
        getModels,
        chat,
        createExampleSystemReturn
    }
} )();