const TallyServer = ( function () {
    const {
        fetchAuth,
        fetchAuthPost
    } = Fetch( "应用设置.设置远程服务器.ip", "应用设置.设置远程服务器.通行证" );

    function test_link( url = "", tempPass = null ) {
        return new Promise( ( resolve, reject ) => {
            fetchAuth( url, tempPass ).then( result => {
                resolve( result );
            } ).catch( e => {
                Log.error( e );
                reject( e );
            } );
        } )
    }

    function init_SSEServer() {
        const Authorization = encodeURIComponent( Confuse.encrypt( JSON.stringify( {
            pass : Setting.get( "应用设置.设置远程服务器.通行证" ),
            userID : Setting.get( "用户ID" )
        } ), NetDataPassword ) );
        const eventSource = new EventSource( `http://${ Setting.get( "应用设置.设置远程服务器.ip" ) }/sse?authorization=` + Authorization );

        eventSource.onopen = ( e ) => {
            console.log( "SSE连接已建立" );
            SSEServer.init( eventSource );
        };

        eventSource.onmessage = ( e ) => {
            SSEServer.message( JSON.parse( e.data ) );
        };

        eventSource.onerror = ( e ) => {
            console.error( "SSE连接错误" );
            if ( eventSource.readyState === EventSource.CLOSED ) {
                console.log( "连接断开,3秒后尝试重连..." );
                setTimeout( () => init_SSEServer(), 3000 );
            }
        };
    }

    function create( data ) {
        return new Promise( async ( resolve, reject ) => {
            fetchAuthPost( "/tally/create", data ).then( result => {
                resolve( result );
            } ).catch( e => {
                Log.error( e );
                reject( e );
            } );
        } );
    }

    function getAllTally( state = Tally.State.normal ) {
        return new Promise( async ( resolve, reject ) => {
            fetchAuthPost( "/tally/getAllTally", { state : state } ).then( result => {
                resolve( result );
            } ).catch( e => {
                Log.error( e );
                reject( e );
            } );
        } );
    }

    function existTally( id ) {
        return new Promise( async ( resolve, reject ) => {
            fetchAuthPost( "/tally/existTally", { id : id } ).then( result => {
                resolve( result );
            } ).catch( e => {
                Log.error( e );
                reject( e );
            } );
        } );
    }

    function getInfo( id ) {
        return new Promise( async ( resolve, reject ) => {
            fetchAuthPost( "/tally/getInfo", { id : id } ).then( result => {
                resolve( result );
            } ).catch( e => {
                Log.error( e );
                reject( e );
            } );
        } );
    }

    function remove( id ) {
        return new Promise( async ( resolve, reject ) => {
            fetchAuthPost( "/tally/remove", { id : id } ).then( result => {
                resolve( result );
            } ).catch( e => {
                Log.error( e );
                reject( e );
            } );
        } );
    }

    function recycle( id ) {
        return new Promise( async ( resolve, reject ) => {
            fetchAuthPost( "/tally/recycle", { id : id } ).then( result => {
                resolve( result );
            } ).catch( e => {
                Log.error( e );
                reject( e );
            } );
        } );
    }

    function recover( id ) {
        return new Promise( async ( resolve, reject ) => {
            fetchAuthPost( "/tally/recover", { id : id } ).then( result => {
                resolve( result );
            } ).catch( e => {
                Log.error( e );
                reject( e );
            } );
        } );
    }

    function update( newObj ) {
        return new Promise( async ( resolve, reject ) => {
            fetchAuthPost( "/tally/update", newObj ).then( result => {
                resolve( result );
            } ).catch( e => {
                Log.error( e );
                reject( e );
            } );
        } );
    }

    function getYears( id ) {
        return new Promise( async ( resolve, reject ) => {
            fetchAuthPost( "/tally/getYears", { id : id } ).then( result => {
                resolve( result );
            } ).catch( e => {
                Log.error( e );
                reject( e );
            } );
        } );
    }

    function getMonths( id, year ) {
        return new Promise( async ( resolve, reject ) => {
            fetchAuthPost( "/tally/getMonths", {
                id : id,
                year : year
            } ).then( result => {
                resolve( result );
            } ).catch( e => {
                Log.error( e );
                reject( e );
            } );
        } );
    }

    function getDays( id, year, month ) {
        return new Promise( async ( resolve, reject ) => {
            fetchAuthPost( "/tally/getDays", {
                id : id,
                year : year,
                month : month
            } ).then( result => {
                resolve( result );
            } ).catch( e => {
                Log.error( e );
                reject( e );
            } );
        } );
    }

    return {
        test_link,

        existTally,
        create,
        init_SSEServer,
        remove,
        recycle,
        recover,
        getInfo,
        update,
        getData : {
            getYears,
            getMonths,
            getDays
        },
        getAllTally
    };
} )();