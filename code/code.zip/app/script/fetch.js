const Fetch = ( _url, _pass ) => {
    let getCount = 0;

    let count = 1;

    let resetTimeId = null;
    let resetCountTimeId = null;

    function addCount() {
        getCount += count;
        clearTimeout( resetTimeId );
        clearInterval( resetCountTimeId );
        resetTimeId = setTimeout( () => { count = 1; }, 60 * 1000 );
        resetCountTimeId = setInterval( () => { getCount = 0; }, 3_0000 );
        return getCount > 30;
    }

    resetCountTimeId = setInterval( () => { getCount = 0; }, 3_0000 );

    return {
        fetchAuth( url, pass ) {
            Page.netLoadShow();
            if ( addCount() ) {
                Page.netLoadHide();
                Log.log( `User requests out of rate limit :${ count } * ${ getCount }` );
                return new Promise( ( resolve, reject ) => {
                    reject( "请求超出速率限制,请等待 1分钟. 重复点击会刷新等待时间" );
                } )
            }
            let goUrl = Setting.get( _url );
            if ( goUrl !== url ) goUrl += url;
            return new Promise( ( resolve, reject ) => {
                fetch( "http://" + goUrl, {
                    headers : {
                        'Authorization' : Confuse.encrypt( JSON.stringify( {
                            pass : pass ? pass : Setting.get( _pass ),
                            userID : Setting.get( "用户ID" )
                        } ), NetDataPassword )
                    }
                } ).then( async ( response ) => {
                    const text = await response.text();
                    const o = JSON.parse( Confuse.decrypt( text, NetDataPassword ) );
                    if ( o.error ) {
                        reject( o.error );
                        return;
                    }
                    resolve( o.data );
                } ).catch( reject ).finally( Page.netLoadHide );
            } );
        },
        fetchAuthPost( url, body ) {
            Page.netLoadShow();
            if ( addCount() ) {
                Page.netLoadHide();
                Log.log( `User requests out of rate limit :${ count } * ${ getCount }` );
                return new Promise( ( resolve, reject ) => {
                    reject( "请求超出速率限制,请等待 1分钟 后尝试. 重复点击会刷新等待时间" );
                } )
            }
            let goUrl = Setting.get( _url );
            if ( goUrl !== url ) goUrl += url;
            return new Promise( ( resolve, reject ) => {
                fetch( "http://" + goUrl, {
                    method : 'POST',
                    headers : {
                        'Content-Type' : 'application/json',
                        'Authorization' : Confuse.encrypt( JSON.stringify( {
                            pass : Setting.get( _pass ),
                            userID : Setting.get( "用户ID" )
                        } ), NetDataPassword )
                    },
                    body : Confuse.encrypt( JSON.stringify( body ), NetDataPassword )
                } ).then( async ( response ) => {
                    const text = await response.text();
                    const o = JSON.parse( Confuse.decrypt( text, NetDataPassword ) );
                    if ( o.error ) {
                        reject( o.error );
                        return;
                    }
                    resolve( o.data );
                } ).catch( reject ).finally( Page.netLoadHide );
            } )
        }
    }
}