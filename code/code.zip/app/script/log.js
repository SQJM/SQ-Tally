const Log = ( function () {
    let debug = true;

    window.onerror = ( e ) => {
        if ( !EasyStorage.IDB ) alert( e );
        error( e );
    }

    function store( id, msg ) {
        if ( !EasyStorage.IDB ) return;
        const transaction = EasyStorage.IDB.transaction( [ 'Log' ], 'readwrite' );
        const os = transaction.objectStore( 'Log' );
        os.getAllKeys().onsuccess = ( e ) => {
            if ( e.target.result.length > 500 ) os.clear().onsuccess = () => {
                os.add( {
                    id : id,
                    msg : msg
                } );
            };
            else
                os.add( {
                    id : id,
                    msg : msg
                } );
        }
    }

    function error( msg, code = 0 ) {
        const id = Date.now();
        msg = `Error [${ id }] ${ code } : ${ msg }`;
        if ( debug ) console.error( msg );
        store( id, msg );
    }

    function log( msg, code = 0 ) {
        const id = Date.now();
        msg = `Log [${ id }] ${ code } : ${ msg }`;
        if ( debug ) console.log( msg );
        store( id, msg );
    }

    function info( msg, code = 0 ) {
        const id = Date.now();
        msg = `Info [${ id }] ${ code } : ${ msg }`;
        if ( debug ) console.log( msg );
        store( id, msg );
    }

    return {
        error,
        log,
        info
    }
} )();