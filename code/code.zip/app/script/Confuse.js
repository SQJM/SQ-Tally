const Confuse = ( () => {
    // 加密函数
    const encryptString = async ( plaintext, password ) => {
        if ( password === "" ) return plaintext;
        try {
            const salt = crypto.getRandomValues( new Uint8Array( 16 ) );

            const keyMaterial = await crypto.subtle.importKey(
                "raw",
                new TextEncoder().encode( password ),
                { name : "PBKDF2" },
                false,
                [ "deriveKey" ]
            );

            const key = await crypto.subtle.deriveKey(
                {
                    name : "PBKDF2",
                    salt,
                    iterations : 3200,
                    hash : "SHA-256"
                },
                keyMaterial,
                {
                    name : "AES-CBC",
                    length : 256
                },
                true,
                [ "encrypt", "decrypt" ]
            );

            const iv = crypto.getRandomValues( new Uint8Array( 16 ) );

            const ciphertext = await crypto.subtle.encrypt(
                {
                    name : "AES-CBC",
                    iv
                },
                key,
                new TextEncoder().encode( plaintext )
            );

            const combined = new Uint8Array( salt.length + iv.length + ciphertext.byteLength );
            combined.set( salt, 0 );
            combined.set( iv, salt.length );
            combined.set( new Uint8Array( ciphertext ), salt.length + iv.length );

            return btoa( String.fromCharCode( ...combined ) );
        } catch ( err ) {
            throw new Error( `加密失败: ${ err.message }` );
        }
    };

    // 解密函数
    const decryptString = async ( encryptedString, password ) => {
        if ( password === "" ) return encryptedString;
        try {
            const combined = Uint8Array.from( atob( encryptedString ), c => c.charCodeAt( 0 ) );

            const salt = combined.slice( 0, 16 );
            const iv = combined.slice( 16, 32 );
            const ciphertext = combined.slice( 32 );

            const keyMaterial = await crypto.subtle.importKey(
                "raw",
                new TextEncoder().encode( password ),
                { name : "PBKDF2" },
                false,
                [ "deriveKey" ]
            );

            const key = await crypto.subtle.deriveKey(
                {
                    name : "PBKDF2",
                    salt,
                    iterations : 3200,
                    hash : "SHA-256"
                },
                keyMaterial,
                {
                    name : "AES-CBC",
                    length : 256
                },
                true,
                [ "decrypt" ]
            );

            const decrypted = await crypto.subtle.decrypt(
                {
                    name : "AES-CBC",
                    iv
                },
                key,
                ciphertext
            );

            return new TextDecoder().decode( decrypted );
        } catch ( err ) {
            throw new Error( '解密失败: 密码错误或数据被篡改' );
        }
    };

    // 同步加密
    const encrypt = ( plaintext, password ) => {
        if ( !password ) return plaintext;
        const salt = CryptoJS.lib.WordArray.random( 16 );
        const iv = CryptoJS.lib.WordArray.random( 16 );
        const key = CryptoJS.PBKDF2( password, salt, {
            keySize : 256 / 32,
            iterations : 3200,
            hasher : CryptoJS.algo.SHA256
        } );
        const encrypted = CryptoJS.AES.encrypt( plaintext, key, {
            iv : iv,
            mode : CryptoJS.mode.CBC,
            padding : CryptoJS.pad.Pkcs7
        } );
        // 合并盐 + IV + 密文
        const combined = CryptoJS.enc.Hex.parse(
            salt.toString() + iv.toString() + encrypted.ciphertext.toString()
        );
        return combined.toString( CryptoJS.enc.Base64 );
    };

    // 同步解密
    const decrypt = ( ciphertext, password ) => {
        if ( !password ) return ciphertext;
        const combined = CryptoJS.enc.Base64.parse( ciphertext ).toString( CryptoJS.enc.Hex );
        const salt = CryptoJS.enc.Hex.parse( combined.substr( 0, 32 ) );
        const iv = CryptoJS.enc.Hex.parse( combined.substr( 32, 32 ) );
        const encryptedData = CryptoJS.enc.Hex.parse( combined.substr( 64 ) );
        const key = CryptoJS.PBKDF2( password, salt, {
            keySize : 256 / 32,
            iterations : 3200,
            hasher : CryptoJS.algo.SHA256
        } );
        const decrypted = CryptoJS.AES.decrypt(
            { ciphertext : encryptedData },
            key,
            {
                iv : iv,
                mode : CryptoJS.mode.CBC,
                padding : CryptoJS.pad.Pkcs7
            }
        );
        return decrypted.toString( CryptoJS.enc.Utf8 );
    };

    return {
        encryptString,
        decryptString,
        encrypt,
        decrypt
    };
} )();