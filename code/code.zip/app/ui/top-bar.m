<template>
	<div #id="bar">
		<h3 #id="title" class="title"></h3>
	</div>
</template>

<script>
	const {
        $bar,
        $title
    } = $id();

    TopBar.title = $title;
</script>

<interface>
</interface>

<css scope="#id:bar" default-theme>
	& {
		background-color: #00e75b;

		.title {
			color: #e5fafb;

			text-shadow: 1px -1px 3px #71eaff, -1px 1px 3px #8dccdd;
		}
	}
</css>

<css scope="#id:bar">
	& {
		width: 100%;
		height: 110px;

		position: relative;
		z-index: 10;

		padding-top: 20px;

		.title {
			font-size: 1.2rem;
			display: flex;
			align-items: center;
			justify-content: center;
		}
	}
</css>