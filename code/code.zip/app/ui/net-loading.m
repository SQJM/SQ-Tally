<template>
	<div #id="view">
		<img src="assets/LineMdLoadingLoop.svg"/>
	</div>
</template>

<global>
	const {
		$view
	} = $id();
</global>

<script>
    window.addEventListener( "load", () => {
        document.body.appendChild( $view );
    } );
</script>

<interface>
	show = () => {
		$view.setAttribute( "state", "true" );
	}
</interface>

<interface once>
	hide = () => {
		$view.setAttribute( "state", "false" );
	}
</interface>

<css scope="#id:view">
	& {
		background-color: rgba(0, 0, 0, 0.25);
		border-radius: 8px;
	}
</css>

<css scope="#id:view">
	& {
		position: fixed;
		z-index: 95;

		pointer-events: none;

		width: 80px;
		height: 80px;
		top: 0;
		left: 0;

		margin: 20px;
		padding: 10px;

		display: flex;
		align-items: center;
		justify-content: center;

		&[state="false"] {
			display: none !important;
		}

		img {
			width: 60px;
		}
	}
</css>