<import
	root="ui/page"
>
	<bill/>
</import>

<template>
	<div #id="view">
		<bill class="bill"/>
	</div>
</template>

<css scope="#id:view">
	& {
		width: 100%;
		height: calc(100% - 80px - 110px);
	}
</css>