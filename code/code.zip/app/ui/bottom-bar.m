<import
	root="magic-ui/ui"
>
	<module:widget>
		<item/>
	</module:widget>

	<module:control>
		<list-view/>
	</module:control>
</import>

<template>
	<list-view #id="bar"
			   #listen:select="pageSelect"
			   :direction="row"
			   :def_select="false"
	>
		<item m-select page="bill">
			<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMjgiIGhlaWdodD0iMTI4IiB2aWV3Qm94PSIwIDAgMjQgMjQiPjxnIGZpbGw9Im5vbmUiIGZpbGwtcnVsZT0iZXZlbm9kZCI+PHBhdGggZD0ibTEyLjU5MyAyMy4yNThsLS4wMTEuMDAybC0uMDcxLjAzNWwtLjAyLjAwNGwtLjAxNC0uMDA0bC0uMDcxLS4wMzVxLS4wMTYtLjAwNS0uMDI0LjAwNWwtLjAwNC4wMWwtLjAxNy40MjhsLjAwNS4wMmwuMDEuMDEzbC4xMDQuMDc0bC4wMTUuMDA0bC4wMTItLjAwNGwuMTA0LS4wNzRsLjAxMi0uMDE2bC4wMDQtLjAxN2wtLjAxNy0uNDI3cS0uMDA0LS4wMTYtLjAxNy0uMDE4bS4yNjUtLjExM2wtLjAxMy4wMDJsLS4xODUuMDkzbC0uMDEuMDFsLS4wMDMuMDExbC4wMTguNDNsLjAwNS4wMTJsLjAwOC4wMDdsLjIwMS4wOTNxLjAxOS4wMDUuMDI5LS4wMDhsLjAwNC0uMDE0bC0uMDM0LS42MTRxLS4wMDUtLjAxOC0uMDItLjAyMm0tLjcxNS4wMDJhLjAyLjAyIDAgMCAwLS4wMjcuMDA2bC0uMDA2LjAxNGwtLjAzNC42MTRxLjAwMS4wMTguMDE3LjAyNGwuMDE1LS4wMDJsLjIwMS0uMDkzbC4wMS0uMDA4bC4wMDQtLjAxMWwuMDE3LS40M2wtLjAwMy0uMDEybC0uMDEtLjAxeiIvPjxwYXRoIGZpbGw9IiMwMDAwMDAiIGQ9Ik0xNyAyYTMgMyAwIDAgMSAzIDN2MTZhMSAxIDAgMCAxLTEuNjI1Ljc4bC0xLjg3NS0xLjVsLTEuODc1IDEuNWExIDEgMCAwIDEtMS4zMzItLjA3M0wxMiAyMC40MTRsLTEuMjkzIDEuMjkzYTEgMSAwIDAgMS0xLjMzMi4wNzRMNy41IDIwLjI4bC0xLjg3NSAxLjVBMSAxIDAgMCAxIDQgMjFWNWEzIDMgMCAwIDEgMy0zem0tNSAxMEg5YTEgMSAwIDEgMCAwIDJoM2ExIDEgMCAxIDAgMC0ybTMtNEg5YTEgMSAwIDAgMC0uMTE3IDEuOTkzTDkgMTBoNmExIDEgMCAwIDAgLjExNy0xLjk5M3oiLz48L2c+PC9zdmc+"/>
			<span>账单</span>
		</item>
		<item page="statistics">
			<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMjgiIGhlaWdodD0iMTI4IiB2aWV3Qm94PSIwIDAgNTEyIDUxMiI+PHBhdGggZmlsbD0iIzAwMDAwMCIgZD0iTTEwNCA0OTZINzJhMjQgMjQgMCAwIDEtMjQtMjRWMzI4YTI0IDI0IDAgMCAxIDI0LTI0aDMyYTI0IDI0IDAgMCAxIDI0IDI0djE0NGEyNCAyNCAwIDAgMS0yNCAyNG0yMjQgMGgtMzJhMjQgMjQgMCAwIDEtMjQtMjRWMjMyYTI0IDI0IDAgMCAxIDI0LTI0aDMyYTI0IDI0IDAgMCAxIDI0IDI0djI0MGEyNCAyNCAwIDAgMS0yNCAyNG0xMTIgMGgtMzJhMjQgMjQgMCAwIDEtMjQtMjRWMTIwYTI0IDI0IDAgMCAxIDI0LTI0aDMyYTI0IDI0IDAgMCAxIDI0IDI0djM1MmEyNCAyNCAwIDAgMS0yNCAyNG0tMjI0IDBoLTMyYTI0IDI0IDAgMCAxLTI0LTI0VjQwYTI0IDI0IDAgMCAxIDI0LTI0aDMyYTI0IDI0IDAgMCAxIDI0IDI0djQzMmEyNCAyNCAwIDAgMS0yNCAyNCIvPjwvc3ZnPg=="/>
			<span>统计</span>
		</item>
		<item page="my">
			<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMjgiIGhlaWdodD0iMTI4IiB2aWV3Qm94PSIwIDAgMjQgMjQiPjxwYXRoIGZpbGw9IiMwMDAwMDAiIGQ9Ik01Ljg1IDE3LjFxMS4yNzUtLjk3NSAyLjg1LTEuNTM3VDEyIDE1dDMuMy41NjN0Mi44NSAxLjUzN3EuODc1LTEuMDI1IDEuMzYzLTIuMzI1VDIwIDEycTAtMy4zMjUtMi4zMzctNS42NjNUMTIgNFQ2LjMzNyA2LjMzOFQ0IDEycTAgMS40NzUuNDg4IDIuNzc1VDUuODUgMTcuMU0xMiAxM3EtMS40NzUgMC0yLjQ4OC0xLjAxMlQ4LjUgOS41dDEuMDEzLTIuNDg4VDEyIDZ0Mi40ODggMS4wMTNUMTUuNSA5LjV0LTEuMDEyIDIuNDg4VDEyIDEzbTAgOXEtMi4wNzUgMC0zLjktLjc4OHQtMy4xNzUtMi4xMzdUMi43ODggMTUuOVQyIDEydC43ODgtMy45dDIuMTM3LTMuMTc1VDguMSAyLjc4OFQxMiAydDMuOS43ODh0My4xNzUgMi4xMzdUMjEuMjEzIDguMVQyMiAxMnQtLjc4OCAzLjl0LTIuMTM3IDMuMTc1dC0zLjE3NSAyLjEzOFQxMiAyMiIvPjwvc3ZnPg=="/>
			<span>我的</span>
		</item>
	</list-view>
</template>

<global>
	let ViewContent = null;

	function select( page ) {
		TopBar.setTitle( PageType[ page ] );
		ViewContent.innerHTML = null;
		if ( PageType[ page ] === "神奇记账" ) {
			ViewContent.appendChild( magic.importM( "ui/page/bill" ) );
		} else if ( PageType[ page ] === "统计" ) {
			ViewContent.appendChild( magic.importM( "ui/page/statistics" ) );
		} else if ( PageType[ page ] === "我的" ) {
			ViewContent.appendChild( magic.importM( "ui/page/my" ) );
		}
	}

	function pageSelect( e ) {
		const page = e.getAttribute( "page" );
		select( page );
	}
</global>

<script>
	const {
        $bar
    } = $id();
</script>

<interface>
	init = ( content ) => {
		ViewContent = content;
		select( "bill" );
	}
</interface>

<css scope="#id:bar" default-theme>
	& {
		border-top: solid #f5f5f5;

		& > *[m-item] {
			border: none;

			background-color: #fff;

			&[m-select] {
				background-color: rgba(0, 0, 0, 0) !important;
				color: #00e75b;
			}

			&:hover {
				background-color: rgba(255, 255, 255, 0) !important;
			}

			img {
				opacity: .7;
			}
		}
	}
</css>

<css scope="#id:bar">
	& {
		z-index: 10;

		display: flex;
		align-items: center;
		justify-content: space-evenly;

		flex: 0 auto;

		width: 100%;
		height: 90px;

		& > *[m-item] {
			display: flex;
			align-items: center;
			flex-direction: column;
			gap: 8px;

			padding: 5px;

			img {
				width: 30px;
			}
		}
	}
</css>