<import
	root="magic-ui/ui"
>
	<module:input>
		<edit/>
	</module:input>
</import>

<template>
	<dialog #id="view" open>
		<div class="dialog">
			<h3 #id="title" class="title"></h3>
			<div #id="content" class="content"></div>
			<div #id="group" class="group"></div>
		</div>
	</dialog>
</template>

<global>
	const {
		$view,
		$content,
		$title,
		$group
	} = $id();
</global>

<script>
    document.body.appendChild( $view );
</script>

<interface>
	init = ( {
				 content = "",
				 title = "",
				 group = {},
				 input = false
			 } = {} ) => {
		$title.textContent = title;
		const iut = magic.importM( "magic-ui/ui/input/edit" );
		for ( const groupKey in group ) {
			$group.appendChild( MagicUi.createElement( {
				tagName : "button",
				text : groupKey,
				callback : b => {
					b.onclick = () => {
						if ( group[ groupKey ]( input ? iut.interface.getValue() : undefined ) ) {
							$view.remove();
						}
					};
				}
			} ) );
		}
		if ( input ) {
			$content.appendChild( iut );
		} else if ( content instanceof HTMLElement ) {
			$content.appendChild( content );
		} else {
			$content.innerHTML = content;
		}
	}
</interface>

<css scope="#id:view" default-theme>
	& {
		border: none;

		background-color: rgba(0, 0, 0, 0.12);

		& > .dialog {
			animation: m-appear-top-to-bottom .5s;

			background-color: #ffffff;
			border-radius: 20px;
			border: solid 2px #00e75b;
			box-shadow: rgba(0, 0, 0, 0.16) 0px 1px 4px;

			.title {
				border-bottom: solid 1.5px rgba(66, 66, 66, 0.1);
			}


			.content {
				text-align: center;
			}

			.group {
				border-top: solid 1.5px rgba(0, 0, 0, 0.12);

				button {
					background-color: #fff;
					border: none;

					border-right: solid 1.5px rgba(0, 0, 0, 0.1);

					&:active {
						background-color: #f5f5f5;
					}
				}

				& > button:last-child {
					border: none;
				}
			}
		}
	}
</css>

<css scope="#id:view">
	& {
		top: 0;
		left: 0;
		position: fixed;
		width: 100%;
		height: 100%;

		z-index: 94;

		display: flex;
		align-items: center;
		justify-content: center;

		padding-bottom: 120px;

		& > .dialog {
			min-width: 65%;
			min-height: 25%;
			max-width: 90%;
			max-height: calc(90% - 120px);

			display: flex;
			flex-direction: column;
			justify-content: space-between;
			align-items: center;

			overflow: hidden;

			.title {
				margin: 0;

				width: 100%;
				height: 55px;

				display: flex;
				align-items: center;

				padding: 8px 10px 8px 10px;
			}

			.content {
				overflow: auto;

				width: 100%;
				height: 100%;

				padding: 5px;

				font-size: x-large;
			}

			.group {
				display: flex;
				align-items: center;

				width: 100%;
				height: 50px;

				button {
					width: 100%;
					height: 100%;

					font-size: larger;
				}

				& > button:last-child {
					padding-right: 7.5px;
				}
			}
		}
	}
</css>