<template>
	<div #id="view">
		<img src="assets/EosIconsBubbleLoading.svg"/>
	</div>
</template>

<global>
	const {
		$view
	} = $id();
</global>

<script>
    window.addEventListener( "load", () => {
        document.body.appendChild( $view );
    } );
</script>

<interface>
	show = () => {
		$view.setAttribute( "state", "true" );
	}
</interface>

<interface once>
	hide = () => {
		$view.setAttribute( "state", "false" );
	}
</interface>

<css scope="#id:view">
	& {
		background-color: rgba(0, 0, 0, 0.3);
	}
</css>

<css scope="#id:view">
	& {
		position: fixed;
		z-index: 95;

		width: 100%;
		height: 100%;
		top: 0;
		left: 0;

		display: flex;
		align-items: center;
		justify-content: center;

		&[state="false"] {
			display: none !important;
		}

		img {
			width: 60px;
		}
	}
</css>