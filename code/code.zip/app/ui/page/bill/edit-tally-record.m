<import
	root="magic-ui/ui"
>
	<module:input>
		<edit/>
	</module:input>

	<module:widget>
		<item/>
	</module:widget>

	<module:control>
		<list-view/>
	</module:control>
</import>

<import
	root="ui"
>
	<money-unit/>
</import>

<template>
    <div #id="view">
        <div class="tab">
            <div #id="tab-bar" @click="tabSwitch" class="bar">
                <label #name="zc" tab-bar-item select>支出</label>
                <label #name="sr" tab-bar-item>收入</label>
            </div>
            <div #id="tab-content" class="content">
                <list-view #id="list0" :direction="row" show class="支出">
                    <item>
                        <lable>早饭</lable>
                    </item>
                    <item>
                        <lable>午饭</lable>
                    </item>
                    <item>
                        <lable>晚饭</lable>
                    </item>
                    <item>
                        <lable>夜宵</lable>
                    </item>
                    <item>
                        <lable>日用品</lable>
                    </item>
                    <item>
                        <lable>小零食</lable>
                    </item>
                    <item>
                        <lable>医疗</lable>
                    </item>
                    <item>
                        <lable>汽车</lable>
                    </item>
                    <item>
                        <lable>交通</lable>
                    </item>
                    <item>
                        <lable>打滴</lable>
                    </item>
                    <item>
                        <lable>出行</lable>
                    </item>
                    <item>
                        <lable>购物</lable>
                    </item>
                    <item>
                        <lable>网购</lable>
                    </item>
                    <item>
                        <lable>外卖</lable>
                    </item>
                    <item>
                        <lable>生活</lable>
                    </item>
                    <item>
                        <lable>房租</lable>
                    </item>
                    <item>
                        <lable>水费</lable>
                    </item>
                    <item>
                        <lable>电费</lable>
                    </item>
                    <item>
                        <lable>网费</lable>
                    </item>
                    <item>
                        <lable>游戏充值</lable>
                    </item>
                    <item>
                        <lable>软件vip</lable>
                    </item>
                    <item>
                        <lable>烟</lable>
                    </item>
                    <item>
                        <lable>酒</lable>
                    </item>
                    <item>
                        <lable>宠物</lable>
                    </item>
                    <item>
                        <lable>孩子</lable>
                    </item>
                    <item>
                        <lable>红包</lable>
                    </item>
                    <item>
                        <lable>送礼</lable>
                    </item>
                    <item>
                        <lable>打赏</lable>
                    </item>
                    <item>
                        <lable>话费</lable>
                    </item>
                    <item>
                        <lable>遗失</lable>
                    </item>
                    <item>
                        <lable>旅行</lable>
                    </item>
                    <item>
                        <lable>化妆品</lable>
                    </item>
                    <item>
                        <lable>娱乐</lable>
                    </item>
                    <item>
                        <lable>保养</lable>
                    </item>
                    <item>
                        <lable>数码</lable>
                    </item>
                    <item>
                        <lable>公益</lable>
                    </item>
                    <item>
                        <lable>保险</lable>
                    </item>
                    <item>
                        <lable>房贷</lable>
                    </item>
                    <item>
                        <lable>车贷</lable>
                    </item>
                    <item>
                        <lable>投资</lable>
                    </item>
                    <item>
                        <lable>其他</lable>
                    </item>
                </list-view>
                <list-view #id="list1" :direction="row" class="收入">
                    <item>
                        <lable>工资</lable>
                    </item>
                    <item>
                        <lable>红包</lable>
                    </item>
                    <item>
                        <lable>奖金</lable>
                    </item>
                    <item>
                        <lable>生活费</lable>
                    </item>
                    <item>
                        <lable>理财</lable>
                    </item>
                    <item>
                        <lable>外快</lable>
                    </item>
                    <item>
                        <lable>股票基金</lable>
                    </item>
                    <item>
                        <lable>意外收获</lable>
                    </item>
                    <item>
                        <lable>零花钱</lable>
                    </item>
                    <item>
                        <lable>礼物</lable>
                    </item>
                    <item>
                        <lable>退款</lable>
                    </item>
                    <item>
                        <lable>不透明收入</lable>
                    </item>
                    <item>
                        <lable>经商</lable>
                    </item>
                    <item>
                        <lable>其他</lable>
                    </item>
                </list-view>
            </div>
        </div>
        <div class="input">
            <div #id="speedy" class="speedy">
                <button style="position: relative"><input #name="date-input" type="datetime-local" style="opacity: 0;width: 0px;height: 0px;position: absolute;top: 0;left: 0;pointer-events: none"/><lable #name="date"></lable></button>
                <button #name="switch-tally" style="min-width: 100px;overflow: hidden;text-overflow: ellipsis">默认账本</button>
                <button #name="auto-record" style="min-width: 130px">自动记账</button>
            </div>
            <div class="extra">
                <edit #id="remark" :placeholder="点此输入备注..." :maxlength="100" class="input"/>
                <span class="money">
                    <money-unit/>
                    <span #id="use-money" class="number">0</span>
                </span>
            </div>
            <div class="input-calculate">
                <div @click="numberScopeInput" class="number">
                    <div>
                        <span data="7" class="number">7</span>
                        <span data="8" class="number">8</span>
                        <span data="9" class="number">9</span>
                    </div>
                    <div>
                        <span data="4" class="number">4</span>
                        <span data="5" class="number">5</span>
                        <span data="6" class="number">6</span>
                    </div>
                    <div>
                        <span data="1" class="number">1</span>
                        <span data="2" class="number">2</span>
                        <span data="3" class="number">3</span>
                    </div>
                    <div>
                        <span data=".">•</span>
                        <span data="0" class="number">0</span>
                        <span data="next" style="font-size: larger">再记</span>
                    </div>
                </div>
                <div class="calculate">
                    <img @click="backspace" class="delete" src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMjgiIGhlaWdodD0iMTI4IiB2aWV3Qm94PSIwIDAgMjQgMjQiPjxnIGZpbGw9Im5vbmUiPjxwYXRoIGQ9Im0xMi41OTMgMjMuMjU4bC0uMDExLjAwMmwtLjA3MS4wMzVsLS4wMi4wMDRsLS4wMTQtLjAwNGwtLjA3MS0uMDM1cS0uMDE2LS4wMDUtLjAyNC4wMDVsLS4wMDQuMDFsLS4wMTcuNDI4bC4wMDUuMDJsLjAxLjAxM2wuMTA0LjA3NGwuMDE1LjAwNGwuMDEyLS4wMDRsLjEwNC0uMDc0bC4wMTItLjAxNmwuMDA0LS4wMTdsLS4wMTctLjQyN3EtLjAwNC0uMDE2LS4wMTctLjAxOG0uMjY1LS4xMTNsLS4wMTMuMDAybC0uMTg1LjA5M2wtLjAxLjAxbC0uMDAzLjAxMWwuMDE4LjQzbC4wMDUuMDEybC4wMDguMDA3bC4yMDEuMDkzcS4wMTkuMDA1LjAyOS0uMDA4bC4wMDQtLjAxNGwtLjAzNC0uNjE0cS0uMDA1LS4wMTgtLjAyLS4wMjJtLS43MTUuMDAyYS4wMi4wMiAwIDAgMC0uMDI3LjAwNmwtLjAwNi4wMTRsLS4wMzQuNjE0cS4wMDEuMDE4LjAxNy4wMjRsLjAxNS0uMDAybC4yMDEtLjA5M2wuMDEtLjAwOGwuMDA0LS4wMTFsLjAxNy0uNDNsLS4wMDMtLjAxMmwtLjAxLS4wMXoiLz48cGF0aCBmaWxsPSIjMzMzMzMzIiBkPSJNMTkgM2EzIDMgMCAwIDEgMi45OTUgMi44MjRMMjIgNnYxMmEzIDMgMCAwIDEtMi44MjQgMi45OTVMMTkgMjFIOC4xMDhhMyAzIDAgMCAxLTIuNDM2LTEuMjVsLS4xMDgtLjE2bC00LjA4LTYuNTNhMiAyIDAgMCAxLS4wODctMS45NjdsLjA4Ni0uMTUzbDQuMDgxLTYuNTNhMyAzIDAgMCAxIDIuMzUxLTEuNDA0TDguMTA4IDN6bTAgMkg4LjEwOGExIDEgMCAwIDAtLjc3My4zNjZsLS4wNzUuMTA0TDMuMTggMTJsNC4wOCA2LjUzYTEgMSAwIDAgMCAuNzIuNDYybC4xMjguMDA4SDE5YTEgMSAwIDAgMCAuOTkzLS44ODNMMjAgMThWNmExIDEgMCAwIDAtLjg4My0uOTkzem0tOC4xMjEgMy40NjRsMi4xMiAyLjEyMmwyLjEyMi0yLjEyMmExIDEgMCAxIDEgMS40MTQgMS40MTVMMTQuNDE1IDEybDIuMTIgMi4xMjFhMSAxIDAgMCAxLTEuNDE0IDEuNDE1TDEzIDEzLjQxNGwtMi4xMjEgMi4xMjJhMSAxIDAgMSAxLTEuNDE1LTEuNDE1TDExLjU4NiAxMkw5LjQ2NCA5Ljg3OWExIDEgMCAwIDEgMS40MTUtMS40MTUiLz48L2c+PC9zdmc+"/>
                    <div @click="symbolInput" class="box">
                        <div class="low">
                            <img data="+" src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMjgiIGhlaWdodD0iMTI4IiB2aWV3Qm94PSIwIDAgMjQgMjQiPjxwYXRoIGZpbGw9IiMzMzMzMzMiIGQ9Ik0xMiA0YTEgMSAwIDAgMSAxIDF2Nmg2YTEgMSAwIDEgMSAwIDJoLTZ2NmExIDEgMCAxIDEtMiAwdi02SDVhMSAxIDAgMSAxIDAtMmg2VjVhMSAxIDAgMCAxIDEtMSIvPjwvc3ZnPg=="/>
                            <img data="-" src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMjgiIGhlaWdodD0iMTI4IiB2aWV3Qm94PSIwIDAgMjQgMjQiPjxwYXRoIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzMzMzMzMyIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjIiIGQ9Ik01IDEyaDE0Ii8+PC9zdmc+"/>
                        </div>
                        <div class="pro">
                            <img data="×" src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMjgiIGhlaWdodD0iMTI4IiB2aWV3Qm94PSIwIDAgMjQgMjQiPjxwYXRoIGZpbGw9IiMzMzMzMzMiIGQ9Im0xMy40MSAxMmw2LjMtNi4yOWExIDEgMCAxIDAtMS40Mi0xLjQyTDEyIDEwLjU5bC02LjI5LTYuM2ExIDEgMCAwIDAtMS40MiAxLjQybDYuMyA2LjI5bC02LjMgNi4yOWExIDEgMCAwIDAgMCAxLjQyYTEgMSAwIDAgMCAxLjQyIDBsNi4yOS02LjNsNi4yOSA2LjNhMSAxIDAgMCAwIDEuNDIgMGExIDEgMCAwIDAgMC0xLjQyWiIvPjwvc3ZnPg=="/>
                            <img data="÷" src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMjgiIGhlaWdodD0iMTI4IiB2aWV3Qm94PSIwIDAgNDggNDgiPjxnIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzMzMzMzMyIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjQiPjxjaXJjbGUgY3g9IjI0IiBjeT0iMTEiIHI9IjUiLz48Y2lyY2xlIGN4PSIyNCIgY3k9IjM3IiByPSI1Ii8+PHBhdGggZD0iTTQ0IDI0SDQiLz48L2c+PC9zdmc+"/>
                        </div>
                    </div>
                    <button #id="enter" @click="enter">保存</button>
                </div>
            </div>
        </div>
    </div>
</template>

<global>
	const {
		$view,
		$tabContent,
		$useMoney,
		$remark,
		$enter,
		$list0,
		$list1
	} = $id();

	const $speedy = $id( "speedy" );

	const pdv = magic.importM( "ui/pop-down-view" );

	let isSymbol = false;

	let isDot = false;

	let times = null;
	let currentTallyId = null,
		currentTallyPassword = null;

	let currentRecordId = null;

	let currentTallyType = "支出";

	function evalSymbol( str ) {
		const r = eval( str.replaceAll( "×", "*" ).replaceAll( "÷", "/" ) );
		if ( `${ r }`.includes( "." ) ) return parseFloat( r.toFixed( 2 ) );
		return r;
	}
</global>

<event>
	tabSwitch = ( event ) => {
		const target = event.target;
		if ( !target.hasAttribute( "tab-bar-item" ) ) return;
		target.parentNode.childNodes.forEach( e => e.removeAttribute( "select" ) );
		target.setAttribute( "select", "" );

		$tabContent.childNodes.forEach( e => e.removeAttribute( "show" ) );
		$tabContent.getElementsByClassName( target.textContent ).item( 0 ).setAttribute( "show", "" );

		currentTallyType = target.textContent;
	}

	backspace = () => {
		$useMoney.textContent = $useMoney.textContent.slice( 0, -1 );
		if ( $useMoney.textContent === "" ) $useMoney.textContent = "0";
		if ( /[-+×÷]/.test( $useMoney.textContent ) ) {
			isSymbol = true;
		} else {
			isSymbol = false;
			$enter.textContent = "保存";
		}
	}

	enter = ( e ) => {
		let code = $useMoney.textContent;
		if ( isSymbol ) {
			try {
				let r = `${ evalSymbol( code ) }`;
				if ( r.lastIndexOf( "." ) !== -1 ) r = r.replace( /(\.\w{2})\w*/, '$1' );
				$useMoney.textContent = r;
				isSymbol = false;
				$enter.textContent = "保存";
				if ( e !== "next" ) return;
			} catch ( e ) {
				MagicUi.feedback.message( {
					text : `错误公式${ e }`,
					eventLevel : MagicUi.previa.feedback.message.EventLevel.error
				} );
			}
		}
		const record = {
			id : currentRecordId,
			time : times,
			type : currentTallyType,
			target : "",
			money : parseFloat( $useMoney.textContent ),
			remark : $remark.interface.getValue(),
			tally : currentTallyId
		};

		if ( currentTallyType === "支出" ) {
			record.target = $list0.interface.getSelect().textContent;
		} else {
			record.target = $list1.interface.getSelect().textContent;
		}
		TallyRecord.update( currentTallyId, currentTallyPassword, record ).then( _ => {
			MagicUi.feedback.message( {
				text : `修改成功`,
				eventLevel : MagicUi.previa.feedback.message.EventLevel.pass
			} );
		} ).catch( e => {
			MagicUi.feedback.message( {
				text : `${ e }`,
				eventLevel : MagicUi.previa.feedback.message.EventLevel.error
			} );
		} ).finally( _ => {
			pdv.interface.close();
			if ( e === "next" ) magic.importM( "ui/page/bill/add-tally-record" );
		} );
	}

	symbolInput = ( event ) => {
		const target = event.target;
		if ( target.hasAttribute( "data" ) ) {
			const data = target.getAttribute( "data" );

			if ( /[-+×÷]$/.test( $useMoney.textContent ) ) {
				return;
			}

			if ( $useMoney.textContent.length > 15 ) {
				MagicUi.feedback.message( {
					text : `公式太长了,请简单点吧`,
					eventLevel : MagicUi.previa.feedback.message.EventLevel.warning
				} );
				return;
			}

			$useMoney.textContent += data;
			isSymbol = true;
			$enter.textContent = "等于";
		}
	}

	numberScopeInput = ( event ) => {
		const target = event.target;
		if ( target.hasAttribute( "data" ) ) {
			const data = target.getAttribute( "data" );
			if ( data === "next" ) {
				call.event( "enter", "next" );
				return;
			}

			const oCode = $useMoney.textContent;

			if ( !/\.\d+$/.test( oCode ) ) isDot = false;

			if ( data === "." ) {
				if ( !isDot ) {
					isDot = true;
					$useMoney.textContent += ".";
				}
				return;
			}

			let code = oCode + data;

			let isDotZero = false;
			if ( code.endsWith( ".0" ) ) {
				isDotZero = true;
			}

			if ( isSymbol ) {
				if ( /\.\d+$/.test( code ) ) {
					const lastDotIndex = code.lastIndexOf( '.' );
					const fromDot = lastDotIndex !== -1 ? code.slice( lastDotIndex ) : "";
					if ( fromDot.length > 3 ) {
						code = code.slice( 0, -( fromDot.length - 3 ) );
					}
				}

				if ( code.length > 15 ) {
					MagicUi.feedback.message( {
						text : `公式太长了,请简单点吧`,
						eventLevel : MagicUi.previa.feedback.message.EventLevel.warning
					} );
					return;
				}

				try {
					const r = evalSymbol( code );
					if ( r > 100000000 ) {
						MagicUi.feedback.message( {
							text : `单笔记录最大 1亿`,
							eventLevel : MagicUi.previa.feedback.message.EventLevel.warning
						} );
						return;
					}
					if ( r < 0 ) {
						MagicUi.feedback.message( {
							text : `金额不能为负数`,
							eventLevel : MagicUi.previa.feedback.message.EventLevel.warning
						} );
						return;
					}
					$useMoney.textContent = code;
				} catch ( e ) {
					MagicUi.feedback.message( {
						text : `错误公式${ e }`,
						eventLevel : MagicUi.previa.feedback.message.EventLevel.error
					} );
				}
				return;
			}

			code = math.number( code );
			if ( isNaN( code ) ) {
				return;
			}

			if ( code > 100000000 ) {
				MagicUi.feedback.message( {
					text : `单笔记录最大 1亿`,
					eventLevel : MagicUi.previa.feedback.message.EventLevel.warning
				} );
				return;
			}
			if ( oCode.lastIndexOf( "." ) !== -1 ) {
				code = `${ code }`.replace( /(\.\w{2})\w*/, '$1' );
			}
			if ( isDotZero ) {
				code += ".0";
			}
			$useMoney.textContent = code;
		}
	}
</event>

<script>

</script>

<interface>
	init = ( tid, tpd, dat ) => {
		currentTallyId = tid;
		currentTallyPassword = tpd;
		times = dat.time;
		currentRecordId = dat.id;

		$remark.interface.setValue( dat.remark );
		$useMoney.textContent = dat.money;

		const rTarget = dat.target;
		if ( dat.type === "收入" ) {
			$id( "tab-bar" ).$name( "sr" ).click();
			$list1.interface.getAll().forEach( item => {
				if ( item.interface.getText() === rTarget ) $list1.interface.selectItem( item );
			} );
		} else {
			$list0.interface.getAll().forEach( item => {
				if ( item.interface.getText() === rTarget ) $list0.interface.selectItem( item );
			} );
		}

		pdv.interface.init( $view );

		Tally.getInfo( currentTallyId ).then( o => {
			$speedy.$name( "switch-tally" ).textContent = o.name;
		} );

		$speedy.$name( "date" ).textContent = WebTool.getNowFormatDate( times, "MM-DD HH:mm" );

		$speedy.$name( "date-input" ).oninput = ( ev ) => {
			times = new Date( ev.target.value ).getTime();
			$speedy.$name( "date" ).textContent = WebTool.getNowFormatDate( times, "MM-DD HH:mm" );
		}
		$speedy.$name( "date" ).onclick = () => {
			$speedy.$name( "date-input" ).showPicker();
		}
		$speedy.$name( "switch-tally" ).onclick = () => {
			Tally.getAllTally( Tally.State.normal ).then( r => {
				magic.importM( "ui/pop-select-list" ).interface.init( async ( target ) => {
					const id = target.getAttribute( "id" );
					if ( currentTallyId === id ) {
						return true;
					}
					const o = await Tally.getInfo( id );
					if ( o.metadata.who === "SQ-Tally" ) {
						currentTallyId = id;
						$speedy.$name( "switch-tally" ).textContent = o.name;
					} else
						magic.importM( "ui/dialog" ).interface.init( {
							title : "该账本已被加密,请输入密码",
							input : true,
							group : {
								"确定" : async ( v ) => {
									try {
										if ( v.trim() === "" ) throw new Error( "账本密码错误" );
										await Confuse.decryptString( o.metadata.who, v );
										currentTallyId = id;
										currentTallyPassword = v;
										$speedy.$name( "switch-tally" ).textContent = o.name;
										return true;
									} catch ( e ) {
										MagicUi.feedback.message( {
											text : `账本密码错误`,
											eventLevel : MagicUi.previa.feedback.message.EventLevel.error
										} );
									}
								},
								"取消" : () => {
									return true;
								}
							}
						} );
					return true;
				}, r.map( o => {
					return {
						text : o.name,
						id : o.id,
						type : o.storage.type
					}
				} ), ( item ) => {
					item.setAttribute( "style", "display: flex;align-items: center;flex-direction: row-reverse;justify-content: flex-end;gap: 8px;" );
					const icon = MagicUi.createElement( { tagName : "img" } );
					icon.setAttribute( "style", "pointer-events: none;width: 35px;" );
					if ( item.getAttribute( "type" ) === "cloud" )
						icon.setAttribute( "src", `assets/MaterialSymbolsCloud.svg` );
					else
						icon.setAttribute( "src", `assets/OpenmojiLedger.svg` );
					item.appendChild( icon );
				} );
			} );
		}
		$speedy.$name( "auto-record" ).onclick = () => {

		}
	}
</interface>

<css scope="#id:view" default-theme>
	& {

		& > .tab {

			& > .bar {
				border-radius: 20px;

				background-color: #00e75b;
			}

			& > .content {
				& > div > div {
					border-radius: 10px;

					box-shadow: rgba(149, 157, 165, 0.2) 0px 8px 24px;
				}
			}
		}

		& > .input {
			background-color: #ffffff;

			box-shadow: rgba(0, 0, 0, 0.09) 0px 3px 12px;

			border-radius: 20px;

			& > .input-calculate {
				& > .number {
					& > div {
						span:active {
							background-color: #ededed;
						}
					}
				}

				& > .calculate {
					button {
						background-color: #00e75b;

						border-radius: 10px;

						border: none;
					}
				}
			}

			& > .speedy {
				overflow: auto;

				width: 100%;

				button {
					background-color: #00e75b;

					border-radius: 10px;

					border: none;

					text-wrap: nowrap;
				}
			}

			& > .extra {
				.input {
					border: none;

					box-shadow: rgba(0, 0, 0, 0.05) 0px 0px 0px 1px, rgba(209, 213, 219, 0.55) 0px 0px 0px 1px inset;
				}

				.money {
					text-wrap: nowrap;

					span {
						color: #333;

						padding: 4px;
					}
				}
			}
		}
	}
</css>

<css scope="#id:view">
	& {
		position: relative;

		height: 100%;

		& > .tab {
			display: flex;
			flex-direction: column;

			height: 100%;

			& > .bar {
				display: flex;
				flex-direction: row;
				justify-content: space-evenly;
				align-items: center;

				width: 100%;
				height: 60px;

				font-size: larger;

				& > label[select] {
					scale: 1.2;
				}
			}

			& > .content {
				display: flex;

				height: calc(100% - 390px);
				width: 100%;

				padding: 10px 10px 15px 10px;

				& > div {
					display: none;

					overflow: auto;

					flex-wrap: wrap;
					align-items: center;
					justify-content: center;
					align-content: flex-start;

					padding-bottom: 18px;

					& > div {
						display: inline-flex;

						margin: 12px;

						min-height: 80px;

						& > lable {
							display: flex;
							align-items: center;
							justify-content: center;

							text-wrap: nowrap;

							font-size: larger;

							min-width: 80px;
							min-height: 30px;
						}
					}
				}

				& > div[show] {
					display: flex;
				}
			}
		}

		& > .input {
			position: absolute;
			bottom: 0;

			display: flex;
			flex-direction: column;
			gap: 10px;

			min-height: 330px;
			width: 100%;

			padding: 10px;

			& > .speedy {
				height: 100%;
				width: 100%;

				display: flex;
				align-items: center;
				gap: 10px;

				padding: 6px;

				button {
					flex: 0 auto;

					font-size: larger;

					padding: 4px 8px 4px 8px;

					min-width: 150px;
				}
			}

			& > .extra {
				height: 100%;
				width: 100%;

				display: flex;
				align-items: center;
				justify-content: space-between;
				gap: 6px;

				img {
					width: 25px;
				}

				.input {
					width: 100%;
				}

				.money {
					font-size: xx-large;

					max-width: 75%;

					& > span:last-child {
						display: inline-flex;

						max-width: 88%;
						min-width: 80px;
						overflow: auto;
					}
				}
			}

			& > .input-calculate {
				display: flex;
				flex-direction: row;

				& > .number {
					display: flex;
					flex-direction: column;
					align-items: center;
					justify-content: space-between;

					width: 100%;

					& > div {
						display: flex;
						flex-direction: row;
						align-items: center;
						justify-content: space-around;

						width: 100%;
						height: 100%;

						span {
							display: flex;
							align-items: center;
							justify-content: center;

							font-size: xx-large;

							width: 100%;
							height: 100%;
						}
					}
				}

				& > .calculate {
					display: flex;
					flex-direction: column;
					align-items: center;
					gap: 8px;

					img {
						width: 40px;

						scale: .85;
					}

					& > .box {
						display: flex;
						flex-direction: column;
						gap: 8px;

						& > div {
							display: flex;
							flex-direction: row;
							gap: 8px;

							img {
								scale: .65;
								width: 42px;
							}
						}
					}

					button {
						font-size: x-large;

						width: 100%;
						height: 100%;

						padding: 10px;
					}
				}
			}
		}
	}
</css>