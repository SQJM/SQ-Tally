<import root="ui">
	<money-unit/>
</import>

<import
	root="magic-ui/ui"
>
	<module:input>
		<text-edit/>
	</module:input>
</import>

<template>
    <div #id="view">
		<div>
			<div #id="target" class="target"></div>
			<label class="money"><label class="type" #id="type"></label><span #id="money"></span><money-unit/></label>
			<text-edit #id="remark" class="remark" :readonly="true"/>
			<p #id="date" class="date"></p>
		</div>
		<button #id="edit" @click="edit">修改记录</button>
		<button #id="remove" @click="remove">删除记录</button>
    </div>
</template>

<global>
	const {
		$view,
		$target,
		$date,
		$money,
		$remark,
		$type,
		$edit
	} = $id();

	const pdv = magic.importM( "ui/pop-down-view" );

	let currentData = null;

	let currentPassword = null;
	let currentTallyId = null;
</global>

<event>
	edit = () => {
		pdv.interface.close();
		magic.importM( "ui/page/bill/edit-tally-record" ).interface.init( currentTallyId, currentPassword, currentData );
	}

	remove = () => {
		magic.importM( "ui/dialog" ).interface.init( {
			content : "不可恢复!",
			title : "是否删除该记录?",
			group : {
				"确定" : async () => {
					Page.pause();
					try {
						pdv.interface.close();
						await TallyRecord.remove( currentTallyId, currentData.id );
						Page.start();

						MagicUi.feedback.message( {
							text : `账本记录删除成功`,
							eventLevel : MagicUi.previa.feedback.message.EventLevel.pass
						} );
					} catch ( e ) {
						MagicUi.feedback.message( {
							text : `账本记录删除失败 ${ e }`,
							eventLevel : MagicUi.previa.feedback.message.EventLevel.error
						} );
					}
					return true;
				},
				"取消" : () => {
					return true;
				}
			}
		} );
	}
</event>

<interface>
	init = ( tallyId, password, id, readOnly = false ) => {
		if ( readOnly ) {
			$edit.style.display = 'none';
			$remove.style.display = 'none';
		}

		TallyRecord.getInfo( tallyId, id ).then( async o => {
			const data = JSON.parse( await Confuse.decryptString( o.data, password ) );
			pdv.interface.init( $view );
			$target.textContent = data.target;
			$type.setAttribute( "type", data.type );
			$date.textContent = WebTool.getNowFormatDate( data.time );
			$remark.interface.setValue( data.remark );
			$money.textContent = data.money;

			currentData = data;
			currentPassword = password;
			currentTallyId = tallyId;
		} );
	}
</interface>

<css scope="#id:view" default-theme>
	& {
		& > div {
			& > .money {
				text-shadow: 2px 1px #878787;

				span:last-child {
					font-family: "Verdana", "Microsoft YaHei", sans-serif;
				}
			}

			& > .target {
				border-radius: 10px;

				box-shadow: rgba(0, 0, 0, 0.16) 0px 10px 36px 0px, rgba(0, 0, 0, 0.06) 0px 0px 0px 1px;

				background-color: white;
			}

			& > .remark {
				box-shadow: rgba(14, 63, 126, 0.06) 0px 0px 0px 1px, rgba(42, 51, 70, 0.03) 0px 1px 1px -0.5px, rgba(42, 51, 70, 0.04) 0px 2px 2px -1px, rgba(42, 51, 70, 0.04) 0px 3px 3px -1.5px, rgba(42, 51, 70, 0.03) 0px 5px 5px -2.5px, rgba(42, 51, 70, 0.03) 0px 10px 10px -5px, rgba(42, 51, 70, 0.03) 0px 24px 24px -8px;
			}
		}

		.type[type="支出"] {
			color: red;
		}

		.type[type="收入"] {
			color: #00e75b;
		}

		button {
			background-color: #00e75b;
			border-radius: 20px;
		}

		button:last-child {
			background-color: #ff3c3c;
		}
	}
</css>

<css scope="#id:view">
	& {
		padding: 15px;

		.type::before {
			font-size: xxx-large;
			font-weight: bolder;
		}

		.type[type="支出"]::before {
			content: "-";
		}

		.type[type="收入"]::before {
			content: "+";
		}

		& > div {
			display: flex;
			flex-direction: column;
			gap: 25px;
			justify-content: center;
			align-items: center;

			padding: 10px;

			& > .target {
				display: flex;
				justify-content: center;
				align-items: center;

				font-size: xxx-large;

				text-align: center;

				width: 150px;
				height: 150px;
			}

			& > .date {
				margin: 4px;
			}

			& > .money {
				display: flex;
				justify-content: center;
				align-items: center;
				gap: 10px;

				text-align: center;

				* {
					height: 100%;
				}

				& > span {
					color: #111;

					font-size: xxx-large;

					text-align: center;
				}
			}

			& > .remark {
				width: 100%;
				height: 200px;
			}
		}

		button {
			width: 80%;
			height: 60px;
			text-align: center;
			position: relative;
			left: 50%;
			transform: translateX(-50%);
			padding: 10px;
			margin-top: 20px;
			font-size: x-large;
		}
	}
</css>