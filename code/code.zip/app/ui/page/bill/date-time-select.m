<import
	root="magic-ui/ui"
>
	<module:widget>
		<item/>
	</module:widget>

	<module:control>
		<list-view/>
	</module:control>
</import>

<template>
    <div #id="view">
		<list-view #id="list-1"
				   #listen:select="select"
				   :def_select="false"
				   :repetition="true"
		>
			<item target="szycfwq">
				<img class="icon" src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMjgiIGhlaWdodD0iMTI4IiB2aWV3Qm94PSIwIDAgMjQgMjQiPjxnIGZpbGw9Im5vbmUiPjxyZWN0IHdpZHRoPSIxOC41IiBoZWlnaHQ9IjcuNSIgeD0iMi43NSIgeT0iMi43NTEiIHN0cm9rZT0iIzQ3YzJmZiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjEuNSIgcng9IjIiLz48Y2lyY2xlIGN4PSI2LjI1IiBjeT0iNi41MDEiIHI9IjEuMjUiIGZpbGw9IiM0N2MyZmYiLz48Y2lyY2xlIGN4PSIxMC4yNSIgY3k9IjYuNTAxIiByPSIxLjI1IiBmaWxsPSIjNDdjMmZmIi8+PHJlY3Qgd2lkdGg9IjE4LjUiIGhlaWdodD0iNy41IiB4PSIyLjc1IiB5PSIxMy43NDkiIHN0cm9rZT0iIzQ3YzJmZiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjEuNSIgcng9IjIiLz48Y2lyY2xlIGN4PSI2LjI1IiBjeT0iMTcuNDk5IiByPSIxLjI1IiBmaWxsPSIjNDdjMmZmIi8+PGNpcmNsZSBjeD0iMTAuMjUiIGN5PSIxNy40OTkiIHI9IjEuMjUiIGZpbGw9IiM0N2MyZmYiLz48L2c+PC9zdmc+"/>
				<span>设置远程服务器</span>
				<img class="icon-arrow" src="assets/MaterialSymbolsLightArrowForwardIosRounded.svg"/>
			</item>
		</list-view>
    </div>
</template>

<global>
	const {
		$view
	} = $id();

	function select( item ) {
		magic.importM( `ui/setting/app/${ item.getAttribute( "target" ) }` );
	}
</global>

<script>
	magic.importM( "ui/pop-view", _args ).interface.init( $view, "应用设置" );
</script>

<css scope="#id:view" default-theme>
	& {
		background-color: #f2faff;
		border-radius: 20px;
		box-shadow: rgba(0, 0, 0, 0.16) 0px 1px 4px;

		& > div {
			background-color: rgba(242, 250, 255, 0.15);

			& > *[m-item] {
				background-color: rgba(255, 255, 255, 0);

				&[m-select] {
					background-color: rgba(255, 255, 255, 0);
				}

				&:active {
					background-color: rgba(0, 0, 0, 0.1);
				}
			}
		}
	}
</css>

<css scope="#id:view">
	& {
		& > div {
			width: 100%;

			& > *[m-item] {
				padding: 15px;
				display: flex;
				align-items: center;
				gap: 15px;

				& > .icon {
					width: 30px;
				}

				& > .icon-arrow {
					width: 20px;

					margin-left: auto;
				}
			}
		}
	}
</css>