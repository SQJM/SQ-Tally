<import
	root="ui"
>
	<money-unit/>
</import>

<template>
	<div #id="view">
		<div class="operation">
			<button>AI分析</button>
			<button #id="show-day" @click="dateSwitch" class="date number"></button>
			<button>表导出</button>
		</div>
		<div class="content">
			<div style="position: relative">
				<label class="switch-btn" style="position: absolute;z-index: 1;"><img class="switch-icon" src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMjgiIGhlaWdodD0iMTI4IiB2aWV3Qm94PSIwIDAgNDggNDgiPjxwYXRoIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMDAwMCIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjQiIGQ9Ik00MiAxOUg2TTMwIDdsMTIgMTJNNi43OTkgMjloMzZtLTM2IDBsMTIgMTIiLz48L3N2Zz4="><span @click="setDayWay">支出</span></label>
				<div #id="day-data" style="height: 500px;pointer-events: none"></div>
			</div>
			<div class="month">
				<div class="title">
					<label class="text"><span #id="show-month" @click="dateMonthSwitch" class="month"></span>月 收支占比</label>
					<label class="switch-btn"><img class="switch-icon" src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMjgiIGhlaWdodD0iMTI4IiB2aWV3Qm94PSIwIDAgNDggNDgiPjxwYXRoIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMDAwMCIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjQiIGQ9Ik00MiAxOUg2TTMwIDdsMTIgMTJNNi43OTkgMjloMzZtLTM2IDBsMTIgMTIiLz48L3N2Zz4="><span @click="setMonthWay">支出</span></label>
				</div>
				<div class="ratio" #id="month-ratio-data"></div>
			</div>
			<button>生成年数据</button>
		</div>
		<div #id="date-switch-content" style="display:none">
			<div #id="date-switch-element">
				<div>
					<label>年:</label>
					<button #name="year" @click="switchYear" class="number"></button>
				</div>
				<div>
					<label>月:</label>
					<button #name="month" @click="switchMonth" class="number"></button>
				</div>
				<div>
					<label>日:</label>
					<button #name="day" @click="switchDay" class="number"></button>
				</div>
			</div>
			<div #id="date-month-switch-element">
				<div>
					<label>年:</label>
					<button #name="year" @click="m_switchYear" class="number"></button>
				</div>
				<div>
					<label>月:</label>
					<button #name="month" @click="m_switchMonth" class="number"></button>
				</div>
			</div>
		</div>
	</div>
</template>

<global>
	const {
		$view,
		$dayData,
		$monthRatioData,
		$dateSwitchContent,
		$dateSwitchElement,
		$dateMonthSwitchElement,
		$showDay,
		$showMonth
	} = $id();

	let dayDataChart = echarts.init( $dayData );

	let time = Date.now();
	let current_year = WebTool.getNowFormatDate( time, "YYYY" ),
		current_month = WebTool.getNowFormatDate( time, "MM" ),
		current_day = WebTool.getNowFormatDate( time, "DD" );

	let m_time = Date.now();
	let m_current_year = WebTool.getNowFormatDate( m_time, "YYYY" ),
		m_current_month = WebTool.getNowFormatDate( m_time, "MM" );

	let currentTallyId = Setting.get( "当前账本" ),
		currentTallyPassword = Setting.get( "当前账本密码" );

	let current_day_way = "支出",
		current_month_way = "支出";

	const optionsTemplate = () => {
		return {
			title : {
				text : '',
				left : 'center'
			},
			legend : {
				top : '12%',
				left : 'center'
			},
			series : [
				{
					name : '',
					type : 'pie',
					radius : [ '30%', '70%' ],
					top: 120,
					itemStyle : {
						borderRadius : 10,
						borderColor : '#fff',
						borderWidth : 2
					},
					label : {
						show : false
					},
					data : []
				}
			]
		}
	};

	async function refresh() {
		$showDay.textContent = current_day;

		const op = await TallyRecord.getTallyRecord( Setting.get( "当前账本" ) );

		op.day( current_year, current_month, current_day ).then( async o => {
			const newOptions = optionsTemplate();
			const d = {};
			let allMoney = 0.0;
			for ( const oElement of o ) {
				const data = await Confuse.decryptString( oElement.data, currentTallyPassword );
				const obj = JSON.parse( data );
				if ( obj.type === current_day_way ) {
					if ( !d[ obj.target ] ) d[ obj.target ] = 0.0;
					d[ obj.target ] += obj.money;
				}
			}
			for ( const dKey in d ) {
				newOptions.series[ 0 ].data.push( {
					name : `${ dKey } ${ d[ dKey ] }${ ( Setting.get( "应用设置.金额单位显示" ) === Setting.FALSE )?"":MoneyUnit[ CurrentMoneyUnit ]  }`,
					value : d[ dKey ]
				} );
				allMoney += d[ dKey ];
			}
			newOptions.title.text = `${ allMoney }${ ( Setting.get( "应用设置.金额单位显示" ) === Setting.FALSE )?"":MoneyUnit[ CurrentMoneyUnit ]  }`;
			newOptions.series[ 0 ].name = `没有${ current_day_way }数据`
			dayDataChart.setOption( newOptions );
		} );
	}

	async function refreshMonth() {
		$monthRatioData.innerHTML = null;
		$showMonth.textContent = m_current_month;

		const op = await TallyRecord.getTallyRecord( Setting.get( "当前账本" ) );
		op.month( m_current_year, m_current_month ).then( async o => {
			const d = {};
			let allMoney = 0.0;
			for ( const oElement of o ) {
				const data = await Confuse.decryptString( oElement.data, currentTallyPassword );
				const obj = JSON.parse( data );
				if ( obj.type === current_month_way ) {
					if ( !d[ obj.target ] ) {
                        d[ obj.target ] = 0.0;
					}
					d[ obj.target ] += obj.money;
				}
			}

			for ( const dKey in d ) { allMoney += d[ dKey ]; }

			const arr = Object.entries(d).map(([name, value]) => ({ name, value })).sort((a, b) => b.value - a.value);
            const na = WebTool.Algorithm.calculatePercentages( arr.map(o=>o.value) , allMoney ).sort((a, b) => b - a);
            $monthRatioData.appendChild( MagicUi.createElement( {
					tagName : "p",
					attribute : [["style", `text-align: center;margin: 0px;font-size: larger;`]],
					classList : ["number"],
					text : `${allMoney} ${ ( Setting.get( "应用设置.金额单位显示" ) === Setting.FALSE )?"":MoneyUnit[ CurrentMoneyUnit ]  }`
            } ) );
            arr.forEach( ( obj , i ) =>{
                $monthRatioData.appendChild( MagicUi.createElement( {
					html : `<label class="title">${obj.name}<span class="number">${ obj.value}${ ( Setting.get( "应用设置.金额单位显示" ) === Setting.FALSE )?"":MoneyUnit[ CurrentMoneyUnit ] }</span></label><div class="progress"><div class="progress-bar"><div class="bar" style="width:${na.at(i)}%;"></div></div><label class="number">${na.at(i)}%</label></div>`
                } ) );
			});
            if(arr.length === 0)
				$monthRatioData.innerHTML = `<p style="color: #666;text-align: center">没有${current_month_way}数据</p>`;
            $monthRatioData.setAttribute("way",current_month_way);
		} );
	}
</global>

<script>
    $dayData.echarts = dayDataChart;

    if ( currentTallyId !== Setting.NOP ) {
        const p1 = refresh();
        const p2 = refreshMonth();
        Promise.all( [ p1, p2 ] );
    } else {
        $showDay.textContent = current_day;
        $showMonth.textContent = m_current_month;
        const newOptions = optionsTemplate();
        newOptions.title.text = `0${ MoneyUnit[ CurrentMoneyUnit ] }`;
        newOptions.series[ 0 ].name = `没有${ current_day_way }数据`
        dayDataChart.setOption( newOptions );
        $monthRatioData.innerHTML = `<p style="color: #666;text-align: center">没有${ current_month_way }数据</p>`;
    }

    SSEServer.register( [
        "/tally-record/remove",
        "/tally-record/update",
        "/tally-record/add"
    ], _args._file, () => {
        const p1 = refresh();
        const p2 = refreshMonth();
        Promise.all( [ p1, p2 ] );
    } );

    EventList.register( EventListName.DAY_CHANGE, _args._file, () => {
        if ( currentTallyId !== Setting.NOP ) {
            time = Date.now();
            current_year = WebTool.getNowFormatDate( time, "YYYY" );
            current_month = WebTool.getNowFormatDate( time, "MM" );
            current_day = WebTool.getNowFormatDate( time, "DD" );

            m_time = Date.now();
            m_current_year = WebTool.getNowFormatDate( m_time, "YYYY" );
            m_current_month = WebTool.getNowFormatDate( m_time, "MM" );
            const p1 = refresh();
            const p2 = refreshMonth();
            Promise.all( [ p1, p2 ] );
        }
    } );
</script>

<event>
	switchYear = async ( ev ) => {
		const button = ev.target;
		const td = await Tally.getData( currentTallyId )
		magic.importM( "ui/pop-select-list" ).interface.init( async ( target ) => {
			if ( target.textContent === "今年" )
				target.textContent = WebTool.getNowFormatDate( Date.now(), "YYYY" );
			current_year = target.textContent;
			button.textContent = target.textContent;

			const m = await td.getMonths( current_year );
			current_month = m[ 0 ];
			const d = await td.getDays( current_year, current_month );
			current_day = d[ 0 ];
			$dateSwitchElement.$name( "month" ).textContent = current_month;
			$dateSwitchElement.$name( "day" ).textContent = current_day;
			return true;
		}, [ "今年", ...await td.getYears() ] );
	}

	switchMonth = async ( ev ) => {
		const button = ev.target;
		const td = await Tally.getData( currentTallyId )
		magic.importM( "ui/pop-select-list" ).interface.init( async ( target ) => {
			if ( target.textContent === "本月" )
				target.textContent = WebTool.getNowFormatDate( Date.now(), "MM" );
			current_month = target.textContent;
			button.textContent = target.textContent;

			const d = await td.getDays( current_year, current_month );
			current_day = d[ 0 ];
			$dateSwitchElement.$name( "day" ).textContent = current_day;
			return true;
		}, [ "本月", ...await td.getMonths( current_year ) ] );
	}

	switchDay = async ( ev ) => {
		const button = ev.target;
		const td = await Tally.getData( currentTallyId )
		magic.importM( "ui/pop-select-list" ).interface.init( async ( target ) => {
			if ( target.textContent === "本日" )
				target.textContent = WebTool.getNowFormatDate( Date.now(), "DD" );
			current_day = target.textContent;
			button.textContent = target.textContent;
			return true;
		}, [ "本日", ...await td.getDays( current_year, current_month ) ] );
	}

	dateSwitch = () => {
		if ( Setting.get( "当前账本" ) === Setting.NOP ) {
			MagicUi.feedback.message( {
				text : `当前没有账本`,
				eventLevel : MagicUi.previa.feedback.message.EventLevel.warning
			} );
			return;
		}
		$dateSwitchElement.$name( "year" ).textContent = current_year;
		$dateSwitchElement.$name( "month" ).textContent = current_month;
		$dateSwitchElement.$name( "day" ).textContent = current_day;

		magic.importM( "ui/dialog" ).interface.init( {
			content : $dateSwitchElement,
			title : "选择日期",
			group : {
				"确定" : () => {
					$dateSwitchContent.appendChild( $dateSwitchElement );
					refresh();
					return true;
				},
				"取消" : () => {
					$dateSwitchContent.appendChild( $dateSwitchElement );
					return true;
				}
			}
		} );
	}

	m_switchYear = async ( ev ) => {
		const button = ev.target;
		const td = await Tally.getData( currentTallyId )
		magic.importM( "ui/pop-select-list" ).interface.init( async ( target ) => {
			if ( target.textContent === "今年" )
				target.textContent = WebTool.getNowFormatDate( Date.now(), "YYYY" );
			m_current_year = target.textContent;
			button.textContent = target.textContent;

			const m = await td.getMonths( m_current_year );
			m_current_month = m[ 0 ];
			$dateMonthSwitchElement.$name( "month" ).textContent = m_current_month;
			return true;
		}, [ "今年", ...await td.getYears() ] );
	}

	m_switchMonth = async ( ev ) => {
		const button = ev.target;
		const td = await Tally.getData( currentTallyId )
		magic.importM( "ui/pop-select-list" ).interface.init( async ( target ) => {
			if ( target.textContent === "本月" )
				target.textContent = WebTool.getNowFormatDate( Date.now(), "MM" );
			m_current_month = target.textContent;
			button.textContent = target.textContent;
			return true;
		}, [ "本月", ...await td.getMonths( current_year ) ] );
	}

	dateMonthSwitch = () => {
		if ( Setting.get( "当前账本" ) === Setting.NOP ) {
			MagicUi.feedback.message( {
				text : `当前没有账本`,
				eventLevel : MagicUi.previa.feedback.message.EventLevel.warning
			} );
			return;
		}
		$dateMonthSwitchElement.$name( "year" ).textContent = m_current_year;
		$dateMonthSwitchElement.$name( "month" ).textContent = m_current_month;

		magic.importM( "ui/dialog" ).interface.init( {
			content : $dateMonthSwitchElement,
			title : "选择月份",
			group : {
				"确定" : () => {
					$dateSwitchContent.appendChild( $dateMonthSwitchElement );
					refreshMonth();
					return true;
				},
				"取消" : () => {
					$dateSwitchContent.appendChild( $dateMonthSwitchElement );
					return true;
				}
			}
		} );
	}

	setDayWay = ( ev ) => {
		const target = ev.target;
		if ( current_day_way === "支出" ) current_day_way = "收入"; else current_day_way = "支出";
		target.textContent = current_day_way;
		refresh();
	}

	setMonthWay = ( ev ) => {
		const target = ev.target;
		if ( current_month_way === "支出" ) current_month_way = "收入"; else current_month_way = "支出";
		target.textContent = current_month_way;
		refreshMonth();
	}
</event>

<interface once>
	init = () => {
		setTimeout( () => {
			dayDataChart.resize();
		}, 250 );
	}
</interface>

<css scope="#id:date-switch-element">
	& {
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
		gap: 15px;

		padding: 10px;

		font-size: large;

		div {
			display: flex;
			align-items: center;
			justify-content: center;
			gap: 8px;

			button {
				min-width: 100px;
				display: flex;
				align-items: center;
				justify-content: center;
				text-align: center;
				font-size: large;
				padding: 10px;
				border: none;
				border-radius: 10px;
				box-shadow: rgba(50, 50, 93, 0.25) 0px 2px 5px -1px, rgba(0, 0, 0, 0.3) 0px 1px 3px -1px;
			}
		}
	}
</css>

<css scope="#id:date-month-switch-element">
	& {
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
		gap: 15px;

		padding: 10px;

		font-size: large;

		div {
			display: flex;
			align-items: center;
			justify-content: center;
			gap: 8px;

			button {
				min-width: 100px;
				display: flex;
				align-items: center;
				justify-content: center;
				text-align: center;
				font-size: large;
				padding: 10px;
				border: none;
				border-radius: 10px;
				box-shadow: rgba(50, 50, 93, 0.25) 0px 2px 5px -1px, rgba(0, 0, 0, 0.3) 0px 1px 3px -1px;
			}
		}
	}
</css>

<css scope="#id:view" default-theme>
	& {
		.operation {
			background-color: #00e75b;
			border-radius: 0 0 30px 30px;

			box-shadow: rgba(50, 50, 93, 0.25) 0px 2px 5px -1px, rgba(0, 0, 0, 0.3) 0px 1px 3px -1px;

			animation: appear-from-top-to-bottom .5s;

			button,
			.date {
				border: none;

				border-radius: 10px;

				box-shadow: rgba(50, 50, 93, 0.25) 0px 2px 5px -1px, rgba(0, 0, 0, 0.3) 0px 1px 3px -1px;
			}

			.date {
				border-radius: 90px;
			}
		}

		.content {
			animation: appear-opacity 1s;

			button {
				background-color: #00e75b;
				border-radius: 20px;
			}

			.month {
				.title {
					.text {
						.month {
							background-color: #ffffff;
							box-shadow: rgb(0 0 0 / 12%) 0px 10px 36px 0px, rgba(0, 0, 0, 0.06) 0px 0px 0px 1px;
							border-radius: 15px;
						}
					}
				}

				.ratio {

					& > div {
						border-radius: 10px;

						box-shadow: rgba(0, 0, 0, 0.11) 0px 1px 3px, rgba(0, 0, 0, 0.22) 0px 1px 2px;

						.title {

						}

						.progress {
							.progress-bar {
								border-radius: 10px;

								background-color: #d0d0d0;

								.bar {
									background-color: #29e072;

									animation: an-1 1.5s;
								}
							}

							.number {

							}
						}
					}

					&[way="支出"] {
						& > div {
							.progress {
								.progress-bar {
									.bar {
										background-color: #f05656;
									}
								}
							}
						}
					}
				}
			}
		}
	}
</css>

<css scope="#id:view">
	& {
		display: flex;
		flex-direction: column;

		width: 100%;
		height: 100%;

		.switch-btn {
			display: flex;
			align-items: center;
			justify-content: center;
			gap: 4px;
			position: relative;
			right: 20px;

			.switch-icon {
				height: 18px;
				position: absolute;
				bottom: -18px;
				pointer-events: none;

				opacity: .65;
			}
		}

		.operation {
			display: flex;
			align-items: center;
			justify-content: space-around;

			height: 110px;

			button {
				display: flex;
				align-items: center;
				justify-content: center;

				text-align: center;

				padding: 10px;

				min-width: 80px;
			}

			.date {
				width: 75px;
				height: 75px;
				min-width: 75px;

				font-size: x-large;
			}
		}

		.content {
			padding: 20px;

			width: 100%;
			height: 100%;

			overflow: auto;

			button {
				width: 80%;
				height: 60px;
				text-align: center;
				position: relative;
				left: 50%;
				transform: translateX(-50%);
				padding: 10px;
				margin-top: 20px;
				font-size: x-large;
			}

			.month {
				.title {
					display: flex;
					align-items: center;
					justify-content: space-between;

					.text {
						display: flex;
						align-items: center;
						gap: 10px;

						.month {
							display: flex;
							align-items: center;
							justify-content: center;

							font-size: x-large;

							padding: 10px;

							width: 50px;
							height: 50px;
						}
					}
				}

				.ratio {
					display: flex;
					flex-direction: column;
					gap: 20px;

					padding: 5px 10px 10px 10px;

					min-height: 200px;

					& > div {
						display: flex;
						flex-direction: column;

						padding: 10px;

						.title {
							display: flex;
							align-items: center;
							justify-content: space-between;

							span {
								margin-right: 70px;
							}
						}

						.progress {
							display: flex;
							flex-direction: row;
							align-items: center;

							.progress-bar {
								position: relative;

								overflow: hidden;

								width: 100%;
								min-height: 8px;
								max-height: 8px;

								.bar {
									min-height: 8px;
								}
							}

							.number {
								position: relative;
								top: -15px;
								text-align: right;
								min-width: 70px;
							}
						}
					}
				}
			}
		}
	}
</css>