<import
	root="ui"
>
	<money-unit/>
</import>

<import
	root="magic-ui/ui"
>
	<module:widget>
		<item/>
	</module:widget>

	<module:control>
		<list-view/>
	</module:control>
</import>

<template>
	<div #id="view">
		<div class="operation">
			<img #id="head-img" class="head"/>
			<p #id="user-name" class="name">Magic Tally</p>
		</div>
		<div class="info-box"></div>
		<div class="list">
			<list-view #id="list-0"
					   #listen:select="set1_select"
					   :def_select="false"
					   :repetition="true"
			>
				<item data="0">
					<img class="icon" src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMjgiIGhlaWdodD0iMTI4IiB2aWV3Qm94PSIwIDAgMTYgMTYiPjxwYXRoIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzhhYWRmNCIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBkPSJNNS41IDcuNXYybTEwLS41VjdtLTUgLjV2Mk0uNSA5VjdtOC0zLjV2LTJINi41Mm0tNC4wMiAyaDExYTEgMSAwIDAgMSAxIDF2OWExIDEgMCAwIDEtMSAxaC0xMWExIDEgMCAwIDEtMS0xdi05YTEgMSAwIDAgMSAxLTEiLz48L3N2Zz4="/>
					<span>AI 管理</span>
					<img class="icon-arrow" src="assets/MaterialSymbolsLightArrowForwardIosRounded.svg"/>
				</item>
				<item data="1">
					<img class="icon" src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMjgiIGhlaWdodD0iMTI4IiB2aWV3Qm94PSIwIDAgNzIgNzIiPjxwYXRoIGZpbGw9IiNGQ0VBMkIiIGQ9Ik02MC4xIDU3LjA4Yy41NjMgMCAxLjAyLS40NTggMS4wMi0xLjAyMlYxMi4wMzRjMC0uNTY0LS40NTctMS4wMjItMS4wMi0xLjAyMkgxNi4xNzhjLS41NjMgMC0xLjAyLjQ1OC0xLjAyIDEuMDIydjI3LjEyOUw1MS4yMiA1Ny4wOHoiLz48cGF0aCBmaWxsPSIjRkNFQTJCIiBkPSJNNjAuMTIxIDU2LjAxMmExIDEgMCAwIDAgLjk5OS0uOTk4VjEyLjAxYTEgMSAwIDAgMC0uOTk5LS45OTlIMTcuMTE4YTEgMSAwIDAgMC0uOTk4Ljk5OXY0NC4wMDF6Ii8+PHBhdGggZmlsbD0iI0ZDRUEyQiIgZD0iTTE2LjEyIDEyLjAxYzAtLjU1LjQ0Ny0uOTk4Ljk5OC0uOTk4aDQzLjAwM2MuNTUyIDAgLjk5OS40NDcuOTk5Ljk5OXY0My4wMDNhMSAxIDAgMCAxLS45OTkuOTk4Ii8+PHBhdGggZmlsbD0iI0YxQjMxQyIgZD0iTTU1LjEzNCA2MUgxMi4xM2ExIDEgMCAwIDEtLjk5OS0uOTk4VjE2Ljk5OEExIDEgMCAwIDEgMTIuMTMgMTZoNDMuMDAzYy41NTEgMCAuOTk4LjQ0Ny45OTguOTk5djQzLjAwM2ExIDEgMCAwIDEtLjk5OC45OTgiLz48ZyBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIgc3Ryb2tlLW1pdGVybGltaXQ9IjEwIiBzdHJva2Utd2lkdGg9IjIiPjxwYXRoIGQ9Ik0xNi4xMiAxMi4wMWMwLS41NS40NDctLjk5OC45OTgtLjk5OGg0My4wMDNjLjU1MiAwIC45OTkuNDQ3Ljk5OS45OTl2NDMuMDAzYTEgMSAwIDAgMS0uOTk5Ljk5OCIvPjxwYXRoIGQ9Ik01NS4xMzQgNjFIMTIuMTNhMSAxIDAgMCAxLS45OTktLjk5OFYxNi45OThBMSAxIDAgMCAxIDEyLjEzIDE2aDQzLjAwM2MuNTUxIDAgLjk5OC40NDcuOTk4Ljk5OXY0My4wMDNhMSAxIDAgMCAxLS45OTguOTk4TTcgMjMuNDExaDguNzEyTTcgMjkuNDQ3aDguNzEyTTcgMzUuNDgyaDguNzEybTAgNi4wMzZIN20wIDYuMDM1aDguNzEyTTcgNTMuNTg5aDguNzEyIi8+PC9nPjwvc3ZnPg=="/>
					<span>账本管理</span>
					<img class="icon-arrow" src="assets/MaterialSymbolsLightArrowForwardIosRounded.svg"/>
				</item>
				<item data="2">
					<img class="icon" src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMjgiIGhlaWdodD0iMTI4IiB2aWV3Qm94PSIwIDAgMTYgMTYiPjxwYXRoIGZpbGw9IiM0N2MyZmYiIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTQgNi41YTEuNSAxLjUgMCAxIDAgMC0zYTEuNSAxLjUgMCAwIDAgMCAzTTcgNWEzIDMgMCAwIDEtLjg3IDIuMTEzQTQgNCAwIDAgMSA4IDEwLjVWMTJhMiAyIDAgMCAxLTIgMkgyYTIgMiAwIDAgMS0yLTJ2LTEuNWMwLTEuNDI3Ljc0Ny0yLjY3OSAxLjg3LTMuMzg3QTMgMyAwIDEgMSA3IDVtLTUuNSA1LjVhMi41IDIuNSAwIDAgMSA1IDBWMTJhLjUuNSAwIDAgMS0uNS41SDJhLjUuNSAwIDAgMS0uNS0uNXptMTIuMjUxLTcuMTY1Yy4yMS4xMjIuNDYyLjE2My42ODUuMDdsLjMxMy0uMTMzYS41LjUgMCAwIDEgLjYyOC4yMWwuMzA4LjUzNWEuNS41IDAgMCAxLS4xMy42NDlsLS4yNzIuMjA1Yy0uMTkzLjE0Ni0uMjgzLjM4Ny0uMjgzLjYyOXMuMDkuNDgzLjI4My42MjlsLjI3MS4yMDVhLjUuNSAwIDAgMSAuMTMxLjY0OWwtLjMwOC41MzRhLjUuNSAwIDAgMS0uNjI4LjIxbC0uMzEzLS4xMzFjLS4yMjMtLjA5NC0uNDc1LS4wNTMtLjY4NS4wNjljLS4yMDkuMTIxLS4zNzQuMzItLjQwNC41NmwtLjA0Mi4zMzdhLjUuNSAwIDAgMS0uNDk2LjQzOGgtLjYxOGEuNS41IDAgMCAxLS40OTYtLjQzOGwtLjA0Mi0uMzM3Yy0uMDMtLjI0LS4xOTUtLjQzOS0uNDA0LS41NnMtLjQ2Mi0uMTYzLS42ODUtLjA3bC0uMzEzLjEzM2EuNS41IDAgMCAxLS42MjgtLjIxbC0uMzA4LS41MzVhLjUuNSAwIDAgMSAuMTMtLjY0OWwuMjcyLS4yMDVDOS45MSA1Ljk4MyAxMCA1Ljc0MiAxMCA1LjVzLS4wOS0uNDgzLS4yODMtLjYyOWwtLjI3MS0uMjA1YS41LjUgMCAwIDEtLjEzMS0uNjQ5bC4zMDgtLjUzNGEuNS41IDAgMCAxIC42MjgtLjIxbC4zMTMuMTMxYy4yMjMuMDk0LjQ3NS4wNTMuNjg1LS4wNjljLjIwOS0uMTIxLjM3NC0uMzIuNDA0LS41NmwuMDQyLS4zMzdBLjUuNSAwIDAgMSAxMi4xOTEgMmguNjE4YS41LjUgMCAwIDEgLjQ5Ni40MzhsLjA0Mi4zMzdjLjAzLjI0LjE5NS40MzkuNDA0LjU2TTEzLjUgNS41YTEgMSAwIDEgMS0yIDBhMSAxIDAgMCAxIDIgMCIgY2xpcC1ydWxlPSJldmVub2RkIi8+PC9zdmc+"/>
					<span>账户管理</span>
					<img class="icon-arrow" src="assets/MaterialSymbolsLightArrowForwardIosRounded.svg"/>
				</item>
				<item data="3">
					<img class="icon" src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMjgiIGhlaWdodD0iMTI4IiB2aWV3Qm94PSIwIDAgMjQgMjQiPjxwYXRoIGZpbGw9IiM0N2MyZmYiIGQ9Im0xMC43IDE1LjVsLjE1LjcyNXEuMDc1LjM1LjMzOC41NjNUMTEuOCAxN2guNHEuMzUgMCAuNjEzLS4yMjV0LjMzNy0uNTc1bC4xNS0uN3EuMy0uMTI1LjU2My0uMjYydC41MzctLjMzOGwuNzI1LjIyNXEuMzI1LjEuNjM4LS4wMjV0LjQ4Ny0uNGwuMi0uMzVxLjE3NS0uMy4xMjUtLjY1dC0uMzI1LS41NzVsLS41NS0uNDc1cS4wNS0uMzUuMDUtLjY1dC0uMDUtLjY1bC41NS0uNDc1cS4yNzUtLjIyNS4zMjUtLjU2MnQtLjEyNS0uNjM4bC0uMjI1LS4zNzVxLS4xNzUtLjI3NS0uNDc1LS40dC0uNjI1LS4wMjVMMTQuNCA5LjFxLS4yNzUtLjItLjUzOC0uMzM3VDEzLjMgOC41bC0uMTUtLjcyNXEtLjA3NS0uMzUtLjMzNy0uNTYyVDEyLjIgN2gtLjRxLS4zNSAwLS42MTIuMjI1dC0uMzM4LjU3NWwtLjE1LjdxLS4zLjEyNS0uNTYyLjI2M1Q5LjYgOS4xbC0uNzI1LS4yMjVxLS4zMjUtLjEtLjYzNy4wMjV0LS40ODguNGwtLjIuMzVxLS4xNzUuMy0uMTI1LjY1dC4zMjUuNTc1bC41NS40NzVxLS4wNS4zNS0uMDUuNjV0LjA1LjY1bC0uNTUuNDc1cS0uMjc1LjIyNS0uMzI1LjU2M3QuMTI1LjYzN2wuMjI1LjM3NXEuMTc1LjI3NS40NzUuNHQuNjI1LjAyNUw5LjYgMTQuOXEuMjc1LjIuNTM4LjMzOHQuNTYyLjI2Mk0xMiAxNHEtLjgyNSAwLTEuNDEyLS41ODdUMTAgMTJ0LjU4OC0xLjQxMlQxMiAxMHQxLjQxMy41ODhUMTQgMTJ0LS41ODcgMS40MTNUMTIgMTRtLTcgN3EtLjgyNSAwLTEuNDEyLS41ODdUMyAxOVY1cTAtLjgyNS41ODgtMS40MTJUNSAzaDE0cS44MjUgMCAxLjQxMy41ODhUMjEgNXYxNHEwIC44MjUtLjU4NyAxLjQxM1QxOSAyMXptMC0yaDE0VjVINXpNNSA1djE0eiIvPjwvc3ZnPg=="/>
					<span>应用设置</span>
					<img class="icon-arrow" src="assets/MaterialSymbolsLightArrowForwardIosRounded.svg"/>
				</item>
			</list-view>
			<list-view #id="list-1"
					   #listen:select="set2_select"
					   :def_select="false"
					   :repetition="true"
			>
				<item data="a0">
					<img class="icon" src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMjgiIGhlaWdodD0iMTI4IiB2aWV3Qm94PSIwIDAgNTEyIDUxMiI+PHBhdGggZmlsbD0iIzQ3YzJmZiIgZmlsbC1ydWxlPSJldmVub2RkIiBkPSJNMjU2IDQyLjY2N2MxMTcuODIyIDAgMjEzLjMzNCA5NS41MTIgMjEzLjMzNCAyMTMuMzMzYzAgMTE3LjgyLTk1LjUxMiAyMTMuMzM0LTIxMy4zMzQgMjEzLjMzNGMtMTE3LjgyIDAtMjEzLjMzMy05NS41MTMtMjEzLjMzMy0yMTMuMzM0UzEzOC4xOCA0Mi42NjcgMjU2IDQyLjY2N20yMS4zOCAxOTJoLTQyLjY2NnYxMjhoNDIuNjY2ek0yNTYuMjE3IDE0NGMtMTUuNTU0IDAtMjYuODM3IDExLjIyLTI2LjgzNyAyNi4zNzFjMCAxNS43NjQgMTAuOTg2IDI2Ljk2MyAyNi44MzcgMjYuOTYzYzE1LjIzNSAwIDI2LjQ5Ny0xMS4yIDI2LjQ5Ny0yNi42NjdjMC0xNS40NDYtMTEuMjYyLTI2LjY2Ny0yNi40OTctMjYuNjY3Ii8+PC9zdmc+"/>
					<span>关于 神奇账本</span>
					<img class="icon-arrow" src="assets/MaterialSymbolsLightArrowForwardIosRounded.svg"/>
				</item>
				<item data="a1">
					<img class="icon" src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMjgiIGhlaWdodD0iMTI4IiB2aWV3Qm94PSIwIDAgMjQgMjQiPjxwYXRoIGZpbGw9IiM0N2MyZmYiIGQ9Ik0xNyAyMnEtMS4yNSAwLTIuMTI1LS44NzVUMTQgMTlxMC0uMTUuMDc1LS43TDcuMDUgMTQuMnEtLjQuMzc1LS45MjUuNTg4VDUgMTVxLTEuMjUgMC0yLjEyNS0uODc1VDIgMTJ0Ljg3NS0yLjEyNVQ1IDlxLjYgMCAxLjEyNS4yMTN0LjkyNS41ODdsNy4wMjUtNC4xcS0uMDUtLjE3NS0uMDYyLS4zMzdUMTQgNXEwLTEuMjUuODc1LTIuMTI1VDE3IDJ0Mi4xMjUuODc1VDIwIDV0LS44NzUgMi4xMjVUMTcgOHEtLjYgMC0xLjEyNS0uMjEzVDE0Ljk1IDcuMmwtNy4wMjUgNC4xcS4wNS4xNzUuMDYzLjMzOFQ4IDEydC0uMDEyLjM2M3QtLjA2My4zMzdsNy4wMjUgNC4xcS40LS4zNzUuOTI1LS41ODdUMTcgMTZxMS4yNSAwIDIuMTI1Ljg3NVQyMCAxOXQtLjg3NSAyLjEyNVQxNyAyMiIvPjwvc3ZnPg=="/>
					<span>分享本应用</span>
					<img class="icon-arrow" src="assets/MaterialSymbolsLightArrowForwardIosRounded.svg"/>
				</item>
				<item data="a2">
					<img class="icon" src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMjgiIGhlaWdodD0iMTI4IiB2aWV3Qm94PSIwIDAgNDggNDgiPjxnIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwZTY4MiIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIgc3Ryb2tlLXdpZHRoPSI0Ij48cGF0aCBkPSJNNCAxNGEyIDIgMCAwIDEgMi0yaDM2YTIgMiAwIDAgMSAyIDJ2MjZhMiAyIDAgMCAxLTIgMkg2YTIgMiAwIDAgMS0yLTJ6Ii8+PHBhdGggc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBkPSJtMTkgMTlsNSA1bDUtNW0tMTEgNmgxMm0tMTIgNmgxMm0tNi02djEwTTggNmgzMiIvPjwvZz48L3N2Zz4="/>
					<span>成为赞助商获得功能升级</span>
					<img class="icon-arrow" src="assets/MaterialSymbolsLightArrowForwardIosRounded.svg"/>
				</item>
			</list-view>
		</div>
	</div>
</template>

<global>
	const {
		$list0,
		$list1,
		$userName,
		$headImg
	} = $id();

	function set1_select( item ) {
		const data = item.getAttribute( "data" );
		const arg = magic.createArgs( { rect : item.getBoundingClientRect() } );

		if ( data === "0" ) {
			magic.importM( "ui/setting/ai", arg );
		} else if ( data === "1" ) {
			magic.importM( "ui/setting/tally", arg );
		} else if ( data === "2" ) {
			magic.importM( "ui/setting/account", arg );
		} else if ( data === "3" ) {
			magic.importM( "ui/setting/app", arg );
		}
	}

	function set2_select( item ) {
		const data = item.getAttribute( "data" );
		const arg = magic.createArgs( { rect : item.getBoundingClientRect() } );

		if ( data === "a0" ) {
			magic.importM( "ui/setting/about", arg );
		} else if ( data === "a1" ) {

		} else if ( data === "a2" ) {
			magic.importM( "ui/page/my/update-function", arg );
		}
	}

	const headObj = {
		0 : "BiEmojiSmileUpsideDownFill.svg",
		1 : "BiEmojiWinkFill.svg",
		2 : "CryptocurrencyColorJpy.svg",
		3 : "FluentEmojiFlatRabbit.svg",
		4 : "FluentEmojiSmileSlight20Filled.svg",
		5 : "FluentEmojiSparkle32Filled.svg",
		6 : "FxemojiHamburger.svg",
		7 : "FxemojiSparklingheart.svg",
		8 : "NotoCatFace.svg",
		9 : "NotoFriedShrimp.svg",
		10 : "NotoHotDog.svg",
		11 : "NotoMeatOnBone.svg",
		12 : "TwemojiBread.svg"
	};

	const upHeadImg = ( () => {
		let remainingHeads = [];

		return function () {
			if ( remainingHeads.length === 0 ) {
				remainingHeads = Array.from( { length : 13 }, ( _, i ) => i );
			}

			const randomIndex = Math.floor( Math.random() * remainingHeads.length );
			const selected = remainingHeads.splice( randomIndex, 1 )[ 0 ];

			$headImg.src = "assets/head/" + headObj[ selected ];
		};
	} )();
</global>

<script>
	upHeadImg();
    setInterval( () => upHeadImg(), 5000 );

    $userName.textContent = Setting.get( "用户名" );

    EventList.register( EventListName.SETTINGS_CHANGE, _args._file, ( opr, t ) => {
        if ( opr === "set" && t === "用户名" ) $userName.textContent = Setting.get( "用户名" );
    } );
</script>

<css scope="#id:view" default-theme>
	& {
		.operation {
			background-color: #00e75b;
			border-radius: 0 0 30px 30px;

			box-shadow: rgba(50, 50, 93, 0.25) 0px 2px 5px -1px, rgba(0, 0, 0, 0.3) 0px 1px 3px -1px;

			animation: appear-from-top-to-bottom .5s;

			.head {
				border-radius: 90px;
				border: solid 2px #fff;
			}
		}

		.info-box {
			animation: appear-opacity .5s;
			background-color: #ffffff;
			border-radius: 20px;
			box-shadow: rgba(0, 0, 0, 0.02) 0px 1px 3px 0px, rgba(27, 31, 35, 0.15) 0px 0px 0px 1px;
		}

		.list {
			animation: appear-opacity .5s;
			background-color: #f2faff;
			border-radius: 20px;
			box-shadow: rgba(0, 0, 0, 0.16) 0px 1px 4px;

			& > div {
				background-color: rgba(242, 250, 255, 0.15);

				& > *[m-item] {
					background-color: rgba(255, 255, 255, 0);

					&:active {
						background-color: rgba(0, 0, 0, 0.1);
					}
				}
			}
		}
	}
</css>

<css scope="#id:view">
	& {
		display: flex;
		flex-direction: column;

		width: 100%;
		height: 100%;

		position: relative;

		& > div {
			flex: 0 auto;
		}

		.operation {
			display: flex;
			align-items: center;
			flex-direction: column;

			height: 250px;

			.head {
				width: 90px;
				height: 90px;
			}

			.name {
				margin: 10px 0 10px 0;

				font-size: 30px;
			}
		}

		.info-box {
			z-index: 10;

			width: 90%;
			max-width: 320px;
			height: 90px;

			position: absolute;
			top: 145px;
			left: 50%;
			transform: translateX(-50%);
		}

		.list {
			display: flex;
			flex-direction: column;
			gap: 20px;

			margin: 80px auto 20px;

			width: 90%;
			height: calc(100% - 100px);

			overflow: auto;

			& > div {
				width: 100%;

				& > *[m-item] {
					padding: 15px;
					display: flex;
					align-items: center;
					gap: 15px;

					& > .icon {
						width: 30px;
					}

					& > .icon-arrow {
						width: 20px;

						margin-left: auto;
					}
				}
			}
		}
	}
</css>