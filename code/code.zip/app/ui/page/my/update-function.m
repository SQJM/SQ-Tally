<import
	root="magic-ui/ui"
>
	<module:widget>
		<item/>
	</module:widget>

	<module:control>
		<list-view/>
	</module:control>
</import>

<import
	root="ui"
>
	<money-unit/>
</import>

<template>
    <div #id="view">
		<list-view #id="list-1"
				   #listen:select="select"
				   :def_select="false"
				   :repetition="true"
		>
			<item target="week">
				<img class="icon" src="assets/FormkitWeek.svg"/>
				<span>7天<p><del>12</del><em>5</em><money-unit/></p></span>
				<img class="icon-arrow" src="assets/MaterialSymbolsLightArrowForwardIosRounded.svg"/>
			</item>
			<item target="month">
				<img class="icon" src="assets/IwwaMonth.svg"/>
				<span>30天<p><del>32</del><em>12</em><money-unit/></p></span>
				<img class="icon-arrow" src="assets/MaterialSymbolsLightArrowForwardIosRounded.svg"/>
			</item>
			<item target="year">
				<img class="icon" src="assets/FluentMdl2CalendarYear.svg"/>
				<span>365天<p><del>158</del><em>68</em><money-unit/></p></span>
				<img class="icon-arrow" src="assets/MaterialSymbolsLightArrowForwardIosRounded.svg"/>
			</item>
		</list-view>
    </div>
</template>

<global>
	const {
		$view
	} = $id();

	function select( item ) {
		const t = item.getAttribute( "target" );
		const o = {
			day : 0,
			money : 0
		};
		if ( t === "week" ) {
			o.day = 7;
			o.money = 5;
		} else if ( t === "month" ) {
			o.day = 30;
			o.money = 12;
		} else if ( t === "year" ) {
			o.day = 365;
			o.money = 68;
		}
		magic.importM( `ui/setting/buy-server/xdym` ).interface.init( o );
	}
</global>

<script>
	magic.importM( "ui/pop-view", _args ).interface.init( $view, "功能升级" );
</script>

<css scope="#id:view" default-theme>
	& {
		background-color: #f2faff;
		border-radius: 20px;
		box-shadow: rgba(0, 0, 0, 0.16) 0px 1px 4px;

		& > div {
			background-color: rgba(242, 250, 255, 0.15);

			& > *[m-item] {
				background-color: rgba(255, 255, 255, 0);

				&[m-select] {
					background-color: rgba(255, 255, 255, 0);
				}

				&:active {
					background-color: rgba(0, 0, 0, 0.1);
				}

				& > span {
					& > p > span {
						color: #505050;
					}
				}
			}
		}
	}
</css>

<css scope="#id:view">
	& {
		display: none;

		& > div {
			width: 100%;

			& > *[m-item] {
				padding: 15px;
				display: flex;
				align-items: center;
				gap: 15px;

				& > span {
					display: flex;
					align-items: center;
					justify-content: space-between;

					padding-left: 10px;

					width: 100%;

					& > p {
						margin: 0;
						display: flex;
						align-items: center;
						gap: 5px;

						em {
							font-size: 28px;
							padding: 2px 4px 2px 4px;
						}
					}
				}

				& > .icon {
					width: 30px;
				}

				& > .icon-arrow {
					width: 20px;

					margin-left: auto;
				}
			}
		}
	}
</css>