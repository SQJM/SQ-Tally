<import
	root="ui"
>
	<money-unit/>
</import>

<import
	root="magic-ui/ui"
>
	<module:widget>
		<item/>
	</module:widget>

	<module:control>
		<list-view/>
	</module:control>
</import>

<template>
	<div #id="view">
		<img @click="ai" class="ai-tally-button" src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMjgiIGhlaWdodD0iMTI4IiB2aWV3Qm94PSIwIDAgMjQgMjQiPjxnIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzQ3YzJmZiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjEuNSIgY29sb3I9IiM0N2MyZmYiPjxwYXRoIGQ9Ik0xNC4xNyAyMC44OWM0LjE4NC0uMjc3IDcuNTE2LTMuNjU3IDcuNzktNy45Yy4wNTMtLjgzLjA1My0xLjY5IDAtMi41MmMtLjI3NC00LjI0Mi0zLjYwNi03LjYyLTcuNzktNy44OTlhMzMgMzMgMCAwIDAtNC4zNCAwYy00LjE4NC4yNzgtNy41MTYgMy42NTctNy43OSA3LjlhMjAgMjAgMCAwIDAgMCAyLjUyYy4xIDEuNTQ1Ljc4MyAyLjk3NiAxLjU4OCA0LjE4NGMuNDY3Ljg0NS4xNTkgMS45LS4zMjggMi44MjNjLS4zNS42NjUtLjUyNi45OTctLjM4NSAxLjIzN2MuMTQuMjQuNDU1LjI0OCAxLjA4NC4yNjNjMS4yNDUuMDMgMi4wODQtLjMyMiAyLjc1LS44MTNjLjM3Ny0uMjc5LjU2Ni0uNDE4LjY5Ni0uNDM0cy4zODcuMDkuODk5LjNjLjQ2LjE5Ljk5NS4zMDcgMS40ODUuMzRjMS40MjUuMDk0IDIuOTE0LjA5NCA0LjM0MiAwIi8+PHBhdGggZD0ibTcuNSAxNWwxLjg0Mi01LjUyNmEuNjk0LjY5NCAwIDAgMSAxLjMxNiAwTDEyLjUgMTVtMy02djZtLTctMmgzIi8+PC9nPjwvc3ZnPg=="/>
		<img @click="addTally" class="add-tally-button" src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMjgiIGhlaWdodD0iMTI4IiB2aWV3Qm94PSIwIDAgMjQgMjQiPjxwYXRoIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwZTY4MiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2Utd2lkdGg9IjEuNSIgZD0iTTE1IDEyaC0zbTAgMEg5bTMgMFY5bTAgM3YzTTcgMy4zMzhBOS45NSA5Ljk1IDAgMCAxIDEyIDJjNS41MjMgMCAxMCA0LjQ3NyAxMCAxMHMtNC40NzcgMTAtMTAgMTBTMiAxNy41MjMgMiAxMmMwLTEuODIxLjQ4Ny0zLjUzIDEuMzM4LTUiLz48L3N2Zz4="/>
		<div class="operation">
			<p #id="year" @click="switchYear" class="year number">2025</p>
			<p #id="month" @click="switchMonth" class="month number">2</p>
			<button #id="select-tally-book" @click="switchTally" class="select-tally-book"></button>
		</div>
		<div class="info-data">
			<div @click="lookMonthData" class="expenditure">
				<p>月支出</p>
				<div class="box">
					<money-unit/>
					<span #id="expenditure" class="number">0</span>
				</div>
			</div>
			<div @click="lookMonthData" class="income">
				<p>月收入</p>
				<div class="box">
					<money-unit/>
					<span #id="income" class="number">0</span>
				</div>
			</div>
		</div>
		<div class="to-day-data">
			<label #id="day" @click="switchDay" class="number"></label>
			<div @click="lookDayData">
				<label style="background-color: red;color: white">支</label>
				<span #id="to-day-z" class="number">0</span>
				<label style="background-color: #00d98d;color: white">收</label>
				<span #id="to-day-s" class="number">0</span>
			</div>
		</div>
		<list-view #id="tally-list" #listen:select="tallyListSelect" :repetition="true" class="tally"></list-view>
	</div>
</template>

<global>
	const {
		$expenditure,
		$income,
		$selectTallyBook,
		$year,
		$month,
		$day,
		$tallyList,
		$toDayZ,
		$toDayS
	} = $id();

	let time = Date.now();

	let current_year = WebTool.getNowFormatDate( time, "YYYY" ),
		current_month = WebTool.getNowFormatDate( time, "MM" ),
		current_day = WebTool.getNowFormatDate( time, "DD" );

	let currentTallyId = Setting.get( "当前账本" ),
		currentTallyPassword = Setting.get( "当前账本密码" );

	async function refresh() {
        $year.textContent = current_year;
        $month.textContent = current_month;
        $day.textContent = current_day;

        if(currentTallyId === Setting.NOP) return;

        currentTallyId = Setting.get( "当前账本" );
		currentTallyPassword = Setting.get( "当前账本密码" );

		const op = await TallyRecord.getTallyRecord( currentTallyId );

        let dZ = 0,dS = 0;
        let mZ = 0,mS = 0;

		op.month( current_year, current_month ).then( o => {
			o.forEach(async o => {
                const data = await Confuse.decryptString(o.data,currentTallyPassword);
                const obj = JSON.parse(data);
                if(o.type === "支出"){
                    mZ += obj.money;
				} else {
                    mS += obj.money;
				}
                $expenditure.textContent = mZ;
                $income.textContent = mS;
			} );
		} );
		op.day( current_year, current_month, current_day ).then(async o => {
			$tallyList.interface.clear();
            for (const oElement of o) {
                const data = await Confuse.decryptString(oElement.data,currentTallyPassword);
                const obj = JSON.parse(data);
				const item = magic.importM( "magic-ui/ui/widget/item" );
				item.setAttribute( "id", oElement.id );
				item.setAttribute( "state", oElement.type );
                if(oElement.type === "支出"){
                    dZ += obj.money;
				} else {
                    dS += obj.money;
				}
                if(obj.remark === "")
					item.innerHTML = `<div class="info"><label class="target">${obj.target}</label></div><span class="money number">${obj.money}</span>`;
				else
					item.innerHTML = `<div class="info"><label class="target">${obj.target}</label><label class="remark">${obj.remark}</label></div><span class="money number">${obj.money}</span>`;
                $tallyList.appendChild( item );
                $toDayZ.textContent = dZ;
                $toDayS.textContent = dS;
            }
		} );
        $toDayZ.textContent = dZ;
        $toDayS.textContent = dS;
	}

    function tallyListSelect(item) {
        const id = item.getAttribute("id");
		magic.importM("ui/page/bill/tally-record-data").interface.init(currentTallyId,currentTallyPassword,id);
    }
</global>

<script>
    if ( currentTallyId !== Setting.NOP ) {
        Tally.getInfo( currentTallyId ).then( o => {
            if ( !o ) {
                Setting.set( "当前账本", Setting.NOP );
                Setting.set( "当前账本密码", Setting.NOP );
                $selectTallyBook.textContent = "没有账本";
                return;
            }
            $selectTallyBook.textContent = o.name;
        } );
    } else {
        $selectTallyBook.textContent = "没有账本";
    }
    EventList.register( EventListName.SETTINGS_CHANGE, _args._file, ( opr, k, v ) => {
        if ( opr === "set" && k === "当前账本" ) {
            if ( v !== Setting.NOP )
                Tally.getInfo( Setting.get( "当前账本" ) ).then( o => {
                    $selectTallyBook.textContent = o.name;
                } );
            else {
                $selectTallyBook.textContent = "没有账本";
                currentTallyId = Setting.NOP
            }
        }
    } );

    EventList.register( EventListName.TALLY_RECORD_CHANGE, _args._file, () => {
        if ( currentTallyId !== Setting.NOP ) {
            refresh();
        }
    } );

    EventList.register( EventListName.DAY_CHANGE, _args._file, () => {
        if ( currentTallyId !== Setting.NOP ) {
            time = Date.now();
            current_year = WebTool.getNowFormatDate( time, "YYYY" );
            current_month = WebTool.getNowFormatDate( time, "MM" );
            current_day = WebTool.getNowFormatDate( time, "DD" );
            refresh();
        }
    } );

    $year.textContent = current_year;
    $month.textContent = current_month;
    $day.textContent = current_day;

    if ( currentTallyId !== Setting.NOP ) {
        refresh();
    }

    SSEServer.register( [
        "/tally-record/remove",
        "/tally-record/update",
        "/tally-record/add"
    ], _args._file, () => refresh() );
</script>

<event>
	switchYear = async () => {
		if ( Setting.get( "当前账本" ) === Setting.NOP ) {
			MagicUi.feedback.message( {
				text : `当前没有账本`,
				eventLevel : MagicUi.previa.feedback.message.EventLevel.warning
			} );
			return;
		}
		const td = await Tally.getData( currentTallyId );
		magic.importM( "ui/pop-select-list" ).interface.init( async ( target ) => {
			if ( target.textContent === "今年" )
				target.textContent = WebTool.getNowFormatDate( Date.now(), "YYYY" );
			current_year = target.textContent;

			const m = await td.getMonths( current_year );
			current_month = m[ 0 ];
			const d = await td.getDays( current_year, current_month );
			current_day = d[ 0 ];
			refresh();
			return true;
		}, [ "今年", ...await td.getYears() ] );
	}

	switchMonth = async () => {
		if ( Setting.get( "当前账本" ) === Setting.NOP ) {
			MagicUi.feedback.message( {
				text : `当前没有账本`,
				eventLevel : MagicUi.previa.feedback.message.EventLevel.warning
			} );
			return;
		}
		const td = await Tally.getData( currentTallyId );
		magic.importM( "ui/pop-select-list" ).interface.init( async ( target ) => {
			if ( target.textContent === "本月" )
				target.textContent = WebTool.getNowFormatDate( Date.now(), "MM" );
			current_month = target.textContent;

			const d = await td.getDays( current_year, current_month );
			current_day = d[ 0 ];
			refresh();
			return true;
		}, [ "本月", ...await td.getMonths( current_year ) ] );
	}

	switchDay = async () => {
		if ( Setting.get( "当前账本" ) === Setting.NOP ) {
			MagicUi.feedback.message( {
				text : `当前没有账本`,
				eventLevel : MagicUi.previa.feedback.message.EventLevel.warning
			} );
			return;
		}
		const td = await Tally.getData( currentTallyId );
		magic.importM( "ui/pop-select-list" ).interface.init( async ( target ) => {
			if ( target.textContent === "本日" )
				target.textContent = WebTool.getNowFormatDate( Date.now(), "DD" );
			current_day = target.textContent;
			refresh();
			return true;
		}, [ "本日", ...await td.getDays( current_year, current_month ) ] );
	}

	lookMonthData = () => {
		console.log( "lookMonthData" )
	}

	lookDayData = () => {
		console.log( "lookDayData" )
	}

	addTally = () => {
		if ( Setting.get( "当前账本" ) === Setting.NOP ) {
			MagicUi.feedback.message( {
				text : `当前没有账本`,
				eventLevel : MagicUi.previa.feedback.message.EventLevel.warning
			} );
			return;
		}
		magic.importM( "ui/page/bill/add-tally-record" );
	}

	switchTally = () => {
		Tally.getAllTally( Tally.State.normal ).then( r => {
			if ( r.length === 0 ) {
				MagicUi.feedback.message( {
					text : `当前没有账本,请先创建一个`,
					eventLevel : MagicUi.previa.feedback.message.EventLevel.error
				} );
				return;
			}
			magic.importM( "ui/pop-select-list" ).interface.init( async ( target ) => {
				const id = target.getAttribute( "id" );
				if ( Setting.get( "当前账本" ) === id ) {
					return true;
				}
				const o = await Tally.getInfo( id );
				if ( o.metadata.who === "SQ-Tally" ) {
					Setting.set( "当前账本", id );
					Setting.set( "当前账本存储类型", o.storage.type );
					Setting.set( "当前账本密码", "" );
					refresh();
				} else
					magic.importM( "ui/dialog" ).interface.init( {
						title : "该账本已被加密,请输入密码",
						input : true,
						group : {
							"确定" : async ( v ) => {
								try {
									if ( v.trim() === "" ) throw new Error( "账本密码错误" );
									await Confuse.decryptString( o.metadata.who, v );
									Setting.set( "当前账本", id );
									Setting.set( "当前账本存储类型", o.storage.type );
									Setting.set( "当前账本密码", v );
									refresh();
									return true;
								} catch ( e ) {
									MagicUi.feedback.message( {
										text : `账本密码错误`,
										eventLevel : MagicUi.previa.feedback.message.EventLevel.error
									} );
								}
							},
							"取消" : () => {
								return true;
							}
						}
					} );
				return true;
			}, r.map( o => {
				return {
					text : o.name,
					id : o.id,
					type : o.storage.type
				}
			} ), ( item ) => {
				item.setAttribute( "style", "display: flex;align-items: center;flex-direction: row-reverse;justify-content: flex-end;gap: 8px;" );
				const icon = MagicUi.createElement( { tagName : "img" } );
				icon.setAttribute( "style", "pointer-events: none;width: 35px;" );
				if ( item.getAttribute( "type" ) === "cloud" )
					icon.setAttribute( "src", `assets/MaterialSymbolsCloud.svg` );
				else
					icon.setAttribute( "src", `assets/OpenmojiLedger.svg` );
				item.appendChild( icon );
			} );
		} );
	}

	ai = ( ev ) => {
		magic.importM( "ui/page/ai/chat", magic.createArgs( { rect : ev.target.getBoundingClientRect() } ) );
	}
</event>

<css scope="#id:view" default-theme>
	& {
		.operation {
			background-color: #00e75b;
			border-radius: 0 0 30px 30px;

			box-shadow: rgba(50, 50, 93, 0.25) 0px 2px 5px -1px, rgba(0, 0, 0, 0.3) 0px 1px 3px -1px;

			animation: appear-from-top-to-bottom .5s;

			.year,
			.month {
				border-radius: 8px;
				background-color: #c0ffc8;
				color: #505050;
				text-align: center;

				box-shadow: rgba(50, 50, 93, 0.25) 0px 2px 5px -1px, rgba(0, 0, 0, 0.3) 0px 1px 3px -1px;
			}

			.select-tally-book {
				border-radius: 8px;
				background-color: #ffffff;
				color: #505050;
				text-align: center;

				overflow: hidden;
				text-overflow: ellipsis;
				text-wrap: nowrap;
			}
		}

		.info-data {
			& > div {
				border: solid 2px #7b7b7b;
				border-radius: 20px;
				box-shadow: rgba(50, 50, 93, 0.25) 0px 2px 5px -1px, rgba(0, 0, 0, 0.3) 0px 1px 3px -1px;
			}

			p {
				color: #f2faff;
				background-color: #000000a6;
				border-radius: 8px;
			}

			.box {
				.number {
					text-overflow: ellipsis;
					color: #f2faff;
					text-shadow: 1px -1px 3px #71eaff, -1px 1px 3px rgba(160, 218, 233, 0.64);
				}
			}

			.expenditure {
				animation: appear-from-left-to-right .5s;
				background-color: #ff6060;

				.number {
					text-shadow: none;
				}

				p {
					text-shadow: none;
				}
			}

			.income {
				animation: appear-from-right-to-left .5s;
				background-color: #26e445;
			}
		}

		.to-day-data {
			animation: appear-opacity .5s;
			background-color: #e5fafb;

			border-radius: 20px 20px 0px 0px;

			z-index: 1;

			& > label {
				background-color: #ffffff;

				box-shadow: rgb(0 0 0 / 12%) 0px 10px 36px 0px, rgba(0, 0, 0, 0.06) 0px 0px 0px 1px;

				border-radius: 15px;
			}

			& > div {
				& > label {
					border-radius: 15px;
				}

				& > span {
					text-overflow: ellipsis;
				}
			}
		}

		.tally {
			animation: appear-opacity .5s;
			background-color: #e5fafb;

			box-shadow: rgba(0, 0, 0, 0.1) 0px 4px 12px;
			border-radius: 0px 0px 20px 20px;

			& > *[m-item] {
				background-color: rgb(255, 255, 255) !important;
				border-radius: 5px;

				box-shadow: rgba(149, 157, 165, 0.2) 0px 8px 24px;

				animation: appear-opacity-scale-9 1s linear both;
				-moz-animation: appear-opacity-scale-9 .2s linear both;
				animation-timeline: view(105% 0);

				&:active {
					background-color: rgba(0, 0, 0, 0.1) !important;
				}

				&[state="收入"] {
					border-left: solid 4px #00e75b;
				}

				&[state="支出"] {
					border-left: solid 4px red;

					& > .money::before {
						color: rgb(210, 0, 0);
					}
				}

				& > .money,
				& > .info > label {
					text-overflow: ellipsis;
				}
			}
		}
	}
</css>

<css scope="#id:view">
	& {
		display: flex;
		flex-direction: column;

		width: 100%;
		height: 100%;

		.ai-tally-button,
		.add-tally-button {
			width: 50px;
			height: 50px;
			position: fixed;
			right: 10px;
		}

		.ai-tally-button {
			bottom: 200px;
		}

		.add-tally-button {
			bottom: 300px;
		}

		.operation {
			display: flex;
			align-items: center;
			justify-content: space-around;

			height: 110px;

			.year,
			.month,
			.select-tally-book {
				padding: 4px 8px 4px 8px;
				min-width: 80px;
				min-height: 50px;

				font-size: 1.4rem;

				text-align: center;

				display: flex;
				align-items: center;
				justify-content: center;
			}

			.select-tally-book {
				min-width: 120px;


				font-size: 1.2rem;
			}
		}

		.info-data {
			flex: 0 auto;
			display: flex;
			align-items: center;
			flex-direction: row;
			justify-content: center;
			gap: 20px;

			width: 100%;
			min-height: 110px;

			margin-top: 10px;

			& > div {
				width: 44%;
				height: 80%;

				padding: 8px;

				p {
					margin: 0 0 4px;
					padding: 6px;
					text-align: center;
					font-size: 12px;
					display: inline-flex;
				}

				.box {
					display: flex;
					align-items: center;
					gap: 6px;

					width: 100%;

					.number {
						font-size: x-large;
						overflow: hidden;
					}
				}
			}
		}

		.to-day-data {
			margin: 20px auto 0px auto;
			padding: 8px 10px 4px 10px;

			display: flex;
			align-items: center;
			justify-content: space-between;

			width: calc(100% - 140px);
			max-width: 999px;

			* {
				text-wrap: nowrap;
			}

			& > label {
				display: flex;
				align-items: center;
				justify-content: center;

				width: 30px;
				height: 30px;
			}

			& > div {
				display: flex;
				align-items: center;
				gap: 6px;

				& > label {
					width: 28px;
					height: 28px;

					display: flex;
					align-items: center;
					justify-content: center;

					font-size: smaller;
				}

				& > span {
					max-width: 70px;

					overflow: hidden;
				}
			}
		}

		.tally {
			flex: 0 auto;
			gap: 10px;

			width: calc(100% - 140px);
			max-width: 999px;
			height: calc(100% - 100px);

			margin: 0px auto 20px auto;
			padding: 10px;

			overflow: auto;

			& > *[m-item] {
				display: flex;
				align-items: center;
				justify-content: space-between;
				gap: 5px;

				padding: 8px 10px 8px 6px;

				min-height: 80px;
				width: 100%;

				& > .money {
					min-width: 30px;
					max-width: 80px;

					font-size: medium;
				}

				& > .money {
					overflow: hidden;
				}

				& > .info {
					font-size: smaller;

					width: calc(100% - 74px);
					height: 100%;

					display: flex;
					flex-direction: column;
					gap: 6px;

					padding: 2px;

					label {
						overflow: hidden;

						display: flex;
						align-items: center;

						width: 100%;
						height: 100%;

						text-wrap: nowrap;
					}

					& > .target {
						font-size: 22px;
					}
				}

				& > .money::before {
					content: "-";
					color: rgba(0, 0, 0, 0);
				}
			}
		}
	}
</css>