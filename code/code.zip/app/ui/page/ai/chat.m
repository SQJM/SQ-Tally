<import
	root="magic-ui/ui"
>
	<module:input>
		<text-edit/>
	</module:input>

	<module:widget>
		<item/>
	</module:widget>

	<module:control>
		<list-view/>
	</module:control>
</import>

<template>
    <div #id="view">
		<list-view #id="message-list"
				   #listen:select="select"
				   :def_select="false"
				   :repetition="true"
				   class="list"
		></list-view>
		<div class="input-view">
			<div class="tool">
				<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMjgiIGhlaWdodD0iMTI4IiB2aWV3Qm94PSIwIDAgMjQgMjQiPjxwYXRoIGZpbGw9IiM0N2MyZmYiIGQ9Ik0zIDRhMSAxIDAgMCAxIDEtMWg2YTEgMSAwIDAgMSAxIDF2NmExIDEgMCAwIDEtMSAxSDRhMSAxIDAgMCAxLTEtMXptMCAxMGExIDEgMCAwIDEgMS0xaDZhMSAxIDAgMCAxIDEgMXY2YTEgMSAwIDAgMS0xIDFINGExIDEgMCAwIDEtMS0xek0xMyA0YTEgMSAwIDAgMSAxLTFoNmExIDEgMCAwIDEgMSAxdjZhMSAxIDAgMCAxLTEgMWgtNmExIDEgMCAwIDEtMS0xem0wIDEwYTEgMSAwIDAgMSAxLTFoNmExIDEgMCAwIDEgMSAxdjZhMSAxIDAgMCAxLTEgMWgtNmExIDEgMCAwIDEtMS0xeiIvPjwvc3ZnPg=="/>
				<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMTAiIGhlaWdodD0iMTEwIiB2aWV3Qm94PSIwIDAgMjQgMjQiPjxnIGZpbGw9Im5vbmUiPjxwYXRoIGZpbGw9IiM3NWE4YjgiIGQ9Im0xNS4zOTMgNC4wNTRsLS41MDIuNTU3em0zLjk1OSAzLjU2M2wtLjUwMi41NTd6bTIuMzAyIDIuNTM3bC0uNjg1LjMwNXpNMy4xNzIgMjAuODI4bC41My0uNTN6bTE3LjY1NiAwbC0uNTMtLjUzek0xNCAyMS4yNWgtNHYxLjVoNHpNMi43NSAxNHYtNGgtMS41djR6bTE4LjUtLjQzN1YxNGgxLjV2LS40Mzd6TTE0Ljg5MSA0LjYxbDMuOTU5IDMuNTYzbDEuMDAzLTEuMTE1bC0zLjk1OC0zLjU2M3ptNy44NTkgOC45NTJjMC0xLjY4OS4wMTUtMi43NTgtLjQxLTMuNzE0bC0xLjM3MS42MWMuMjY2LjU5OC4yODEgMS4yODMuMjgxIDMuMTA0em0tMy45LTUuMzg5YzEuMzUzIDEuMjE4IDEuODUzIDEuNjg4IDIuMTE5IDIuMjg1bDEuMzctLjYxYy0uNDI2LS45NTctMS4yMy0xLjY2LTIuNDg2LTIuNzl6TTEwLjAzIDIuNzVjMS41ODIgMCAyLjE3OS4wMTIgMi43MS4yMTZsLjUzOC0xLjRjLS44NTItLjMyOC0xLjc4LS4zMTYtMy4yNDgtLjMxNnptNS44NjUuNzQ2Yy0xLjA4Ni0uOTc3LTEuNzY1LTEuNjA0LTIuNjE3LTEuOTNsLS41MzcgMS40Yy41MzIuMjA0Ljk4LjU5MiAyLjE1IDEuNjQ1ek0xMCAyMS4yNWMtMS45MDcgMC0zLjI2MS0uMDAyLTQuMjktLjE0Yy0xLjAwNS0uMTM1LTEuNTg1LS4zODktMi4wMDgtLjgxMmwtMS4wNiAxLjA2Yy43NDguNzUgMS42OTcgMS4wODEgMi44NjkgMS4yMzljMS4xNS4xNTUgMi42MjUuMTUzIDQuNDg5LjE1M3pNMS4yNSAxNGMwIDEuODY0LS4wMDIgMy4zMzguMTUzIDQuNDg5Yy4xNTggMS4xNzIuNDkgMi4xMjEgMS4yMzggMi44N2wxLjA2LTEuMDZjLS40MjItLjQyNC0uNjc2LTEuMDA0LS44MTEtMi4wMWMtLjEzOC0xLjAyNy0uMTQtMi4zODItLjE0LTQuMjg5ek0xNCAyMi43NWMxLjg2NCAwIDMuMzM4LjAwMiA0LjQ4OS0uMTUzYzEuMTcyLS4xNTggMi4xMjEtLjQ5IDIuODctMS4yMzhsLTEuMDYtMS4wNmMtLjQyNC40MjItMS4wMDQuNjc2LTIuMDEuODExYy0xLjAyNy4xMzgtMi4zODIuMTQtNC4yODkuMTR6TTIxLjI1IDE0YzAgMS45MDctLjAwMiAzLjI2Mi0uMTQgNC4yOWMtLjEzNSAxLjAwNS0uMzg5IDEuNTg1LS44MTIgMi4wMDhsMS4wNiAxLjA2Yy43NS0uNzQ4IDEuMDgxLTEuNjk3IDEuMjM5LTIuODY5Yy4xNTUtMS4xNS4xNTMtMi42MjUuMTUzLTQuNDg5em0tMTguNS00YzAtMS45MDcuMDAyLTMuMjYxLjE0LTQuMjljLjEzNS0xLjAwNS4zODktMS41ODUuODEyLTIuMDA4bC0xLjA2LTEuMDZjLS43NS43NDgtMS4wODEgMS42OTctMS4yMzkgMi44NjlDMS4yNDggNi42NjEgMS4yNSA4LjEzNiAxLjI1IDEwem03LjI4LTguNzVjLTEuODc1IDAtMy4zNTYtLjAwMi00LjUxMS4xNTNjLTEuMTc3LjE1OC0yLjEyOS40OS0yLjg3OCAxLjIzOGwxLjA2IDEuMDZjLjQyNC0uNDIyIDEuMDA1LS42NzYgMi4wMTctLjgxMWMxLjAzMy0uMTM4IDIuMzk1LS4xNCA0LjMxMi0uMTR6Ii8+PHBhdGggc3Ryb2tlPSIjNzVhOGI4IiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS13aWR0aD0iMS41IiBkPSJNNiAxNC41aDhNNiAxOGg1LjUiIG9wYWNpdHk9Ii41Ii8+PHBhdGggc3Ryb2tlPSIjNzVhOGI4IiBzdHJva2Utd2lkdGg9IjEuNSIgZD0iTTEzIDIuNVY1YzAgMi4zNTcgMCAzLjUzNi43MzIgNC4yNjhTMTUuNjQzIDEwIDE4IDEwaDQiIG9wYWNpdHk9Ii41Ii8+PC9nPjwvc3ZnPg=="/>
				<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMjgiIGhlaWdodD0iMTI4IiB2aWV3Qm94PSIwIDAgMjQgMjQiPjxwYXRoIGZpbGw9IiM1ODc1N2UiIGQ9Ik01IDIxcS0uODI1IDAtMS40MTItLjU4N1QzIDE5VjVxMC0uODI1LjU4OC0xLjQxMlQ1IDNoMTRxLjgyNSAwIDEuNDEzLjU4OFQyMSA1djE0cTAgLjgyNS0uNTg3IDEuNDEzVDE5IDIxem0yLTRoMTBxLjMgMCAuNDUtLjI3NXQtLjA1LS41MjVsLTIuNzUtMy42NzVxLS4xNS0uMi0uNC0uMnQtLjQuMkwxMS4yNSAxNkw5LjQgMTMuNTI1cS0uMTUtLjItLjQtLjJ0LS40LjJsLTIgMi42NzVxLS4yLjI1LS4wNS41MjVUNyAxNyIvPjwvc3ZnPg=="/>

				<img @click="tool_clearAllMessage" src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMTAiIGhlaWdodD0iMTEwIiB2aWV3Qm94PSIwIDAgMjA0OCAyMDQ4Ij48cGF0aCBmaWxsPSIjZmY3NTc1IiBkPSJNMTExNSAxNzkyaDQyMXYxMjhINDUzTDUwIDE1MTZxLTI0LTI0LTM3LTU2dC0xMy02OHEwLTM1IDEzLTY3dDM4LTU4TDEyNDggNjlsNzk0IDc5NXptMTMzLTE1NDJMNTM4IDk2MGw2MTQgNjEzbDcwOS03MDl6TTkzMyAxNzkybDEyOC0xMjhsLTYxMy02MTRsLTMwNiAzMDdxLTE0IDE0LTE0IDM1dDE0IDM1bDM2NCAzNjV6Ii8+PC9zdmc+"/>
				<img #id="tool-r-o-m" @click="tool_removeOneMessage" src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMTAiIGhlaWdodD0iMTEwIiB2aWV3Qm94PSIwIDAgNTYgNTYiPjxwYXRoIGZpbGw9IiNmZjc1NzUiIGQ9Ik0xMy43ODUgNDkuNTc0aDI4LjQ1M2M0Ljg5OSAwIDcuMzM2LTIuNDM3IDcuMzM2LTcuMjY1VjEzLjY5YzAtNC44MjgtMi40MzctNy4yNjUtNy4zMzYtNy4yNjVIMTMuNzg1Yy00Ljg3NSAwLTcuMzYgMi40MTQtNy4zNiA3LjI2NXYyOC42MmMwIDQuODUxIDIuNDg1IDcuMjY1IDcuMzYgNy4yNjVtLjA3LTMuNzczYy0yLjM0MyAwLTMuNjU2LTEuMjQyLTMuNjU2LTMuNjhWMTMuODhjMC0yLjQzOCAxLjMxMy0zLjY4IDMuNjU2LTMuNjhoMjguMzEzYzIuMzIgMCAzLjYzMyAxLjI0MiAzLjYzMyAzLjY4djI4LjI0YzAgMi40MzgtMS4zMTMgMy42OC0zLjYzMyAzLjY4Wm00LjMzNi05Ljg2N2ExLjg2IDEuODYgMCAwIDAgMS44NTIgMS44NzVjLjUxNSAwIC45ODQtLjE4OCAxLjMxMi0uNTRsNi42MzMtNi42NTZsNi42NTYgNi42NTdjLjMyOS4zMjguNzc0LjUzOSAxLjI5LjUzOWExLjg4IDEuODggMCAwIDAgMS44NzUtMS44NzVjMC0uNTQtLjIxMS0uOTYxLS41NjMtMS4zMTNsLTYuNjEtNi42MzNsNi42MzQtNi42NTZjLjM3NC0uMzc1LjU2Mi0uNzk3LjU2Mi0xLjI4OWMwLTEuMDMxLS44Mi0xLjg3NS0xLjg3NS0xLjg3NWMtLjQ2OSAwLS44NjcuMTg4LTEuMjQyLjU2M2wtNi43MjcgNi42OGwtNi42OC02LjY1N2MtLjM1MS0uMzI4LS43NS0uNTQtMS4yNjUtLjU0YTEuODU2IDEuODU2IDAgMCAwLTEuODUyIDEuODUyYzAgLjQ5My4yMTEuOTM4LjU0IDEuMjlsNi42MzIgNi42MzJsLTYuNjMzIDYuNjU3Yy0uMzI4LjM1MS0uNTM5Ljc3My0uNTM5IDEuMjg5Ii8+PC9zdmc+
"/>
			</div>
			<div class="edit">
				<text-edit #id="input" :maxlength="360"/>
				<button @click="send">发送</button>
			</div>
		</div>
    </div>
</template>

<global>
	const {
		$view,
		$input,
		$messageList,
		$toolROM
	} = $id();

	function select( item ) {
        if(!selectRemoveMessage) return;
        selectRemoveMessage = false;
        $toolROM.src = `data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMTAiIGhlaWdodD0iMTEwIiB2aWV3Qm94PSIwIDAgNTYgNTYiPjxwYXRoIGZpbGw9IiNmZjc1NzUiIGQ9Ik0xMy43ODUgNDkuNTc0aDI4LjQ1M2M0Ljg5OSAwIDcuMzM2LTIuNDM3IDcuMzM2LTcuMjY1VjEzLjY5YzAtNC44MjgtMi40MzctNy4yNjUtNy4zMzYtNy4yNjVIMTMuNzg1Yy00Ljg3NSAwLTcuMzYgMi40MTQtNy4zNiA3LjI2NXYyOC42MmMwIDQuODUxIDIuNDg1IDcuMjY1IDcuMzYgNy4yNjVtLjA3LTMuNzczYy0yLjM0MyAwLTMuNjU2LTEuMjQyLTMuNjU2LTMuNjhWMTMuODhjMC0yLjQzOCAxLjMxMy0zLjY4IDMuNjU2LTMuNjhoMjguMzEzYzIuMzIgMCAzLjYzMyAxLjI0MiAzLjYzMyAzLjY4djI4LjI0YzAgMi40MzgtMS4zMTMgMy42OC0zLjYzMyAzLjY4Wm00LjMzNi05Ljg2N2ExLjg2IDEuODYgMCAwIDAgMS44NTIgMS44NzVjLjUxNSAwIC45ODQtLjE4OCAxLjMxMi0uNTRsNi42MzMtNi42NTZsNi42NTYgNi42NTdjLjMyOS4zMjguNzc0LjUzOSAxLjI5LjUzOWExLjg4IDEuODggMCAwIDAgMS44NzUtMS44NzVjMC0uNTQtLjIxMS0uOTYxLS41NjMtMS4zMTNsLTYuNjEtNi42MzNsNi42MzQtNi42NTZjLjM3NC0uMzc1LjU2Mi0uNzk3LjU2Mi0xLjI4OWMwLTEuMDMxLS44Mi0xLjg3NS0xLjg3NS0xLjg3NWMtLjQ2OSAwLS44NjcuMTg4LTEuMjQyLjU2M2wtNi43MjcgNi42OGwtNi42OC02LjY1N2MtLjM1MS0uMzI4LS43NS0uNTQtMS4yNjUtLjU0YTEuODU2IDEuODU2IDAgMCAwLTEuODUyIDEuODUyYzAgLjQ5My4yMTEuOTM4LjU0IDEuMjlsNi42MzIgNi42MzJsLTYuNjMzIDYuNjU3Yy0uMzI4LjM1MS0uNTM5Ljc3My0uNTM5IDEuMjg5Ii8+PC9zdmc+`;
        const id = item.getAttribute("id");
        magic.importM( "ui/dialog" ).interface.init( {
			content : "不可恢复!",
			title : "是否删除此聊天记录?",
			group : {
				"确定" : async () => {
					try {
						await AiStorage.remove(id);
						item.remove();
						MagicUi.feedback.message( {
							text : `删除成功`,
							eventLevel : MagicUi.previa.feedback.message.EventLevel.pass
						} );
					} catch ( e ) {
						MagicUi.feedback.message( {
							text : `删除失败 ${ e }`,
							eventLevel : MagicUi.previa.feedback.message.EventLevel.error
						} );
					}
					return true;
				},
				"取消" : () => {
					return true;
				}
			}
		} );
	}

	function scrollBottom() {
		$messageList.scrollTop = $messageList.scrollHeight;
	}

	function generateRandomString( minLen = 8, maxLen = 15, includeSpecial = false ) {
		let chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
		if ( includeSpecial ) chars += '!@#$%^&*()_+-=[]{}|;:,.<>?';

		const length = Math.floor( Math.random() * ( maxLen - minLen + 1 ) ) + minLen;
		return Array.from( { length }, () =>
			chars.charAt( Math.floor( Math.random() * chars.length ) )
		).join( '' );
	}

    function rS(re) {
        re.childNodes.forEach(e=>{
            if(e.nodeType === 3) {
				e.data = unescape( e.data );
			} else if(e.nodeType === 1) rS(e);
		});
    }

    function createMessage(obj) {
		const item = magic.importM( "magic-ui/ui/widget/item" );
        item.setAttribute("id",obj.id);
        item.setAttribute("role",obj.role);

        for (const attrsKey in obj.attrs) {
		    item.setAttribute(attrsKey, obj.attrs[attrsKey]);
        }

        const messageElement = MagicUi.createElement({className:"message"});

        if (obj.role === "user") {
            messageElement.textContent = obj.message;
            item.appendChild( messageElement );
        }

		$messageList.appendChild( item );
        item.scrollIntoView();

        if(obj.role === "assistant"){
            item.innerHTML = `<img class="ai-icon" src="assets/JamSmiley.svg"/><div class="message"><img style="width: 40px;" src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMTAiIGhlaWdodD0iMTEwIiB2aWV3Qm94PSIwIDAgMjQgMjQiPjxwYXRoIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzQ3YzJmZiIgc3Ryb2tlLWRhc2hhcnJheT0iMTYiIHN0cm9rZS1kYXNob2Zmc2V0PSIxNiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjIiIGQ9Ik0xMiAzYzQuOTcgMCA5IDQuMDMgOSA5Ij48YW5pbWF0ZSBmaWxsPSJmcmVlemUiIGF0dHJpYnV0ZU5hbWU9InN0cm9rZS1kYXNob2Zmc2V0IiBkdXI9IjAuMnMiIHZhbHVlcz0iMTY7MCIvPjxhbmltYXRlVHJhbnNmb3JtIGF0dHJpYnV0ZU5hbWU9InRyYW5zZm9ybSIgZHVyPSIxLjVzIiByZXBlYXRDb3VudD0iaW5kZWZpbml0ZSIgdHlwZT0icm90YXRlIiB2YWx1ZXM9IjAgMTIgMTI7MzYwIDEyIDEyIi8+PC9wYXRoPjwvc3ZnPg=="/></div>`;
            setTimeout(()=>{
                item.scrollIntoView();
                scrollBottom();
			},10);
            return {
                close:()=>{
                    if(!document.contains(item)) return false;
                    item.remove();
				},
                finish: (o = obj)=>{
                    if(!document.contains(item)) return false;
                    function createLi( target ) { return `<li onclick="WebTool.getParent(this,2).cb(this.textContent)">${ target }</li>`;}
                    item.setAttribute("id",o.id);
                    item.innerHTML = `<img class="ai-icon" src="assets/JamSmiley.svg"/>`;
                    messageElement.innerHTML = marked.parse( o.message );
                    for (const attrsKey in obj.attrs) {
                        if (attrsKey === "init") {
                            if(obj.attrs[attrsKey] === "[记账功能列表]") {
                                messageElement.classList.add( "function-list" );
                                messageElement.innerHTML =`<h3>【记账功能列表】</h3><ul>
${ createLi( "获取账本数量" ) }
${ createLi( "获取账本信息[id]" ) }
${ createLi( "获取账本信息[name]" ) }
</ul>`;
                                messageElement.cb = (fn)=>{
                                    console.log(fn)
								}
							}
						}
                    }
                    rS(messageElement);
                    item.appendChild( messageElement );
                    $messageList.appendChild( item );
                    setTimeout(()=>{
                        item.scrollIntoView();
                        scrollBottom();
					},10);
                },
				element : ()=>{
                    return messageElement;
				}
			};
		}
    }

    function unescape( html ) {
        const unescapeReplacements = {
            '&amp;' : '&',
            '&lt;' : '<',
            '&gt;' : '>',
            '&quot;' : '"',
            '&#39;' : "'"
        };

        return html.replace( /&(amp|lt|gt|quot|#39);/g, ( match ) => {
            return unescapeReplacements[ match ] || match;
        } );
    }

    function refreshCodeBlock() {
		$view.querySelectorAll(".ai-code-block").forEach( e =>{
            const lang = e.getAttribute("lang");
            if(lang.length === 0 || e.querySelector(".code-bar")) return;
            const sc = e.textContent;
            const bs = MagicUi.createElement({
				html:`<label>${lang}</label><button>复制</button>`,
				className: "code-bar",
				callback: r => {
                    r.querySelector("button").onclick = (ev)=>{
                        navigator.clipboard.writeText(sc).then(r => {
                            if(ev.target.textContent === "复制成功") return;
                            ev.target.textContent = "复制成功";
                            setTimeout(()=>{
                                ev.target.textContent = "复制";
                            },800);
						});
					}
				}
            });
            e.appendChild(bs);
            e.insertBefore(bs,e.querySelector("code"));
        });
    }

    function refresh() {
		$messageList.innerHTML = null;
        return new Promise((resolve, reject) => {
            AiStorage.getAll().then( r => {
                r.forEach( o => {
                    if(!o.show)return;
                    const r = createMessage(o);
                    if(r) r.finish(o);
				} );
                refreshCodeBlock();
                scrollBottom();
				resolve();
			} );
        });
    }

    let isLoading = false;

    let selectRemoveMessage = false;
</global>

<script>
	$messageList._view = $view;
    magic.importM( "ui/pop-view", _args ).interface.init( $view, "AI 记账管家" );
    refresh();
</script>

<interface>
	setUserInputValue = ( value ) => {
		if ( $input.interface.getValue() === "" ) $input.interface.setValue( value );
	}
</interface>

<event>
	send = async () => {
		if ( !App.Current[ "ai服务器状态" ] ) {
			MagicUi.feedback.message( {
				text : `未连接AI服务器`,
				eventLevel : MagicUi.previa.feedback.message.EventLevel.warning
			} );
			return;
		}
		if ( Setting.get( "ai设置.当前ai模型" ) === Setting.NOP ) {
			MagicUi.feedback.message( {
				text : `当前没有设置AI模型`,
				eventLevel : MagicUi.previa.feedback.message.EventLevel.warning
			} );
			return;
		}
		if ( isLoading ) return;
		const value = $input.interface.getValue();
		if ( value.length < 1 ) {
			MagicUi.feedback.message( {
				text : `字数太少啦`,
				eventLevel : MagicUi.previa.feedback.message.EventLevel.info
			} );
			return;
		}
		$input.interface.setValue( "" );
		const obj = AiStorage.createMessageObject( "user", value );
		createMessage( obj );
		await AiStorage.add( obj );
		const assistantObj = AiStorage.createMessageObject( "assistant" );
		isLoading = true;
		const assistantMsg = createMessage( assistantObj );
		AiStorage.getHistory().then( m => {
			Ai.chat( m ).then( async r => {
				const temp = document.createElement( "div" );
				temp.innerHTML = r.message;
				if ( temp.querySelector( "think" ) ) {
					Log.info( "思考过程:" + temp.querySelector( "think" ).textContent )
					temp.querySelector( "think" ).remove();
					assistantObj.message = temp.innerHTML;
				} else {
					assistantObj.message = r.message;
				}
				if ( assistantObj.message === "[记账功能列表]" ) {
					assistantMsg.close();
					assistantObj.show = false;
					await AiStorage.add( assistantObj );
					const newAssistantObj = AiStorage.createMessageObject( "assistant", "", { attrs : { "init" : assistantObj.message } } );
					isLoading = false;
					if ( createMessage( newAssistantObj ).finish() === false ) return;
					await AiStorage.add( newAssistantObj );
					return;
				}
				assistantObj.id = r.id;
				assistantObj.time += 1;
				if ( assistantMsg.finish( assistantObj ) === false ) {
					isLoading = false;
					return;
				}
				await AiStorage.add( assistantObj );
				refreshCodeBlock();
				isLoading = false;
			} );
		} );
	}

	tool_removeOneMessage = ( e ) => {
		if ( isLoading ) return;
		if ( selectRemoveMessage ) {
			e.target.src = `data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMTAiIGhlaWdodD0iMTEwIiB2aWV3Qm94PSIwIDAgNTYgNTYiPjxwYXRoIGZpbGw9IiNmZjc1NzUiIGQ9Ik0xMy43ODUgNDkuNTc0aDI4LjQ1M2M0Ljg5OSAwIDcuMzM2LTIuNDM3IDcuMzM2LTcuMjY1VjEzLjY5YzAtNC44MjgtMi40MzctNy4yNjUtNy4zMzYtNy4yNjVIMTMuNzg1Yy00Ljg3NSAwLTcuMzYgMi40MTQtNy4zNiA3LjI2NXYyOC42MmMwIDQuODUxIDIuNDg1IDcuMjY1IDcuMzYgNy4yNjVtLjA3LTMuNzczYy0yLjM0MyAwLTMuNjU2LTEuMjQyLTMuNjU2LTMuNjhWMTMuODhjMC0yLjQzOCAxLjMxMy0zLjY4IDMuNjU2LTMuNjhoMjguMzEzYzIuMzIgMCAzLjYzMyAxLjI0MiAzLjYzMyAzLjY4djI4LjI0YzAgMi40MzgtMS4zMTMgMy42OC0zLjYzMyAzLjY4Wm00LjMzNi05Ljg2N2ExLjg2IDEuODYgMCAwIDAgMS44NTIgMS44NzVjLjUxNSAwIC45ODQtLjE4OCAxLjMxMi0uNTRsNi42MzMtNi42NTZsNi42NTYgNi42NTdjLjMyOS4zMjguNzc0LjUzOSAxLjI5LjUzOWExLjg4IDEuODggMCAwIDAgMS44NzUtMS44NzVjMC0uNTQtLjIxMS0uOTYxLS41NjMtMS4zMTNsLTYuNjEtNi42MzNsNi42MzQtNi42NTZjLjM3NC0uMzc1LjU2Mi0uNzk3LjU2Mi0xLjI4OWMwLTEuMDMxLS44Mi0xLjg3NS0xLjg3NS0xLjg3NWMtLjQ2OSAwLS44NjcuMTg4LTEuMjQyLjU2M2wtNi43MjcgNi42OGwtNi42OC02LjY1N2MtLjM1MS0uMzI4LS43NS0uNTQtMS4yNjUtLjU0YTEuODU2IDEuODU2IDAgMCAwLTEuODUyIDEuODUyYzAgLjQ5My4yMTEuOTM4LjU0IDEuMjlsNi42MzIgNi42MzJsLTYuNjMzIDYuNjU3Yy0uMzI4LjM1MS0uNTM5Ljc3My0uNTM5IDEuMjg5Ii8+PC9zdmc+`;
			selectRemoveMessage = false;
			return;
		}
		if ( App.Current[ "第一次进入应用" ] ) {
			MagicUi.feedback.message( {
				text : `点击消息可选择删除,再次点击此按钮可取消选择`,
				eventLevel : MagicUi.previa.feedback.message.EventLevel.info
			} );
		}
		selectRemoveMessage = true;
		e.target.src = `data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMTAiIGhlaWdodD0iMTEwIiB2aWV3Qm94PSIwIDAgNTYgNTYiPjxwYXRoIGZpbGw9IiNjY2NjY2MiIGQ9Ik0xMy43ODUgNDkuNTc0aDI4LjQ1M2M0Ljg5OSAwIDcuMzM2LTIuNDM3IDcuMzM2LTcuMjY1VjEzLjY5YzAtNC44MjgtMi40MzctNy4yNjUtNy4zMzYtNy4yNjVIMTMuNzg1Yy00Ljg3NSAwLTcuMzYgMi40MTQtNy4zNiA3LjI2NXYyOC42MmMwIDQuODUxIDIuNDg1IDcuMjY1IDcuMzYgNy4yNjVtLjA3LTMuNzczYy0yLjM0MyAwLTMuNjU2LTEuMjQyLTMuNjU2LTMuNjhWMTMuODhjMC0yLjQzOCAxLjMxMy0zLjY4IDMuNjU2LTMuNjhoMjguMzEzYzIuMzIgMCAzLjYzMyAxLjI0MiAzLjYzMyAzLjY4djI4LjI0YzAgMi40MzgtMS4zMTMgMy42OC0zLjYzMyAzLjY4Wm00LjMzNi05Ljg2N2ExLjg2IDEuODYgMCAwIDAgMS44NTIgMS44NzVjLjUxNSAwIC45ODQtLjE4OCAxLjMxMi0uNTRsNi42MzMtNi42NTZsNi42NTYgNi42NTdjLjMyOS4zMjguNzc0LjUzOSAxLjI5LjUzOWExLjg4IDEuODggMCAwIDAgMS44NzUtMS44NzVjMC0uNTQtLjIxMS0uOTYxLS41NjMtMS4zMTNsLTYuNjEtNi42MzNsNi42MzQtNi42NTZjLjM3NC0uMzc1LjU2Mi0uNzk3LjU2Mi0xLjI4OWMwLTEuMDMxLS44Mi0xLjg3NS0xLjg3NS0xLjg3NWMtLjQ2OSAwLS44NjcuMTg4LTEuMjQyLjU2M2wtNi43MjcgNi42OGwtNi42OC02LjY1N2MtLjM1MS0uMzI4LS43NS0uNTQtMS4yNjUtLjU0YTEuODU2IDEuODU2IDAgMCAwLTEuODUyIDEuODUyYzAgLjQ5My4yMTEuOTM4LjU0IDEuMjlsNi42MzIgNi42MzJsLTYuNjMzIDYuNjU3Yy0uMzI4LjM1MS0uNTM5Ljc3My0uNTM5IDEuMjg5Ii8+PC9zdmc+`;
	}

	tool_clearAllMessage = () => {
		magic.importM( "ui/dialog" ).interface.init( {
			content : "不可恢复!",
			title : "是否删除所有聊天记录?",
			group : {
				"确定" : async () => {
					Page.pause();
					try {
						await AiStorage.clear();
						refresh();
						Page.start();

						MagicUi.feedback.message( {
							text : `所有聊天记录删除成功`,
							eventLevel : MagicUi.previa.feedback.message.EventLevel.pass
						} );
					} catch ( e ) {
						MagicUi.feedback.message( {
							text : `所有聊天记录删除失败 ${ e }`,
							eventLevel : MagicUi.previa.feedback.message.EventLevel.error
						} );
					}
					return true;
				},
				"取消" : () => {
					return true;
				}
			}
		} );
	}
</event>

<css scope="#id:view" default-theme>
	& {
		background-color: #fff;
		border-radius: 20px;
		box-shadow: rgba(0, 0, 0, 0.16) 0px 1px 4px;

		& > .list {
			background-color: rgba(242, 250, 255, 0.15);

			& > *[m-item] {
				background-color: rgba(255, 255, 255, 0);

				animation: appear-opacity-scale-9 .3s;

				&[m-select] {
					background-color: rgba(255, 255, 255, 0);
				}

				&:active {
					background-color: rgba(0, 0, 0, 0.06);
				}

				& > .ai-icon {
					border-radius: 10px;
				}

				& > .message {
					animation: appear-opacity-scale-9 .3s;

					background-color: #f2faff;

					border-radius: 10px;

					box-shadow: rgba(0, 0, 0, 0.02) 0px 1px 3px 0px, rgba(27, 31, 35, 0.15) 0px 0px 0px 1px;
				}

				&[role="user"] {
					& > .message {
						background-color: #f2f9ff73;
					}
				}
			}
		}

		& > .input-view {
			box-shadow: rgba(9, 30, 66, 0.25) 0px 1px 1px, rgba(9, 30, 66, 0.13) 0px 0px 1px 1px;

			.tool {
				img {
					&:active {
						scale: .95;
					}
				}
			}

			.edit {

				& > div {
					border-radius: 16px;
					border: none;

					box-shadow: rgba(3, 102, 214, 0.3) 0px 0px 0px 3px;

					textarea {
						border-radius: 16px;
					}
				}

				button {
					border-radius: 6px;
					border: none;

					background-color: #47c2ff;
					color: #fff;

					&:active {
						background-color: rgba(71, 194, 255, 0.7);
					}
				}
			}
		}
	}
</css>

<css scope="#id:view">
	& {
		overflow: hidden;

		& > .list {
			width: 100%;
			height: calc(100% - 144px);

			overflow: auto;

			& > *[m-item] {
				padding: 15px;
				display: flex;
				align-items: flex-start;
				gap: 8px;

				&[role="user"] {
					justify-content: flex-end
				}

				& > .ai-icon {
					width: 26px;
					height: 26px;
					margin-top: 6px;
				}

				& > .message {
					padding: 10px;
					margin: 4px;

					overflow: auto;

					max-width: calc(100% - 50px);

					word-wrap: break-word;

					user-select: text;

					* {
						user-select: text;
					}

					p {
						margin: 0px;
					}

					&.function-list {
						h3 {
							margin: 2px;
						}

						ul {
							display: flex;
							gap: 18px;
							flex-direction: column;

							li {
								color: #2b87d8;
								user-select: none;

								&:active {
									scale: .95;
								}

								&:hover {
									color: #4daaff;
								}
							}
						}
					}

					.ai-code-block {
						margin: 0px;

						& > .code-bar {
							background-color: #333;

							display: flex;
							align-items: center;
							justify-content: space-between;

							padding: 6px;

							text-align: center;

							border-radius: 10px 10px 0px 0px;

							label {
								color: #fff;
							}

							button {
								background-color: #d8d8d8;
								border-radius: 8px;
								padding: 6px;

								user-select: none;
							}
						}

						& > code {
							padding: 10px;
							border-radius: 0px 0px 10px 10px;
						}
					}
				}
			}
		}

		.input-view {
			min-height: 144px;
			max-height: 144px;
			width: 100%;

			display: flex;
			flex-direction: column;
			gap: 4px;

			.tool {
				display: flex;
				align-items: center;
				gap: 12px;

				padding: 6px;
				margin-top: 4px;

				height: 36px;
				width: 100%;

				img {
					width: 30px;
				}
			}

			.edit {
				display: flex;
				align-items: center;

				height: 100px;
				width: 100%;

				& > div {
					width: 100%;
					height: calc(100% - 16px);

					margin: 8px;

					textarea {
						resize: none;

						padding: 6px;

						&::-webkit-scrollbar {
							width: 0px;
							height: 0px;
						}
					}
				}

				button {
					text-wrap: nowrap;

					text-align: center;

					padding: 2px;
					margin-right: 8px;

					min-width: 48px;
					height: 46px;
				}
			}
		}
	}
</css>