<template>
	<span #id="unit"></span>
</template>

<script>
	$id( "unit" ).textContent = MoneyUnit[ CurrentMoneyUnit ];

    EventList.register( EventListName.SETTINGS_CHANGE, _args._file, ( ev, key, value ) => {
        if ( ev !== "set" && key !== "应用设置.金额单位显示" ) return;
        if ( value === Setting.FALSE ) {
            $id( "unit" ).style.display = `none`;
        } else {
            $id( "unit" ).style.display = `inline-flex`;
        }
    } );

    if ( Setting.get( "应用设置.金额单位显示" ) === Setting.FALSE ) {
        $id( "unit" ).style.display = `none`;
    } else {
        $id( "unit" ).style.display = `inline-flex`;
    }
</script>

<css scope="#id:unit">
	& {
		display: inline-flex;
		color: #f2faff;
		text-align: center;
	}
</css>