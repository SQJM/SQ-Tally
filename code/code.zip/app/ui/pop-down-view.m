<template>
	<div @click="close" #id="view">
		<div #id="content" class="content">
			<div @click="close_btn" class="top-btn">
				<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMjgiIGhlaWdodD0iMTI4IiB2aWV3Qm94PSIwIDAgMjQgMjQiPjxwYXRoIGZpbGw9IiMzMzMzMzMiIGQ9Ik0xNyA5LjE3YTEgMSAwIDAgMC0xLjQxIDBMMTIgMTIuNzFMOC40NiA5LjE3YTEgMSAwIDAgMC0xLjQxIDBhMSAxIDAgMCAwIDAgMS40Mmw0LjI0IDQuMjRhMSAxIDAgMCAwIDEuNDIgMEwxNyAxMC41OWExIDEgMCAwIDAgMC0xLjQyIi8+PC9zdmc+"/>
			</div>
			<div #id="box" class="box"></div>
		</div>
	</div>
</template>

<global>
	const {
		$view,
		$content,
		$box
	} = $id();

	function close_fn() {
		$view.style.animation = "appear-opacity .3s reverse"
		$content.style.marginTop = "100dvh";
		$view.onanimationend = () => {
			$view.remove();
		}
	}
</global>

<script>
	document.body.appendChild( $view );
</script>

<event>
	close = ( ev ) => {
		if ( ev.target === $view ) close_fn();
	}

	close_btn = () => {
		close_fn();
	}
</event>

<interface>
	init = ( con ) => {
		$box.appendChild( con );
	}

	close = () => {
		close_fn();
	}
</interface>

<css scope="#id:view">
	& {
		background-color: rgba(123, 123, 123, 0.68);

		& > .content {
			animation: appear-from-bottom-to-top .3s;

			border-radius: 20px 20px 0 0;

			background-color: #f2faff;

			& > .top-btn {
				background-color: #fff;

				border-radius: 20px 20px 0 0;

				&:active {
					background-color: #d9d9d9;
				}
			}
		}
	}
</css>

<css scope="#id:view">
	& {
		position: fixed;
		z-index: 20;
		width: 100%;
		height: 100%;
		bottom: 0;

		& > .content {
			width: 100%;
			height: calc(100% - 120px);
			margin-top: 120px;

			overflow: auto;

			transition: all .2s;

			& > .top-btn {
				display: flex;
				align-items: center;
				justify-content: center;

				position: absolute;

				height: 25px;
				width: 100%;

				& > img {
					width: 28px;
				}
			}

			& > .box {
				display: flex;
				flex-direction: column;
				gap: 20px;

				padding: 15px;

				padding-top: 30px;

				height: 100%;
				width: 100%;
			}
		}
	}
</css>