<import
	root="magic-ui/ui"
>
	<module:widget>
		<item/>
	</module:widget>

	<module:control>
		<list-view/>
	</module:control>
</import>

<template>
	<dialog #id="view" @click="close" open>
		<list-view
			#id="list"
			#listen:select="select_cb"
			:def_select="false"
			:repetition="true"
			class="list"></list-view>
	</dialog>
</template>

<global>
	const {
		$view,
		$list
	} = $id();

	let _select_cb_cus = null;

	async function select_cb( e ) {
		if ( _select_cb_cus ) {
			const r = await _select_cb_cus( e, $view );
			if ( r ) {
				$view.remove();
			}
			$list.interface.removeAllSelect();
		}
	}
</global>

<event>
	close = ( e ) => {
		( e.target === $view ) && $view.remove();
	}
</event>

<script>
    document.body.appendChild( $view );
</script>

<interface>
	init = ( cb = () => {}, list = [], disposeItemElement = () => {} ) => {
		_select_cb_cus = cb;
		list.forEach( item => {
			const e = magic.importM( "magic-ui/ui/widget/item" );
			if ( typeof item === "string" )
				e.textContent = item;
			else if ( typeof item === "object" ) {
				e.textContent = item.text;
				delete item.text;
				for ( const itemKey in item ) {
					e.setAttribute( itemKey, item[ itemKey ] );
				}
			}
			disposeItemElement( e );
			$list.appendChild( e );
		} );
	}

	close = () => {
		$view.remove();
	}
</interface>

<css scope="#id:view" default-theme>
	& {
		border: none;

		background-color: rgba(0, 0, 0, 0.12);

		& > .list {
			animation: m-appear-top-to-bottom .3s;

			background-color: #ffffff;
			border-radius: 20px;
			box-shadow: rgba(0, 0, 0, 0.16) 0px 1px 4px;

			& > *[m-item] {
				border-bottom: solid 1.5px #c6c6c6;
			}

			& > *[m-item]:last-child {
				border-bottom: none;
			}
		}
	}
</css>

<css scope="#id:view">
	& {
		top: 0;
		left: 0;
		position: fixed;
		width: 100%;
		height: 100%;

		z-index: 94;

		display: flex;
		align-items: center;
		justify-content: center;

		padding-bottom: 120px;

		& > .list {
			min-width: 60%;
			min-height: 68px;
			max-width: 90%;
			max-height: calc(90% - 120px);

			overflow: auto;

			&::-webkit-scrollbar {
				width: 0px;
				height: 0px;
			}

			& > *[m-item] {
				width: 100%;

				padding: 20px;

				font-size: large;
			}
		}
	}
</css>