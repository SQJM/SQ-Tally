<import
	root="magic-ui/ui"
>
	<module:widget>
		<item/>
	</module:widget>

	<module:input>
		<edit/>
	</module:input>

	<module:input>
		<switch-button/>
	</module:input>

	<module:control>
		<list-view/>
	</module:control>
</import>

<template>
    <div #id="view">
		<div class="pass-info">
			<label>当前通行证</label>
			<div>
				<edit #id="pass-input" :readonly="true" class="pass-input"/>
				<button @click="passCopy" class="opr-btn">复制</button>
			</div>
		</div>
		<div #id="family-user-admin" class="family-user-admin">
			<div class="bar">
				<label>家庭用户</label>
				<img @click="familyAdmin" class="admin" src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMjgiIGhlaWdodD0iMTI4IiB2aWV3Qm94PSIwIDAgMjQgMjQiPjxwYXRoIGZpbGw9IiM0OGJlZmQiIGQ9Ik0xMCAxMS4zODVxLTEuMjM3IDAtMi4xMTktLjg4MlQ3IDguMzg1dC44ODEtMi4xMlQxMCA1LjM4NnQyLjExOS44OHQuODgxIDIuMTJ0LS44ODEgMi4xMTh0LTIuMTE5Ljg4Mm0tNyA3LjIzVjE2Ljk3cTAtLjY5LjM0OC0xLjE5NHQuOTgzLS44MDJxMS4yMTctLjU5MiAyLjUxLS45NzVxMS4yOTItLjM4MiAzLjE1OS0uMzgyaC4yMzVxLjA5MiAwIC4yMjMuMDExcS0uMTA0LjI1OC0uMTY1LjUwNWwtLjExNi40ODRIMTBxLTEuNjc5IDAtMi45MjguMzQ0dC0yLjI2NC44OXEtLjQ1Ni4yNC0uNjMyLjUwNFE0IDE2LjYxOCA0IDE2Ljk3di42NDdoNi4zcS4wNzMuMjM2LjE3OS41MDh0LjIzMy40OTJ6bTEzLjIxMi40ODFsLS4xNDYtMS4xNTRxLS40MTYtLjA4Ni0uNzg0LS4yOTF0LS42NjMtLjUybC0xLjA4NC40M2wtLjQyMy0uNzE5bC45MTktLjY5MnEtLjE2NS0uNDI3LS4xNjUtLjg4dC4xNjUtLjg4MWwtLjktLjczMWwuNDIzLS43MmwxLjA2NS40NXEuMjc1LS4zMTUuNjUzLS41MXQuNzk0LS4yODJsLjE0Ni0xLjE1NGguODQ2bC4xMjcgMS4xNTRxLjQxNS4wODcuNzkzLjI4NXQuNjUzLjUxOWwxLjA2NS0uNDYxbC40MjMuNzNsLS45LjczMXEuMTY2LjQyMi4xNjYuODc4dC0uMTY2Ljg3MmwuOTIuNjkybC0uNDIzLjcybC0xLjA4NS0uNDMxcS0uMjk0LjMxNS0uNjYzLjUydC0uNzgzLjI5MWwtLjEyNyAxLjE1NHptLjQwNS0yLjAxOXEuNzQ3IDAgMS4yNzYtLjUzMnQuNTMtMS4yNzh0LS41MzEtMS4yNzZ0LTEuMjc4LS41M3EtLjc0NyAwLTEuMjc3LjUzMnQtLjUzIDEuMjc4dC41MzIgMS4yNzZ0MS4yNzguNTNNMTAgMTAuMzg0cS44MjUgMCAxLjQxMy0uNTg3VDEyIDguMzg1dC0uNTg3LTEuNDEzVDEwIDYuMzg1dC0xLjQxMi41ODdUOCA4LjM4NXQuNTg4IDEuNDEydDEuNDEyLjU4OG0uMyA3LjIzIi8+PC9zdmc+"/>
				<img @click="familyAdd" class="add" src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMTAiIGhlaWdodD0iMTEwIiB2aWV3Qm94PSIwIDAgMjQgMjQiPjxwYXRoIGZpbGw9IiMwMGU2ODIiIGQ9Ik0xMiAyMXEtLjQyNSAwLS43MTItLjI4OFQxMSAyMHYtN0g0cS0uNDI1IDAtLjcxMi0uMjg4VDMgMTJ0LjI4OC0uNzEyVDQgMTFoN1Y0cTAtLjQyNS4yODgtLjcxMlQxMiAzdC43MTMuMjg4VDEzIDR2N2g3cS40MjUgMCAuNzEzLjI4OFQyMSAxMnQtLjI4OC43MTNUMjAgMTNoLTd2N3EwIC40MjUtLjI4OC43MTNUMTIgMjEiLz48L3N2Zz4="/>
				<img @click="familyRemove" class="remove" src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMTAiIGhlaWdodD0iMTEwIiB2aWV3Qm94PSIwIDAgMjQgMjQiPjxwYXRoIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2UxMWQ0OCIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjEuNSIgZD0iTTIwIDEySDQiIGNvbG9yPSIjZTExZDQ4Ii8+PC9zdmc+"/>
			</div>
			<list-view #id="family-user-list" #listen:select="select" :def_select="false" class="list"></list-view>
		</div>
		<button #id="bind-pass" @click="bindPass" class="btn bind">绑定通行证</button>
		<button #id="remove-bind-pass" @click="removeBindPass" class="btn remove-bind">解绑通行证</button>
		<div #id="admin-template" style="display: none">
			<div #id="member-admin">
				<div class="tally-all">
					<label>使用</label>
					<switch-button #name="tally-all" #listen:switch="tallyAllSwitch"/>
				</div>
				<fieldset>
					<legend>账本</legend>
					<div>
						<label>创建</label>
						<switch-button #name="tally-create"/>
					</div>
					<div>
						<label>回收</label>
						<switch-button #name="tally-recycle"/>
					</div>
					<div>
						<label>恢复</label>
						<switch-button #name="tally-recover"/>
					</div>
					<div>
						<label>删除</label>
						<switch-button #name="tally-remove"/>
					</div>
					<div>
						<label>编辑</label>
						<switch-button #name="tally-edit"/>
					</div>
				</fieldset>
				<fieldset>
					<legend>记账记录</legend>
					<div>
						<label>添加</label>
						<switch-button #name="tally-record-add"/>
					</div>
					<div>
						<label>删除</label>
						<switch-button #name="tally-record-remove"/>
					</div>
					<div>
						<label>编辑</label>
						<switch-button #name="tally-record-edit"/>
					</div>
				</fieldset>
			</div>
			<div #id="member-add">
				<div>
					<label>成员 ID</label>
					<edit #name="member-id" :maxlength="64"/>
				</div>
				<div>
					<label>成员名字</label>
					<edit #name="member-name" :maxlength="64"/>
				</div>
			</div>
		</div>
    </div>
</template>

<global>
	const {
		$view,
		$passInput,
		$familyUserList,
		$bindPass,
		$removeBindPass,
		$familyUserAdmin,
	    $adminTemplate,
		$memberAdmin,
		$memberAdd
	} = $id();

	const pdv = magic.importM( "ui/pop-down-view" );

	let vip = null,family = null;

    let current_family_user_id = null;

	function select( item ) {
		current_family_user_id = item.getAttribute( "f-id" ) ;
	}

	function hide() {
		$bindPass.style.display = "none";
		$removeBindPass.style.display = "none";
		$familyUserAdmin.style.display = "none";
	}

	function refresh() {
        $familyUserList.innerHTML = null;
        current_family_user_id = null;
        vip = null;
        family = null;

		$passInput.interface.setValue( Setting.get( "应用设置.设置远程服务器.通行证" ) );

		hide();

		if ( Setting.get( "应用设置.设置远程服务器.通行证" ) === Setting.NOP ) return;

		Pass.checkPassIsBind().then( async r => {
			if ( !r || ( r.isBind && !r.isMe ) ) return;
			if ( r.isBind && r.isMe ) {
				$removeBindPass.style.display = "block";

				vip = await Pass.getVip();
                family = await Pass.getFamily();
				if ( family ) {
					$familyUserAdmin.style.display = "block";
					family.member.forEach( mem => {
						const item = magic.importM( "magic-ui/ui/widget/item" );
						item.setAttribute( "f-id", mem.userID );
                        item.innerHTML = `<label>${mem.name}</label>`;
                        $familyUserList.appendChild(item);
					} );
                    family = family.member;
				}
				return;
			}
			if ( !r.isBind ) {
				$bindPass.style.display = "block";
			}
		} ).catch( e => {
			Log.error( e );
			MagicUi.feedback.message( {
				text : e,
				eventLevel : MagicUi.previa.feedback.message.EventLevel.error
			} );
		} );
	}

    function tallyAllSwitch(bool) {
		$memberAdmin.setAttribute("all",bool);
    }
</global>

<script>
	refresh();

    pdv.interface.init( $view );
</script>

<event>
	familyAdmin = () => {
		if ( current_family_user_id === null ) {
			MagicUi.feedback.message( {
				text : `请先选择一位家庭成员`,
				eventLevel : MagicUi.previa.feedback.message.EventLevel.warning
			} );
			return;
		}
		const t = family.filter( mem => mem.userID === current_family_user_id ).at( 0 );

		const authority = t.authority;

		$memberAdmin.$name( "tally-all" ).interface.setState( t.use );
		$memberAdmin.setAttribute( "all", t.use );

		$memberAdmin.$name( "tally-create" ).interface.setState( authority.tally.create );
		$memberAdmin.$name( "tally-remove" ).interface.setState( authority.tally.remove );
		$memberAdmin.$name( "tally-edit" ).interface.setState( authority.tally.edit );
		$memberAdmin.$name( "tally-recover" ).interface.setState( authority.tally.recover );
		$memberAdmin.$name( "tally-recycle" ).interface.setState( authority.tally.recycle );

		$memberAdmin.$name( "tally-record-add" ).interface.setState( authority.tallyRecord.add );
		$memberAdmin.$name( "tally-record-edit" ).interface.setState( authority.tallyRecord.edit );
		$memberAdmin.$name( "tally-record-remove" ).interface.setState( authority.tallyRecord.remove );

		magic.importM( "ui/dialog" ).interface.init( {
			content : $memberAdmin,
			title : "管理该成员的权限",
			group : {
				"保存" : () => {
					const newAuthority = {
						tally : {
							create : $memberAdmin.$name( "tally-create" ).interface.getState(),
							remove : $memberAdmin.$name( "tally-remove" ).interface.getState(),
							edit : $memberAdmin.$name( "tally-edit" ).interface.getState(),
							recover : $memberAdmin.$name( "tally-recover" ).interface.getState(),
							recycle : $memberAdmin.$name( "tally-recycle" ).interface.getState()
						},
						tallyRecord : {
							add : $memberAdmin.$name( "tally-record-add" ).interface.getState(),
							edit : $memberAdmin.$name( "tally-record-edit" ).interface.getState(),
							remove : $memberAdmin.$name( "tally-record-remove" ).interface.getState()
						}
					};
					Pass.updateFamilyAuthority( {
						userID : current_family_user_id,
						use : $memberAdmin.$name( "tally-all" ).interface.getState(),
						authority : newAuthority
					} ).then( refresh ).catch();
					$adminTemplate.appendChild( $memberAdmin );
					return true;
				},
				"取消" : () => {
					$adminTemplate.appendChild( $memberAdmin );
					return true;
				}
			}
		} );
	}

	familyAdd = () => {
		magic.importM( "ui/dialog" ).interface.init( {
			content : $memberAdd,
			title : "添加成员",
			group : {
				"确定" : () => {
					const id = $memberAdd.$name( "member-id" ).interface.getValue();
					const name = $memberAdd.$name( "member-name" ).interface.getValue();
					const t = family.findLast( mem => mem.userID === id );
					if ( t ) {
						MagicUi.feedback.message( {
							text : `重复成员 ID [${ t.name }]`,
							eventLevel : MagicUi.previa.feedback.message.EventLevel.warning
						} );
						return false;
					}
					Pass.addFamilyMember( {
						userID : id,
						name : name
					} ).then( refresh ).catch();
					$adminTemplate.appendChild( $memberAdd );
					$memberAdd.$name( "member-id" ).interface.setValue( "" );
					$memberAdd.$name( "member-name" ).interface.setValue( "" );
					return true;
				},
				"取消" : () => {
					$adminTemplate.appendChild( $memberAdd );
					return true;
				}
			}
		} );
	}

	familyRemove = () => {
		if ( current_family_user_id === null ) {
			MagicUi.feedback.message( {
				text : `请先选择一位家庭成员`,
				eventLevel : MagicUi.previa.feedback.message.EventLevel.warning
			} );
			return;
		}
		magic.importM( "ui/dialog" ).interface.init( {
			content : family.filter( mem => mem.userID === current_family_user_id ).at( 0 ).name,
			title : "是否移除这位家庭成员?",
			group : {
				"确定" : () => {
					Pass.removeFamilyMember( current_family_user_id ).then( refresh ).catch();
					return true;
				},
				"取消" : () => {
					return true;
				}
			}
		} );
	}

	passCopy = ( ev ) => {
		navigator.clipboard.writeText( Setting.get( "应用设置.设置远程服务器.通行证" ) ).then( r => {
			if ( ev.target.textContent === "复制成功" ) return;
			ev.target.textContent = "复制成功";
			setTimeout( () => {
				ev.target.textContent = "复制";
			}, 800 );
		} );
	}

	bindPass = () => {
		hide();
		Pass.bindPass().then( r => {
			refresh();
		} ).catch( e => {
			Log.error( e );
			MagicUi.feedback.message( {
				text : e,
				eventLevel : MagicUi.previa.feedback.message.EventLevel.error
			} );
		} );
	}

	removeBindPass = () => {
		magic.importM( "ui/dialog" ).interface.init( {
			content : "您可在稍后重新绑定",
			title : "是否解除绑定?",
			group : {
				"确定" : () => {
					hide();
					Pass.removeBindPass().then( r => {
						refresh();
					} ).catch( e => {
						Log.error( e );
						MagicUi.feedback.message( {
							text : e,
							eventLevel : MagicUi.previa.feedback.message.EventLevel.error
						} );
					} );
					return true;
				},
				"取消" : () => {
					return true;
				}
			}
		} );
	}
</event>

<css scope="#id:member-admin">
	& {
		display: flex;
		flex-direction: column;
		gap: 10px;

		padding: 6px;

		& > fieldset > div,
		.tally-all {
			display: flex;
			align-items: center;
			justify-content: space-between;

			margin-top: 8px;
			margin-bottom: 8px;
		}

		&[all="false"] > fieldset {
			pointer-events: none;
			background-color: #c0c0c0;
		}
	}
</css>

<css scope="#id:member-add">
	& {
		display: flex;
		flex-direction: column;
		gap: 10px;

		padding: 6px;

		& > div {
			display: flex;
			align-items: center;
			justify-content: space-between;
			gap: 10px;

			font-size: large;
		}
	}
</css>

<css scope="#id:view" default-theme>
	& {
		& > .pass-info > label {
			border-radius: 8px;
			background-color: #ffffff;
			box-shadow: rgba(0, 0, 0, 0.16) 0px 1px 4px;
		}

		.opr-btn {
			border: solid 1.5px #8de2df;
			background-color: white;
			border-radius: 6px;
		}

		.pass-input {
			border-color: #8de2df;
		}

		& > .family-user-admin {

			& > .bar {

				& > label {
					border-radius: 8px;
					background-color: #ffffff;
					box-shadow: rgba(0, 0, 0, 0.16) 0px 1px 4px;
				}
			}

			& > .list {
				border-radius: 10px;

				background-color: white;
			}
		}

		& > .btn {
			border-radius: 20px;

			&.bind {
				background-color: #44ff69;
			}

			&.remove-bind {
				background-color: #ff3131;
			}
		}
	}
</css>

<css scope="#id:view">
	& {
		padding: 15px;

		display: flex;
		gap: 20px;
		align-items: center;
		flex-direction: column;

		margin-bottom: 20px;

		width: 100%;

		* {
			text-wrap: nowrap;
		}

		& > .pass-info > label {
			padding: 10px;
		}

		.opr-btn {
			padding: 8px;
		}

		&::-webkit-scrollbar {
			width: 0px;
			height: 0px;
		}

		& > .pass-info {
			display: flex;
			align-items: flex-start;
			flex-direction: column;
			gap: 10px;

			width: 100%;

			& > div {
				display: flex;
				align-items: center;
				flex-direction: row;
				gap: 10px;

				width: 100%;

				& > .pass-input {
					width: 100%;
				}
			}
		}

		& > .family-user-admin {
			display: flex;
			align-items: center;
			flex-direction: column;
			gap: 8px;

			width: 100%;
			height: 100%;

			& > .bar {
				display: flex;
				align-items: center;
				justify-content: flex-start;
				gap: 10px;

				width: 100%;
				min-height: 45px;
				max-height: 45px;

				& > label {
					padding: 8px;
				}

				img {
					width: 32px;
					height: 32px;

					&:active {
						scale: .9;
					}
				}
			}

			& > .list {
				width: 100%;
				height: 100%;
				min-height: 160px;
				max-height: 360px;

				overflow: auto;

				& > *[m-item] {
					min-height: 45px;
					max-height: 45px;

					display: flex;
					align-items: center;
					justify-content: flex-start;

					label {
						padding: 0 10px 0 10px;
					}
				}
			}
		}

		& > .btn {
			width: 80%;
			height: 60px;
			text-align: center;
			position: relative;
			left: 50%;
			transform: translateX(-62%);
			padding: 10px;
			margin-top: 20px;
			font-size: x-large;
		}
	}
</css>