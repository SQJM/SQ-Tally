<import
	root="magic-ui/ui"
>
	<module:widget>
		<item/>
	</module:widget>

	<module:input>
		<edit/>
	</module:input>

	<module:control>
		<list-view/>
	</module:control>
</import>

<template>
    <div #id="view">
		<div class="pass-info">
			<label>当前通行证</label>
			<div>
				<edit #id="pass-input" :readonly="true" class="pass-input"/>
				<button @click="passCopy" class="opr-btn">复制</button>
			</div>
		</div>
		<div #id="token-info" class="token-info">
			<label>当前 Token: <span>99999</span></label>
			<label>已使用 Token: <span>99999</span></label>
		</div>
		<button #id="bind-pass" class="btn bind">绑定通行证</button>
		<button #id="remove-bind-pass" class="btn remove-bind">解绑通行证</button>
    </div>
</template>

<global>
	const {
		$view,
		$passInput,
		$bindPass,
		$removeBindPass,
		$familyUserAdmin
	} = $id();

	const pdv = magic.importM( "ui/pop-down-view" );

	function select( item ) {
		console.log( item.getAttribute( "f-id" ) )
	}

	function refresh() {
		$passInput.interface.setValue( Setting.get( "ai设置.设置ai服务器.通行证" ) );

		if ( Setting.get( "ai设置.设置ai服务器.通行证" ) === Setting.NOP ) {
			$bindPass.style.display = "none";
			$removeBindPass.style.display = "none";
		}

		// 未绑定
		$removeBindPass.style.display = "none";
	}
</global>

<script>
	refresh();

    pdv.interface.init( $view );
</script>

<event>
	passCopy = ( ev ) => {
		navigator.clipboard.writeText( Setting.get( "ai设置.设置ai服务器.通行证" ) ).then( r => {
			if ( ev.target.textContent === "复制成功" ) return;
			ev.target.textContent = "复制成功";
			setTimeout( () => {
				ev.target.textContent = "复制";
			}, 800 );
		} );
	}
</event>

<css scope="#id:view" default-theme>
	& {
		& > .pass-info > label {
			border-radius: 8px;
			background-color: #ffffff;
			box-shadow: rgba(0, 0, 0, 0.16) 0px 1px 4px;
		}

		.opr-btn {
			border: solid 1.5px #8de2df;
			background-color: white;
			border-radius: 6px;
		}

		.pass-input {
			border-color: #8de2df;
		}

		& > .token-info {


		}

		& > .btn {
			border-radius: 20px;

			&.bind {
				background-color: #44ff69;
			}

			&.remove-bind {
				background-color: #ff3131;
			}
		}
	}
</css>

<css scope="#id:view">
	& {
		padding: 15px;

		display: flex;
		gap: 20px;
		align-items: center;
		flex-direction: column;

		margin-bottom: 20px;

		width: 100%;

		* {
			text-wrap: nowrap;
		}

		& > .pass-info > label {
			padding: 10px;
		}

		.opr-btn {
			padding: 8px;
		}

		&::-webkit-scrollbar {
			width: 0px;
			height: 0px;
		}

		& > .pass-info {
			display: flex;
			align-items: flex-start;
			flex-direction: column;
			gap: 10px;

			width: 100%;

			& > div {
				display: flex;
				align-items: center;
				flex-direction: row;
				gap: 10px;

				width: 100%;

				& > .pass-input {
					width: 100%;
				}
			}
		}

		& > .token-info {
			display: flex;
			align-items: center;
			flex-direction: column;
			gap: 8px;

			width: 100%;
			height: 100%;
		}

		& > .btn {
			width: 80%;
			height: 60px;
			text-align: center;
			position: relative;
			left: 50%;
			transform: translateX(-62%);
			padding: 10px;
			margin-top: 20px;
			font-size: x-large;
		}
	}
</css>