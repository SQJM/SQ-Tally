<import
	root="magic-ui/ui"
>
	<module:input>
		<edit/>
	</module:input>
</import>

<template>
    <div #id="view">
        <div>
            <label>服务器 IP</label>
            <edit #id="ip" class="w"/>
        </div>
        <div>
            <label>通行证</label>
            <edit #id="pass" class="w" :maxlength="255"/>
        </div>
        <button @click="saved" class="add">保存</button>
    </div>
</template>

<global>
	const {
		$view,
		$ip,
		$pass
	} = $id();
</global>

<event>
	saved = () => {
		Page.pause();

		const ip = $ip.interface.getValue(),
			pass = $pass.interface.getValue();

		TallyServer.test_link( ip, pass ).then( r => {
			MagicUi.feedback.message( {
				text : "连接通过",
				eventLevel : MagicUi.previa.feedback.message.EventLevel.pass
			} );

			App.Current[ "远程服务器状态" ] = true;
		} ).catch( ( e ) => {
			MagicUi.feedback.message( {
				text : `连接失败 ${ e }`,
				eventLevel : MagicUi.previa.feedback.message.EventLevel.error
			} );
			App.Current[ "远程服务器状态" ] = false;
		} ).finally( () => {
			Setting.set( "应用设置.设置远程服务器.ip", ip );
			Setting.set( "应用设置.设置远程服务器.通行证", pass );
			Page.start();
		} );
	}
</event>

<script>
	const pdv = magic.importM( "ui/pop-down-view" );
    pdv.interface.init( $view );

    $ip.interface.setValue( Setting.get( "应用设置.设置远程服务器.ip" ) );
    $pass.interface.setValue( Setting.get( "应用设置.设置远程服务器.通行证" ) );
</script>

<css scope="#id:view">
	& {
		& > .add {
			background-color: #00e75b;

			border-radius: 20px;
		}
	}
</css>

<css scope="#id:view">
	& {
		display: flex;
		flex-direction: column;
		gap: 25px;

		padding: 15px;

		& > div {
			display: flex;
			flex-direction: column;
			gap: 10px;

			label {
				font-size: larger;
			}

			input {
				font-size: medium;
			}

			.w {
				width: 100%;
			}
		}

		& > .add {
			width: 80%;
			height: 60px;

			text-align: center;

			position: relative;
			left: 50%;
			transform: translateX(-50%);

			padding: 10px;
			margin-top: 20px;
			margin-bottom: 20px;

			font-size: x-large;
		}
	}
</css>