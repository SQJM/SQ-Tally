<import
	root="magic-ui/ui"
>
	<module:widget>
		<item/>
	</module:widget>

	<module:input>
		<switch-button/>
	</module:input>

	<module:control>
		<list-view/>
	</module:control>
</import>

<template>
    <div #id="view">
		<list-view #id="list"
				   #listen:select="select"
				   :def_select="false"
				   :repetition="true"
		>
			<item target="#">
				<span>AI 服务器状态</span>
				<switch-button #id="szaifwqzt" #listen:switch="serverStateChange" class="right"/>
			</item>
			<item target="szaifwq">
				<img class="icon" src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMjgiIGhlaWdodD0iMTI4IiB2aWV3Qm94PSIwIDAgMjQgMjQiPjxnIGZpbGw9Im5vbmUiPjxyZWN0IHdpZHRoPSIxOC41IiBoZWlnaHQ9IjcuNSIgeD0iMi43NSIgeT0iMi43NTEiIHN0cm9rZT0iIzQ3YzJmZiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjEuNSIgcng9IjIiLz48Y2lyY2xlIGN4PSI2LjI1IiBjeT0iNi41MDEiIHI9IjEuMjUiIGZpbGw9IiM0N2MyZmYiLz48Y2lyY2xlIGN4PSIxMC4yNSIgY3k9IjYuNTAxIiByPSIxLjI1IiBmaWxsPSIjNDdjMmZmIi8+PHJlY3Qgd2lkdGg9IjE4LjUiIGhlaWdodD0iNy41IiB4PSIyLjc1IiB5PSIxMy43NDkiIHN0cm9rZT0iIzQ3YzJmZiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjEuNSIgcng9IjIiLz48Y2lyY2xlIGN4PSI2LjI1IiBjeT0iMTcuNDk5IiByPSIxLjI1IiBmaWxsPSIjNDdjMmZmIi8+PGNpcmNsZSBjeD0iMTAuMjUiIGN5PSIxNy40OTkiIHI9IjEuMjUiIGZpbGw9IiM0N2MyZmYiLz48L2c+PC9zdmc+"/>
				<span>设置 AI 服务器</span>
				<img class="icon-arrow" src="assets/MaterialSymbolsLightArrowForwardIosRounded.svg"/>
			</item>
			<item target="#">
				<img class="icon" src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMjgiIGhlaWdodD0iMTI4IiB2aWV3Qm94PSIwIDAgMzIgMzIiPjxwYXRoIGZpbGw9IiM0N2MyZmYiIGQ9Ik0yOC40NDcgMTYuMTA2TDIzIDEzLjM4MVY3YTEgMSAwIDAgMC0uNTUzLS44OTRsLTYtM2ExIDEgMCAwIDAtLjg5NCAwbC02IDNBMSAxIDAgMCAwIDkgN3Y2LjM4MmwtNS40NDcgMi43MjNBMSAxIDAgMCAwIDMgMTd2N2ExIDEgMCAwIDAgLjU1My44OTVsNiAzYTEgMSAwIDAgMCAuODk0IDBMMTYgMjUuMTE4bDUuNTUzIDIuNzc3YTEgMSAwIDAgMCAuODk0IDBsNi0zQTEgMSAwIDAgMCAyOSAyNHYtN2ExIDEgMCAwIDAtLjU1My0uODk1TTIxIDEzLjM4MWwtNCAydi00Ljc2NGw0LTJabS01LTguMjY0TDE5Ljc2NCA3TDE2IDguODgyTDEyLjIzNiA3Wm0tNSAzLjVsNCAydjQuNzY0bC00LTJaTTkgMjUuMzgybC00LTJ2LTQuNzY0bDQgMlptMS02LjVMNi4yMzYgMTdMMTAgMTUuMTE4TDEzLjc2NCAxN1ptMSAxLjczNmw0LTJ2NC43NjRsLTQgMlptMTAgNC43NjRsLTQtMnYtNC43NjRsNCAyWm0xLTYuNUwxOC4yMzYgMTdMMjIgMTUuMTE4TDI1Ljc2NCAxN1ptNSA0LjVsLTQgMnYtNC43NjRsNC0yWiIvPjwvc3ZnPg=="/>
				<span>AI 模型</span>
				<label #id="select-ai-model" @click="selectAiModel" class="right-max">未选择</label>
			</item>
		</list-view>
    </div>
</template>

<global>
	const {
		$view,
		$list,
		$selectAiModel,
		$szaifwqzt
	} = $id();

	function refresh() {
		$selectAiModel.textContent = Setting.get( "ai设置.当前ai模型" ) === Setting.NOP ? "未选择" : Setting.get( "ai设置.当前ai模型" );
		$szaifwqzt.interface.setState( Setting.get( "ai设置.AI服务器状态" ) === Setting.TRUE );
	}

	function select( item ) {
		if ( item.getAttribute( "target" ).at( 0 ) === "#" ) return;
		magic.importM( `ui/setting/ai/${ item.getAttribute( "target" ) }` );
	}

	function serverStateChange( state ) {
		Setting.set( "ai设置.AI服务器状态", `${ state }`.toUpperCase() );
		if ( state ) {
			if ( Setting.get( "ai设置.设置ai服务器.ip" ) !== Setting.NOP )
				Ai.test_link( Setting.get( "ai设置.设置ai服务器.ip" ) ).then( r => {
					MagicUi.feedback.message( {
						text : "ai服务器,连接通过",
						eventLevel : MagicUi.previa.feedback.message.EventLevel.pass
					} );
					App.Current[ "ai服务器状态" ] = true;
				} ).catch( ( e ) => {
					Log.error( e );
					MagicUi.feedback.message( {
						text : `ai服务器,连接失败 ${ e }`,
						eventLevel : MagicUi.previa.feedback.message.EventLevel.error
					} );
					App.Current[ "ai服务器状态" ] = false;
				} );
		} else {
			App.Current[ "ai服务器状态" ] = false;
		}
		refresh();
	}
</global>

<script>
	magic.importM( "ui/pop-view", _args ).interface.init( $view, "AI 管理" );

    refresh();
</script>

<event>
	selectAiModel = async () => {
		if ( !App.Current[ "ai服务器状态" ] )
			MagicUi.feedback.message( {
				text : `未连接AI服务器`,
				eventLevel : MagicUi.previa.feedback.message.EventLevel.warning
			} );
		const result = await Ai.getModels();
		magic.importM( "ui/pop-select-list" ).interface.init( async ( target ) => {
			if ( target.textContent === "暂不设置" ) target.textContent = Setting.NOP;
			Setting.set( "ai设置.当前ai模型", target.textContent );
			refresh();
			return true;
		}, [ "暂不设置", ...result[ "data" ].map( o => o.id ) ] );
	}
</event>

<css scope="#id:view" default-theme>
	& {
		background-color: #f2faff;
		border-radius: 20px;

		box-shadow: rgba(0, 0, 0, 0.16) 0px 1px 4px;

		& > div {
			background-color: rgba(242, 250, 255, 0.15);


			& > *[m-item] {
				background-color: rgba(255, 255, 255, 0);

				&[m-select] {
					background-color: rgba(255, 255, 255, 0);
				}

				&:active {
					background-color: rgba(0, 0, 0, 0.1);
				}

				& > label {
					background-color: #fff;
					border-radius: 10px;
					box-shadow: rgba(0, 0, 0, 0.02) 0px 1px 3px 0px, rgba(27, 31, 35, 0.15) 0px 0px 0px 1px;
				}
			}
		}
	}
</css>

<css scope="#id:view">
	& {
		overflow: auto;

		& > div {
			width: 100%;

			& > *[m-item] {
				padding: 15px;
				display: flex;
				align-items: center;
				gap: 15px;
				min-height: 65px;

				position: relative;

				& > .icon {
					width: 30px;
				}

				& > .icon-arrow {
					width: 20px;

					margin-left: auto;
				}

				& > span {
					text-wrap: nowrap;

					text-align: center;

					max-width: 100%;
					min-width: max-content;

					overflow: hidden;

					text-overflow: ellipsis;
				}

				& > .right-max {
					text-align: center;

					width: 100%;

					padding: 6px;

					overflow: hidden;

					text-overflow: ellipsis;
				}

				& > .right {
					position: absolute;
					right: 15px;
				}
			}
		}
	}
</css>