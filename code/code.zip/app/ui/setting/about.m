<template>
    <div #id="view">
		<div>
			<p>
				<label>软件名字:</label>
				<span>神奇记账</span>
			</p>
			<p>
				<label>作者:</label>
				<span>Wang Jia Ming</span>
			</p>
			<p>
				<label>开源协议:</label>
				<span>MIT</span>
			</p>
			<p>
				<label>项目地址:</label>
				<span>https://github.com/SQJM/SQ-Tally</span>
			</p>
		</div>
		<div class="box">
			<h3>开源代码</h3>
			<div class="list">
				<p><span>*magic</span></p>
				<p><span>*magic-ui</span></p>
				<p><span>YesIcon</span><a>yesicon.app/</a></p>
				<p><span>crypto-js</span><a>github.com/brix/crypto-js</a></p>
				<p><span>echarts</span><a>echarts.apache.org/zh/index.html</a></p>
				<p><span>highlight</span><a>highlightjs.org/</a></p>
				<p><span>marked</span><a>github.com/markedjs/marked</a></p>
				<p><span>marked-highlight</span></p>
				<p><span>math</span><a>mathjs.org/</a></p>
			</div>
		</div>
    </div>
</template>

<global>
	const {
		$view
	} = $id();
</global>

<script>
	magic.importM( "ui/pop-view", _args ).interface.init( $view, "关于 神奇账本" );
</script>

<css scope="#id:view" default-theme>
	& {
		background-color: #f2faff;
		border-radius: 20px;
		box-shadow: rgba(0, 0, 0, 0.16) 0px 1px 4px;
	}
</css>

<css scope="#id:view">
	& {
		overflow: auto;

		&::-webkit-scrollbar {
			width: 0px;
			height: 0px;
		}

		padding: 10px;

		& > .box {
			& > .list {
				display: flex;
				flex-direction: column;

				p {
					display: flex;
					flex-direction: column;
					gap: 2px;

					span {
						font-size: large;
					}

					a {
						color: #000087;
					}
				}
			}
		}
	}
</css>