<import
	root="magic-ui/ui"
>
	<module:widget>
		<item/>
	</module:widget>

	<module:control>
		<list-view/>
	</module:control>
</import>

<template>
    <div #id="view">
        <div class="opa">
            <img @click="opa_add" class="add" src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMjgiIGhlaWdodD0iMTI4IiB2aWV3Qm94PSIwIDAgNDggNDgiPjxkZWZzPjxtYXNrIGlkPSJJY29uaWZ5SWQxOTU3MmRjM2ZiMGMxZjU0MzUiPjxnIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2ZmZiIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIgc3Ryb2tlLXdpZHRoPSI0Ij48cmVjdCB3aWR0aD0iMzYiIGhlaWdodD0iMzYiIHg9IjYiIHk9IjYiIGZpbGw9IiM1NTUiIHJ4PSIzIi8+PHBhdGggc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBkPSJNMjQgMTZ2MTZtLTgtOGgxNiIvPjwvZz48L21hc2s+PC9kZWZzPjxwYXRoIGZpbGw9IiM0N2MyZmYiIGQ9Ik0wIDBoNDh2NDhIMHoiIG1hc2s9InVybCgjSWNvbmlmeUlkMTk1NzJkYzNmYjBjMWY1NDM1KSIvPjwvc3ZnPg=="/>
            <img @click="opa_del" class="del" src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMjgiIGhlaWdodD0iMTI4IiB2aWV3Qm94PSIwIDAgMjQgMjQiPjxwYXRoIGZpbGw9IiNkYzI2MjYiIGQ9Im05LjQgMTYuNWwyLjYtMi42bDIuNiAyLjZsMS40LTEuNGwtMi42LTIuNkwxNiA5LjlsLTEuNC0xLjRsLTIuNiAyLjZsLTIuNi0yLjZMOCA5LjlsMi42IDIuNkw4IDE1LjF6TTcgMjFxLS44MjUgMC0xLjQxMi0uNTg3VDUgMTlWNkg0VjRoNVYzaDZ2MWg1djJoLTF2MTNxMCAuODI1LS41ODcgMS40MTNUMTcgMjF6TTE3IDZIN3YxM2gxMHpNNyA2djEzeiIvPjwvc3ZnPg=="/>
            <img @click="opa_rec" class="rec" src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMjgiIGhlaWdodD0iMTI4IiB2aWV3Qm94PSIwIDAgMjQgMjQiPjxwYXRoIGZpbGw9IiMzMzMzMzMiIGQ9Ik0xNSAxM2gxLjV2Mi44MmwyLjQ0IDEuNDFsLS43NSAxLjNMMTUgMTYuNjl6bTggM2MwIDMuODctMy4xMyA3LTcgN2MtMS45MSAwLTMuNjQtLjc2LTQuOS0ySDhjLTEuMSAwLTItLjktMi0yVjdoMTJ2Mi4yOWMyLjg5Ljg2IDUgMy41NCA1IDYuNzFNOSAxNmMwLTMuODcgMy4xMy03IDctN0g4djEwaDEuNjdjLS40My0uOTEtLjY3LTEuOTMtLjY3LTNtNy01Yy0yLjc2IDAtNSAyLjI0LTUgNXMyLjI0IDUgNSA1czUtMi4yNCA1LTVzLTIuMjQtNS01LTVtLS41LTdIMTl2Mkg1VjRoMy41bDEtMWg1eiIvPjwvc3ZnPg=="/>
        </div>
        <list-view #id="list-0" #listen:select="set1_select" #listen:select_stop_bubbling="listOpr" :def_select="false" :repetition="true"></list-view>
    </div>
</template>

<global>
	const {
		$view,
		$list0
	} = $id();

	let current_item_id = null;

	function close() {
		$view.style.animation = `disappear-above .5s forwards`;
		$view.onanimationend = () => {
			$view.remove();
		}
	}

	function set1_select(e) {
		current_item_id = e.getAttribute("id");
	}

	function createItem( o ) {
		const item = magic.importM( "magic-ui/ui/widget/item" );
		if ( o.storage.type === "cloud" ) {
			item.setAttribute( "cloud", "" );
		}
		item.setAttribute( "id", o.id );
		item.interface.setHTML(`<img class="cloud" src="assets/MaterialSymbolsCloud.svg"/>
	<img class="icon" src="assets/OpenmojiLedger.svg"/>
	<div class="box">
	<span>${o.name}</span>
	<p>${o.description}</p>
	</div>
	<div class="opa">
	<img event="edit" m-stop-bubbling src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMjgiIGhlaWdodD0iMTI4IiB2aWV3Qm94PSIwIDAgMjQgMjQiPjxnIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzMzMzMzMyIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjIiPjxwYXRoIGQ9Im0xNi40NzUgNS40MDhsMi4xMTcgMi4xMTdtLS43NTYtMy45ODJMMTIuMTA5IDkuMjdhMi4xIDIuMSAwIDAgMC0uNTggMS4wODJMMTEgMTNsMi42NDgtLjUzYy40MS0uMDgyLjc4Ni0uMjgzIDEuMDgyLS41NzlsNS43MjctNS43MjdhMS44NTMgMS44NTMgMCAxIDAtMi42MjEtMi42MjEiLz48cGF0aCBkPSJNMTkgMTV2M2EyIDIgMCAwIDEtMiAySDZhMiAyIDAgMCAxLTItMlY3YTIgMiAwIDAgMSAyLTJoMyIvPjwvZz48L3N2Zz4="/>
	<img event="out" m-stop-bubbling src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMjgiIGhlaWdodD0iMTI4IiB2aWV3Qm94PSIwIDAgMjQgMjQiPjxwYXRoIGZpbGw9IiM0N2MyZmYiIGQ9Ik04LjcxIDcuNzFMMTEgNS40MVYxNWExIDEgMCAwIDAgMiAwVjUuNDFsMi4yOSAyLjNhMSAxIDAgMCAwIDEuNDIgMGExIDEgMCAwIDAgMC0xLjQybC00LTRhMSAxIDAgMCAwLS4zMy0uMjFhMSAxIDAgMCAwLS43NiAwYTEgMSAwIDAgMC0uMzMuMjFsLTQgNGExIDEgMCAxIDAgMS40MiAxLjQyTTIxIDE0YTEgMSAwIDAgMC0xIDF2NGExIDEgMCAwIDEtMSAxSDVhMSAxIDAgMCAxLTEtMXYtNGExIDEgMCAwIDAtMiAwdjRhMyAzIDAgMCAwIDMgM2gxNGEzIDMgMCAwIDAgMy0zdi00YTEgMSAwIDAgMC0xLTEiLz48L3N2Zz4="/>
	</div>`);
		return item;
	}

	function refreshList() {
        current_item_id = null;
        Tally.getAllTally( Tally.State.normal ).then( r => {
            $list0.innerHTML = null;
            r.forEach( o=> $list0.appendChild( createItem( o ) ) );
        });
	}

    function listOpr( item, target ) {
        if( !target.hasAttribute( "event" ) ) return;
		const event = target.getAttribute( "event" );
        if( event === "edit" ){
            magic.importM( "ui/setting/tally-opa/edit" ).interface.init( item.getAttribute("id") );
		}
	}
</global>

<event>
	opa_add = () => {
		magic.importM( "ui/setting/tally-opa/add" );
	}

	opa_del = () => {
		if ( !current_item_id ) {
			MagicUi.feedback.message( {
				text : `没有选择账本`,
				eventLevel : MagicUi.previa.feedback.message.EventLevel.info
			} );
			return;
		}
		Tally.getInfo( current_item_id ).then( r => {
			magic.importM( "ui/dialog" ).interface.init( {
				content : r.name,
				title : "是否删除账本?",
				group : {
					"确定" : () => {
						Tally.recycle( current_item_id ).then( () => {
							MagicUi.feedback.message( {
								text : `账本移除成功`,
								eventLevel : MagicUi.previa.feedback.message.EventLevel.pass
							} );
						} ).catch( e => {
							Log.error( `账本移除失败: ${ e }` );
							MagicUi.feedback.message( {
								text : `账本移除失败 ${ e }`,
								eventLevel : MagicUi.previa.feedback.message.EventLevel.error
							} );
						} );
						return true;
					},
					"取消" : () => {
						return true;
					}
				}
			} );
		} );
	}

	opa_rec = () => {
		magic.importM( "ui/setting/tally-opa/rec" );
	}
</event>

<script>
	magic.importM( "ui/pop-view", _args ).interface.init( $view, "账本管理" );

    refreshList();
    EventList.register( EventListName.TALLY_CHANGE, _args._file, ( bool ) => {
        refreshList();
    } );

    EventList.register( EventListName.REMOTE_SERVER_STATUS_CHANGE, _args._file, ( c, o ) => {
        refreshList();
    } );

    SSEServer.register( [
        "/tally/create",
        "/tally/remove",
        "/tally/recycle",
        "/tally/recover",
        "/tally/update"
    ], _args._file, () => refreshList() );
</script>

<css scope="#id:view" default-theme>
	& {
		& > div {
			background-color: #e5fafb;

			box-shadow: rgba(0, 0, 0, 0.16) 0px 1px 4px;

			border-radius: 20px;

			& > *[m-item] {
			}
		}

		& > .opa {
			background-color: #f2faff;

			box-shadow: rgba(0, 0, 0, 0.16) 0px 1px 4px;
		}
	}
</css>

<css scope="#id:view">
	& {
		& > .list-view {
			overflow: auto;
			height: calc(100% - 75px);

			& > *[m-item] {
				display: flex;
				align-items: center;
				gap: 5px;

				padding: 20px 10px 20px 10px;

				& > .cloud {
					display: none;
				}

				& > .icon {
					width: 50px;
					height: 50px;
				}

				&[cloud] > .cloud {
					display: block;
					position: absolute;
					scale: .16;
					left: -9px;
				}

				& > .box {
					display: flex;
					flex-direction: column;

					margin-right: auto;

					max-width: 50%;

					span, p {
						text-overflow: ellipsis;
						white-space: nowrap;
						overflow: hidden;
					}

					span {
						font-size: larger;
					}

					p {
						margin: 0px;
					}
				}

				& > .opa {
					display: flex;
					align-items: center;
					gap: 5px;

					img {
						width: 35px;
					}
				}
			}
		}

		& > .opa {
			display: flex;
			align-items: center;
			justify-content: space-evenly;

			margin-bottom: 10px;
			padding: 5px;

			img {
				width: 60px;
			}
		}
	}
</css>