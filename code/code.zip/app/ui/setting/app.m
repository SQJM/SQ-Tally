<import
	root="magic-ui/ui"
>
	<module:widget>
		<item/>
	</module:widget>

	<module:input>
		<switch-button/>
	</module:input>

	<module:control>
		<list-view/>
	</module:control>
</import>

<template>
    <div #id="view">
		<list-view #id="list-1"
				   #listen:select="select"
				   :def_select="false"
				   :repetition="true"
		>
			<item target="#">
				<span>远程服务器状态</span>
				<switch-button #id="szycfwqzt" #listen:switch="ycServerStateChange" class="right"/>
			</item>
			<item target="szycfwq">
				<img class="icon" src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMjgiIGhlaWdodD0iMTI4IiB2aWV3Qm94PSIwIDAgMjQgMjQiPjxnIGZpbGw9Im5vbmUiPjxyZWN0IHdpZHRoPSIxOC41IiBoZWlnaHQ9IjcuNSIgeD0iMi43NSIgeT0iMi43NTEiIHN0cm9rZT0iIzQ3YzJmZiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjEuNSIgcng9IjIiLz48Y2lyY2xlIGN4PSI2LjI1IiBjeT0iNi41MDEiIHI9IjEuMjUiIGZpbGw9IiM0N2MyZmYiLz48Y2lyY2xlIGN4PSIxMC4yNSIgY3k9IjYuNTAxIiByPSIxLjI1IiBmaWxsPSIjNDdjMmZmIi8+PHJlY3Qgd2lkdGg9IjE4LjUiIGhlaWdodD0iNy41IiB4PSIyLjc1IiB5PSIxMy43NDkiIHN0cm9rZT0iIzQ3YzJmZiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjEuNSIgcng9IjIiLz48Y2lyY2xlIGN4PSI2LjI1IiBjeT0iMTcuNDk5IiByPSIxLjI1IiBmaWxsPSIjNDdjMmZmIi8+PGNpcmNsZSBjeD0iMTAuMjUiIGN5PSIxNy40OTkiIHI9IjEuMjUiIGZpbGw9IiM0N2MyZmYiLz48L2c+PC9zdmc+"/>
				<span>设置远程服务器</span>
				<img class="icon-arrow" src="assets/MaterialSymbolsLightArrowForwardIosRounded.svg"/>
			</item>
			<item target="#">
				<img class="icon" src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMTAiIGhlaWdodD0iMTEwIiB2aWV3Qm94PSIwIDAgMjQgMjQiPjxnIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2VhYjMwOCIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjEuNSIgY29sb3I9IiNlYWIzMDgiPjxwYXRoIGQ9Ik0yMiAxMmMwIDUuNTIzLTQuNDc3IDEwLTEwIDEwUzIgMTcuNTIzIDIgMTJTNi40NzcgMiAxMiAyczEwIDQuNDc3IDEwIDEwIi8+PHBhdGggZD0iTTkgNy41Yy4yLjkxNyAxLjA4IDMgMyA0bTAgMGMxLjkyLTEgMi44LTMuMDgzIDMtNG0tMyA0djVtMi41LTNoLTUiLz48L2c+PC9zdmc+"/>
				<span>是否开启金额单位显示</span>
				<switch-button #id="sfkqjedwxs" #listen:switch="setMoneyUnitVisibility" class="right"/>
			</item>
			<item target="#">
				<img class="icon" src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMTAiIGhlaWdodD0iMTEwIiB2aWV3Qm94PSIwIDAgMjQgMjQiPjxwYXRoIGZpbGw9IiM0N2MyZmYiIGQ9Im0xMiAxMy41bDYtNGwtNi00em0uNyA1LjVoNS42cS0uMTc1LjY1LS42IDEuMDV0LTEuMS41TDUuNyAyMS44NzVxLS44MjUuMTI1LTEuNDg4LS4zODdUMy40NSAyMC4xNUwyLjEyNSA5LjIyNXEtLjEtLjgyNS40LTEuNDc1VDMuODUgN0w1IDYuODV2MmwtLjkuMTI1TDUuNDUgMTkuOXpNOSAxN3EtLjgyNSAwLTEuNDEyLS41ODdUNyAxNVY0cTAtLjgyNS41ODgtMS40MTJUOSAyaDExcS44MjUgMCAxLjQxMy41ODhUMjIgNHYxMXEwIC44MjUtLjU4NyAxLjQxM1QyMCAxN3ptMC0yaDExVjRIOXptLTMuNTUgNC45Ii8+PC9zdmc+"/>
				<span>是否开启快速应用动画</span>
				<switch-button #id="sfkqyydh" #listen:switch="setAppAnimationVisibility" class="right"/>
			</item>
		</list-view>
    </div>
</template>

<global>
	const {
		$view,
		$szycfwqzt,
		$sfkqjedwxs,
		$sfkqyydh
	} = $id();

	function refresh() {
		$szycfwqzt.interface.setState( Setting.get( "应用设置.远程服务器状态" ) === Setting.TRUE );
		$sfkqjedwxs.interface.setState( Setting.get( "应用设置.金额单位显示" ) === Setting.TRUE );
		$sfkqyydh.interface.setState( Setting.get( "应用设置.快速应用动画" ) === Setting.TRUE );
	}

	function select( item ) {
		if ( item.getAttribute( "target" ).at( 0 ) === "#" ) return;
		magic.importM( `ui/setting/app/${ item.getAttribute( "target" ) }` );
	}

	function ycServerStateChange( state ) {
		Setting.set( "应用设置.远程服务器状态", `${ state }`.toUpperCase() );
		if ( state ) {
			if ( Setting.get( "应用设置.设置远程服务器.ip" ) !== Setting.NOP )
				TallyServer.test_link( Setting.get( "应用设置.设置远程服务器.ip" ) ).then( r => {
					MagicUi.feedback.message( {
						text : "远程服务器,连接通过",
						eventLevel : MagicUi.previa.feedback.message.EventLevel.pass
					} );
					App.Current[ "远程服务器状态" ] = true;
				} ).catch( ( e ) => {
					MagicUi.feedback.message( {
						text : `远程服务器,连接失败 ${ e }`,
						eventLevel : MagicUi.previa.feedback.message.EventLevel.error
					} );
					App.Current[ "远程服务器状态" ] = false
				} );
		} else {
			App.Current[ "ai服务器状态" ] = false;
		}
		refresh();
	}

	function setMoneyUnitVisibility( state ) {
		Setting.set( "应用设置.金额单位显示", `${ state }`.toUpperCase() );
		refresh();
	}

	function setAppAnimationVisibility( state ) {
		Setting.set( "应用设置.快速应用动画", `${ state }`.toUpperCase() );
		App.animationVisibility();
		refresh();
	}
</global>

<script>
	magic.importM( "ui/pop-view", _args ).interface.init( $view, "应用设置" );

    refresh();
</script>

<css scope="#id:view" default-theme>
	& {
		background-color: #f2faff;
		border-radius: 20px;
		box-shadow: rgba(0, 0, 0, 0.16) 0px 1px 4px;

		& > div {
			background-color: rgba(242, 250, 255, 0.15);

			& > *[m-item] {
				background-color: rgba(255, 255, 255, 0);

				&[m-select] {
					background-color: rgba(255, 255, 255, 0);
				}

				&:active {
					background-color: rgba(0, 0, 0, 0.1);
				}
			}
		}
	}
</css>

<css scope="#id:view">
	& {
		overflow: auto;

		& > div {
			width: 100%;

			& > *[m-item] {
				padding: 15px;
				display: flex;
				align-items: center;
				gap: 15px;
				min-height: 65px;

				position: relative;

				& > .icon {
					width: 30px;
				}

				& > .icon-arrow {
					width: 20px;

					margin-left: auto;
				}

				& > span {
					text-wrap: nowrap;

					text-align: center;

					max-width: 100%;

					overflow: hidden;

					text-overflow: ellipsis;
				}

				& > .right-max {
					text-align: center;

					width: 100%;

					padding: 6px;

					overflow: hidden;

					text-overflow: ellipsis;
				}

				& > .right {
					position: absolute;
					right: 15px;
				}
			}
		}
	}
</css>