<import
	root="magic-ui/ui"
>
	<module:widget>
		<item/>
	</module:widget>

	<module:input>
		<edit/>
	</module:input>

	<module:control>
		<list-view/>
	</module:control>
</import>

<template>
    <div #id="view">
        <div class="scope" style="margin-bottom: 20px;">
			<div class="box box-1">
				<div class="user-name-info">
					<label>用户名</label>
					<div>
						<edit #id="name-input" :readonly="true" class="input name-input"/>
						<button @click="nameEdit" class="opr-btn">修改</button>
					</div>
				</div>
				<div class="user-id-info">
					<label>用户ID</label>
					<div>
						<edit #id="id-input" :readonly="true" class="input id-input"/>
						<button @click="idCopy" class="opr-btn">复制</button>
					</div>
				</div>
				<i class="tip">请保管好自己的用户ID！不要泄露给别人！</i>
			</div>
        </div>
		<list-view #id="list-1"
				   #listen:select="select"
				   :def_select="false"
				   :repetition="true"
				   class="list"
		>
			<item target="ycfwqtxzgl">
				<img class="icon" src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMjgiIGhlaWdodD0iMTI4IiB2aWV3Qm94PSIwIDAgMjQgMjQiPjxnIGZpbGw9Im5vbmUiPjxyZWN0IHdpZHRoPSIxOC41IiBoZWlnaHQ9IjcuNSIgeD0iMi43NSIgeT0iMi43NTEiIHN0cm9rZT0iIzQ3YzJmZiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjEuNSIgcng9IjIiLz48Y2lyY2xlIGN4PSI2LjI1IiBjeT0iNi41MDEiIHI9IjEuMjUiIGZpbGw9IiM0N2MyZmYiLz48Y2lyY2xlIGN4PSIxMC4yNSIgY3k9IjYuNTAxIiByPSIxLjI1IiBmaWxsPSIjNDdjMmZmIi8+PHJlY3Qgd2lkdGg9IjE4LjUiIGhlaWdodD0iNy41IiB4PSIyLjc1IiB5PSIxMy43NDkiIHN0cm9rZT0iIzQ3YzJmZiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjEuNSIgcng9IjIiLz48Y2lyY2xlIGN4PSI2LjI1IiBjeT0iMTcuNDk5IiByPSIxLjI1IiBmaWxsPSIjNDdjMmZmIi8+PGNpcmNsZSBjeD0iMTAuMjUiIGN5PSIxNy40OTkiIHI9IjEuMjUiIGZpbGw9IiM0N2MyZmYiLz48L2c+PC9zdmc+"/>
				<span>远程服务器通行证管理</span>
				<img class="icon-arrow" src="assets/MaterialSymbolsLightArrowForwardIosRounded.svg"/>
			</item>
			<item target="aitxzgl">
				<img class="icon" src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMjgiIGhlaWdodD0iMTI4IiB2aWV3Qm94PSIwIDAgMjQgMjQiPjxnIGZpbGw9Im5vbmUiPjxyZWN0IHdpZHRoPSIxOC41IiBoZWlnaHQ9IjcuNSIgeD0iMi43NSIgeT0iMi43NTEiIHN0cm9rZT0iIzQ3YzJmZiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjEuNSIgcng9IjIiLz48Y2lyY2xlIGN4PSI2LjI1IiBjeT0iNi41MDEiIHI9IjEuMjUiIGZpbGw9IiM0N2MyZmYiLz48Y2lyY2xlIGN4PSIxMC4yNSIgY3k9IjYuNTAxIiByPSIxLjI1IiBmaWxsPSIjNDdjMmZmIi8+PHJlY3Qgd2lkdGg9IjE4LjUiIGhlaWdodD0iNy41IiB4PSIyLjc1IiB5PSIxMy43NDkiIHN0cm9rZT0iIzQ3YzJmZiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBzdHJva2Utd2lkdGg9IjEuNSIgcng9IjIiLz48Y2lyY2xlIGN4PSI2LjI1IiBjeT0iMTcuNDk5IiByPSIxLjI1IiBmaWxsPSIjNDdjMmZmIi8+PGNpcmNsZSBjeD0iMTAuMjUiIGN5PSIxNy40OTkiIHI9IjEuMjUiIGZpbGw9IiM0N2MyZmYiLz48L2c+PC9zdmc+"/>
				<span>AI通行证管理</span>
				<img class="icon-arrow" src="assets/MaterialSymbolsLightArrowForwardIosRounded.svg"/>
			</item>
		</list-view>
    </div>
</template>

<global>
	const {
		$view,
		$idInput,
		$nameInput,
		$list0
	} = $id();

	let current_item_id = null;

	function close() {
		$view.style.animation = `disappear-above .5s forwards`;
		$view.onanimationend = () => {
			$view.remove();
		}
	}

	function select( item ) {
		if ( item.getAttribute( "target" ).at( 0 ) === "#" ) return;
		magic.importM( `ui/setting/account/${ item.getAttribute( "target" ) }` );
	}

	function refresh() {
		$idInput.interface.setValue( Setting.get( "用户ID" ) );
		$nameInput.interface.setValue( Setting.get( "用户名" ) );
	}
</global>

<event>
	idCopy = ( ev ) => {
		navigator.clipboard.writeText( Setting.get( "用户ID" ) ).then( r => {
			if ( ev.target.textContent === "复制成功" ) return;
			ev.target.textContent = "复制成功";
			setTimeout( () => {
				ev.target.textContent = "复制";
			}, 800 );
		} );
	}

	nameEdit = () => {
		magic.importM( "ui/dialog" ).interface.init( {
			title : "修改用户名",
			input : true,
			group : {
				"确定" : ( v ) => {
					if ( v.trim() === "" ) {
						MagicUi.feedback.message( {
							text : `用户名不可为空`,
							eventLevel : MagicUi.previa.feedback.message.EventLevel.warning
						} );
						return false;
					}
					Setting.set( "用户名", v.substring( 0, 8 ) );
					refresh();
					return true;
				},
				"取消" : () => {
					return true;
				}
			}
		} );
	}
</event>

<script>
	refresh();

    magic.importM( "ui/pop-view", _args ).interface.init( $view, "账户管理" );
</script>

<css scope="#id:view" default-theme>
	& {
		& > .list {
			background-color: #f2faff;
			border-radius: 20px;
			box-shadow: rgba(0, 0, 0, 0.16) 0px 1px 4px;

			& > *[m-item] {
				background-color: rgba(255, 255, 255, 0);

				&[m-select] {
					background-color: rgba(255, 255, 255, 0);
				}

				&:active {
					background-color: rgba(0, 0, 0, 0.1);
				}
			}
		}

		& > .scope {
			box-shadow: rgba(0, 0, 0, 0.16) 0px 1px 4px;

			.opr-btn {
				border: solid 1.5px #8de2df;
				background-color: white;
				border-radius: 6px;
			}

			.id-input, .name-input {
				border-color: #8de2df;
			}

			background-color: #f2faff;

			border-radius: 10px;

			& > .box {
				& > .user-name-info > label,
				& > .user-id-info > label {
					border-radius: 8px;
					background-color: #ffffff;
					box-shadow: rgba(0, 0, 0, 0.16) 0px 1px 4px;
				}
			}
		}
	}
</css>

<css scope="#id:view">
	& {
		display: flex;
		gap: 10px;
		flex-direction: column;

		* {
			text-wrap: nowrap;
		}

		& > .list {
			width: 100%;
			height: 100%;

			overflow: auto;

			& > *[m-item] {
				padding: 15px;
				display: flex;
				align-items: center;
				gap: 15px;
				min-height: 65px;

				position: relative;

				& > .icon {
					width: 30px;
				}

				& > .icon-arrow {
					width: 20px;

					margin-left: auto;
				}

				& > span {
					text-wrap: nowrap;

					text-align: center;

					max-width: 100%;

					overflow: hidden;

					text-overflow: ellipsis;
				}

				& > .right-max {
					text-align: center;

					width: 100%;

					padding: 6px;

					overflow: hidden;

					text-overflow: ellipsis;
				}

				& > .right {
					position: absolute;
					right: 15px;
				}
			}
		}

		& > .scope {

			.opr-btn {
				padding: 8px;
			}

			& > .box {
				display: flex;
				gap: 20px;

				width: 100%;

				overflow: auto;

				padding: 16px;

				& > .user-name-info > label,
				& > .user-id-info > label {
					padding: 10px;
				}
			}

			& > .box-1 {
				align-items: center;
				flex-direction: column;

				& > .user-id-info,
				& > .user-name-info {
					display: flex;
					align-items: flex-start;
					flex-direction: column;
					gap: 10px;

					width: 100%;

					& > div {
						display: flex;
						align-items: center;
						flex-direction: row;
						gap: 10px;

						width: 100%;

						& > .input {
							width: 100%;
						}
					}
				}
			}
		}
	}
</css>