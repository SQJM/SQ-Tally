<import
	root="magic-ui/ui"
>
	<module:input>
		<edit/>
		<text-edit/>
		<switch-button/>
	</module:input>
</import>

<template>
    <div #id="view">
        <div>
            <label>账本名</label>
            <edit #id="tally-name" :placeholder="请输入" :maxlength="30" class="w"/>
        </div>
        <div>
            <label>描述</label>
            <text-edit #id="tally-describe" :maxlength="300" class="w mh"/>
        </div>
        <div>
            <label>密码 (注意!忘记密码将无法恢复)</label>
            <edit #id="tally-password" class="w" :maxlength="8" :placeholder="为空则是不设置密码"/>
        </div>
        <div>
            <label>设置为云账本</label>
            <switch-button #id="set-tally-cloud" @click="setCloud"/>
        </div>
        <button @click="addTally" class="add">点击添加账本</button>
    </div>
</template>

<global>
	const {
		$view,
		$setTallyCloud,
		$tallyName,
		$tallyDescribe,
		$tallyPassword
	} = $id();

	const tallly = {
		id : window.crypto.randomUUID(),
		metadata : {
			who : "SQ-Tally"
		},
		name : "",
		description : "",
		state : Tally.State.normal,
		createTime : Date.now(),
		storage : {
			type : "locality"
		}
	};

	const pdv = magic.importM( "ui/pop-down-view" );
</global>

<event>
	setCloud = () => {
		if ( !App.Current[ "远程服务器状态" ] ) {
			MagicUi.feedback.message( {
				text : `无法连接远程服务器`,
				eventLevel : MagicUi.previa.feedback.message.EventLevel.warning
			} );
		} else {
			if ( $setTallyCloud.interface.getState() ) {
				tallly.storage = {
					type : "cloud"
				};
			} else tallly.storage = {
				type : "locality"
			};
		}
	}

	addTally = () => {
		tallly.name = $tallyName.interface.getValue();
		tallly.description = $tallyDescribe.interface.getValue();

		if ( tallly.name === "null" || tallly.name === "没有账本" ) {
			MagicUi.feedback.message( {
				text : `非法账本名`,
				eventLevel : MagicUi.previa.feedback.message.EventLevel.warning
			} );
			return;
		}

		if ( tallly.name.trim().length === 0 ) {
			MagicUi.feedback.message( {
				text : `账本名不能为空`,
				eventLevel : MagicUi.previa.feedback.message.EventLevel.warning
			} );
			return;
		}

		Tally.create( tallly, $tallyPassword.interface.getValue() ).then( () => {
			pdv.interface.close();

			MagicUi.feedback.message( {
				text : `账本创建成功`,
				eventLevel : MagicUi.previa.feedback.message.EventLevel.pass
			} );
		} ).catch( e => {
			Log.error( `账本创建失败: ${ e }` );
			MagicUi.feedback.message( {
				text : `账本创建失败 ${ e }`,
				eventLevel : MagicUi.previa.feedback.message.EventLevel.error
			} );
		} );
	}
</event>

<script>
    pdv.interface.init( $view );

    if ( !App.Current[ "远程服务器状态" ] ) {
        $setTallyCloud.interface.setFreeze( true );
    }
</script>

<css scope="#id:view">
	& {

		& > div {
			& > div {
				box-shadow: rgba(14, 63, 126, 0.06) 0px 0px 0px 1px, rgba(42, 51, 70, 0.03) 0px 1px 1px -0.5px, rgba(42, 51, 70, 0.04) 0px 2px 2px -1px, rgba(42, 51, 70, 0.04) 0px 3px 3px -1.5px, rgba(42, 51, 70, 0.03) 0px 5px 5px -2.5px, rgba(42, 51, 70, 0.03) 0px 10px 10px -5px, rgba(42, 51, 70, 0.03) 0px 24px 24px -8px;
			}
		}

		& > .add {
			background-color: #00e75b;

			border-radius: 20px;
		}
	}
</css>

<css scope="#id:view">
	& {
		display: flex;
		flex-direction: column;
		gap: 25px;

		padding: 15px;

		& > div {
			display: flex;
			flex-direction: column;
			gap: 10px;

			label {
				font-size: larger;
			}

			input {
				font-size: medium;
			}

			.w {
				width: 100%;
			}

			.mh {
				height: 200px;
			}
		}

		& > .add {
			width: 80%;
			height: 60px;

			text-align: center;

			position: relative;
			left: 50%;
			transform: translateX(-50%);

			padding: 10px;
			margin-top: 20px;
			margin-bottom: 20px;

			font-size: x-large;
		}
	}
</css>