<import
	root="magic-ui/ui"
>
	<module:input>
		<edit/>
		<text-edit/>
		<switch-button/>
	</module:input>
</import>

<template>
    <div #id="view">
        <div>
            <label>账本名</label>
            <edit #id="tally-name" :placeholder="请输入" class="w"/>
        </div>
        <div>
            <label>描述</label>
            <text-edit #id="tally-describe" class="w mh"/>
        </div>
        <div>
            <label>创建日期</label>
            <label #id="tally-create-date"></label>
        </div>
        <div>
            <i #id="tally-is-password"></i>
        </div>
        <button @click="lookData" class="lookData">账本数据</button>
		<button @click="saved" class="saved">保存修改</button>
    </div>
</template>

<global>
	const {
		$view,
		$tallyName,
		$tallyDescribe,
		$tallyIsPassword,
		$tallyCreateDate
	} = $id();

	const pdv = magic.importM( "ui/pop-down-view" );

	let currentTallyData = null;
</global>

<event>
	saved = () => {
		if ( currentTallyData.storage.type === "cloud" && !App.Current[ "远程服务器状态" ] ) {
			MagicUi.feedback.message( {
				text : `无法连接远程服务器`,
				eventLevel : MagicUi.previa.feedback.message.EventLevel.warning
			} );
			return;
		}
		Tally.update( {
			id : currentTallyData.id,
			name : $tallyName.interface.getValue(),
			description : $tallyDescribe.interface.getValue()
		} ).then( _ => {
			MagicUi.feedback.message( {
				text : `保存成功`,
				eventLevel : MagicUi.previa.feedback.message.EventLevel.pass
			} );
		} ).catch( e => {
			Log.error( `保存失败: ${ e }` );
			MagicUi.feedback.message( {
				text : `保存失败: ${ e }`,
				eventLevel : MagicUi.previa.feedback.message.EventLevel.error
			} );
		} );
	}

	lookData = () => {
		console.log( currentTallyData )
	}
</event>

<interface>
	init = ( id ) => {
		Page.pause();
		Tally.getInfo( id ).then( obj => {
			if ( obj.metadata.who !== "SQ-Tally" ) {
				$tallyIsPassword.textContent = "该账本已被加密";
			}
			$tallyName.interface.setValue( obj.name );
			$tallyDescribe.interface.setValue( obj.description );
			$tallyCreateDate.textContent = WebTool.getNowFormatDate( obj.createTime );
			currentTallyData = obj;
			Page.start();
		} );
	}
</interface>

<script>
    pdv.interface.init( $view );
</script>

<css scope="#id:view">
	& {
		& > div > div {
			box-shadow: rgba(14, 63, 126, 0.06) 0px 0px 0px 1px, rgba(42, 51, 70, 0.03) 0px 1px 1px -0.5px, rgba(42, 51, 70, 0.04) 0px 2px 2px -1px, rgba(42, 51, 70, 0.04) 0px 3px 3px -1.5px, rgba(42, 51, 70, 0.03) 0px 5px 5px -2.5px, rgba(42, 51, 70, 0.03) 0px 10px 10px -5px, rgba(42, 51, 70, 0.03) 0px 24px 24px -8px;
		}

		& > .saved,
		& > .lookData {
			background-color: #00e75b;

			border-radius: 20px;
		}

		& > .lookData {
			background-color: #00e3ff;
		}
	}
</css>

<css scope="#id:view">
	& {
		display: flex;
		flex-direction: column;
		gap: 25px;

		padding: 15px;

		& > div {
			display: flex;
			flex-direction: column;
			gap: 10px;

			label {
				font-size: larger;
			}

			input {
				font-size: medium;
			}

			.w {
				width: 100%;
			}

			.mh {
				height: 200px;
			}
		}

		& > .saved,
		& > .lookData {
			width: 80%;
			height: 60px;

			text-align: center;

			position: relative;
			left: 50%;
			transform: translateX(-50%);

			padding: 10px;
			margin-top: 20px;

			font-size: x-large;
		}
	}
</css>