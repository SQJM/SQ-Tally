<import
	root="magic-ui/ui"
>
	<module:widget>
		<item/>
	</module:widget>

	<module:control>
		<list-view/>
	</module:control>
</import>

<template>
    <div #id="view">
		<div class="opr">
			<img @click="hf" src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMjgiIGhlaWdodD0iMTI4IiB2aWV3Qm94PSIwIDAgMjQgMjQiPjxwYXRoIGZpbGw9IiMxMWU4NTIiIGQ9Ik0xMyAzYTkgOSAwIDAgMC05IDlIMWwzLjg5IDMuODlsLjA3LjE0TDkgMTJINmE3IDcgMCAwIDEgNy03YTcgNyAwIDAgMSA3IDdhNyA3IDAgMCAxLTcgN2MtMS45MyAwLTMuNjgtLjc5LTQuOTQtMi4wNmwtMS40MiAxLjQyQTguOSA4LjkgMCAwIDAgMTMgMjFhOSA5IDAgMCAwIDktOWE5IDkgMCAwIDAtOS05Ii8+PC9zdmc+"/>
			<img @click="sc" src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMjgiIGhlaWdodD0iMTI4IiB2aWV3Qm94PSIwIDAgMjQgMjQiPjxwYXRoIGZpbGw9IiNlMTFkNDgiIGQ9Im05LjQgMTUuODA4bDIuNi0yLjZsMi42IDIuNmwuNzA4LS43MDhsLTIuNi0yLjZsMi42LTIuNmwtLjcwOC0uNzA4bC0yLjYgMi42bC0yLjYtMi42bC0uNzA4LjcwOGwyLjYgMi42bC0yLjYgMi42ek03LjYxNiAyMHEtLjY5MSAwLTEuMTUzLS40NjJUNiAxOC4zODRWNkg1VjVoNHYtLjc3aDZWNWg0djFoLTF2MTIuMzg1cTAgLjY5LS40NjIgMS4xNTNUMTYuMzg0IDIwek0xNyA2SDd2MTIuMzg1cTAgLjIzLjE5Mi40MjN0LjQyMy4xOTJoOC43N3EuMjMgMCAuNDIzLS4xOTJ0LjE5Mi0uNDIzek03IDZ2MTN6Ii8+PC9zdmc+"/>
		</div>
		<list-view #id="list-0" #listen:select="set1_select" :def_select="false" :repetition="true" :multiple="true" #listen:select_stop_bubbling="listOpr" class="list"></list-view>
    </div>
</template>

<global>
	const {
		$view,
		$list0
	} = $id();

	const pdv = magic.importM( "ui/pop-down-view" );

    function set1_select(e) {
		current_item_id = e.getAttribute("id");
	}

    function createItem( o ) {
		const item = magic.importM( "magic-ui/ui/widget/item" );
		if ( o.storage.type === "cloud" ) {
			item.setAttribute( "cloud", "" );
		}
		item.setAttribute( "id", o.id );
		item.interface.setHTML(`<img class="cloud" src="assets/MaterialSymbolsCloud.svg"/>
	<img class="icon" src="assets/OpenmojiLedger.svg"/>
	<div class="box">
	<span>${o.name}</span>
	<p>${o.description}</p>
	</div>
	<div class="opa">
	<img event="out" m-stop-bubbling src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMjgiIGhlaWdodD0iMTI4IiB2aWV3Qm94PSIwIDAgMjQgMjQiPjxwYXRoIGZpbGw9IiM0N2MyZmYiIGQ9Ik04LjcxIDcuNzFMMTEgNS40MVYxNWExIDEgMCAwIDAgMiAwVjUuNDFsMi4yOSAyLjNhMSAxIDAgMCAwIDEuNDIgMGExIDEgMCAwIDAgMC0xLjQybC00LTRhMSAxIDAgMCAwLS4zMy0uMjFhMSAxIDAgMCAwLS43NiAwYTEgMSAwIDAgMC0uMzMuMjFsLTQgNGExIDEgMCAxIDAgMS40MiAxLjQyTTIxIDE0YTEgMSAwIDAgMC0xIDF2NGExIDEgMCAwIDEtMSAxSDVhMSAxIDAgMCAxLTEtMXYtNGExIDEgMCAwIDAtMiAwdjRhMyAzIDAgMCAwIDMgM2gxNGEzIDMgMCAwIDAgMy0zdi00YTEgMSAwIDAgMC0xLTEiLz48L3N2Zz4="/>
	<img event="info" m-stop-bubbling src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMjgiIGhlaWdodD0iMTI4IiB2aWV3Qm94PSIwIDAgNDggNDgiPjxjaXJjbGUgY3g9IjI0IiBjeT0iMjQiIHI9IjIxIiBmaWxsPSIjMjE5NkYzIi8+PHBhdGggZmlsbD0iI2ZmZiIgZD0iTTIyIDIyaDR2MTFoLTR6Ii8+PGNpcmNsZSBjeD0iMjQiIGN5PSIxNi41IiByPSIyLjUiIGZpbGw9IiNmZmYiLz48L3N2Zz4="/>
	</div>`);
		return item;
	}

	function refreshList() {
        $list0.interface.clear();
        Tally.getAllTally(Tally.State.remove).then(r=>{
            r.forEach(o=> $list0.appendChild( createItem( o ) ) );
		});
	}

    function listOpr( item, target ) {
		if( !target.hasAttribute( "event" ) ) return;
		const event = target.getAttribute( "event" );
		if( event === "info" ){
			magic.importM( "ui/setting/tally-opa/info" ).interface.init( item.getAttribute("id") );
		}
	}
</global>

<event>
	hf = async () => {
		const items = $list0.interface.getSelectAll();
		if ( items.length === 0 ) {
			MagicUi.feedback.message( {
				text : `没有选择账本`,
				eventLevel : MagicUi.previa.feedback.message.EventLevel.info
			} );
			return;
		}
		Page.pause();
		try {
			for ( const item of items ) {
				const id = item.getAttribute( "id" );
				await Tally.recover( id );
			}
			MagicUi.feedback.message( {
				text : `账本恢复成功`,
				eventLevel : MagicUi.previa.feedback.message.EventLevel.pass
			} );
		} catch ( e ) {
			Log.error( `账本恢复失败: ${ e }` );
			MagicUi.feedback.message( {
				text : `账本恢复失败 ${ e }`,
				eventLevel : MagicUi.previa.feedback.message.EventLevel.error
			} );
		}
		Page.start();
		refreshList();
	}

	sc = () => {
		const items = $list0.interface.getSelectAll();
		if ( items.length === 0 ) {
			MagicUi.feedback.message( {
				text : `没有选择账本`,
				eventLevel : MagicUi.previa.feedback.message.EventLevel.info
			} );
			return;
		}
		magic.importM( "ui/dialog" ).interface.init( {
			content : "不可恢复!",
			title : "是否删除所选账本?",
			group : {
				"确定" : async () => {
					Page.pause();
					try {
						for ( const item of items ) {
							await Tally.remove( item.getAttribute( "id" ) );
						}
					} catch ( e ) {
						Log.error( `账本删除失败: ${ e }` );
						MagicUi.feedback.message( {
							text : `账本删除失败 ${ e }`,
							eventLevel : MagicUi.previa.feedback.message.EventLevel.error
						} );
					}
					Page.start();
					refreshList();
					return true;
				},
				"取消" : () => {
					return true;
				}
			}
		} );
	}
</event>

<script>
    pdv.interface.init( $view );
    refreshList();
</script>

<css scope="#id:view" default-theme>
	& {
		& > .opr {
			background-color: #e5fafb;

			box-shadow: rgba(0, 0, 0, 0.04) 0px 3px 5px;
			border-radius: 20px;
		}

		& > .list {
			background-color: #e5fafb;

			box-shadow: rgba(0, 0, 0, 0.04) 0px 3px 5px;
			border-radius: 20px;

			& > *[m-item] {
			}
		}

		& > .add {
			background-color: #00e75b;

			border-radius: 20px;
		}
	}
</css>

<css scope="#id:view">
	& {
		display: flex;
		flex-direction: column;
		gap: 25px;

		padding: 15px;

		overflow: hidden;

		& > .list {
			overflow: auto;
			height: calc(100% - 125px);

			& > *[m-item] {
				display: flex;
				align-items: center;
				gap: 5px;

				padding: 20px 10px 20px 10px;

				& > .cloud {
					display: none;
				}

				& > .icon {
					width: 50px;
					height: 50px;
				}

				&[cloud] > .cloud {
					display: block;
					position: absolute;
					scale: .16;
					left: 1px;
				}

				& > .box {
					display: flex;
					flex-direction: column;

					max-width: 50%;

					margin-right: auto;

					span, p {
						text-overflow: ellipsis;
						white-space: nowrap;
						overflow: hidden;
					}

					span {
						font-size: larger;
					}

					p {
						margin: 0px;
					}
				}

				& > .opa {
					display: flex;
					align-items: center;
					gap: 5px;

					img {
						width: 35px;
					}
				}
			}
		}

		& > .opr {
			display: flex;
			flex-direction: row;
			justify-content: center;
			align-items: center;

			margin-bottom: 10px;
			padding: 10px;

			img {
				width: 80px;

				margin: auto;
			}
		}
	}
</css>