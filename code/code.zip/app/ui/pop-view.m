<import
	root="ui"
>
	<top-bar-exit/>
</import>

<template>
	<div #id="view">
		<top-bar-exit #id="title" #listen:exit="close"/>
		<div #id="content" class="content"></div>
	</div>
</template>

<global>
	const {
		$view,
		$content,
		$title
	} = $id();

	function close() {
		$view.style.animation = `disappear-above .5s forwards`;
		$view.onanimationend = () => {
			$view.remove();
		}
	}
</global>

<script>
    $view.style.width = `${ _args.rect.width }px`;
    $view.style.height = `${ _args.rect.height }px`;
    $view.style.top = `${ _args.rect.y }px`;
    $view.style.left = `${ _args.rect.x }px`;
    $view.style.opacity = ".8";

    document.body.appendChild( $view );

    setTimeout( () => {
        $view.style.width = `100%`;
        $view.style.height = `100%`;
        $view.style.top = `0`;
        $view.style.left = `0`;
        $view.style.opacity = "1";
    }, 100 );
</script>

<interface>
	init = ( con, title ) => {
		$content.appendChild( con );
		$title.interface.setTitle( title );
	}

	close = () => {
		close();
	}
</interface>

<css scope="#id:view" default-theme>
	& {
		& > .content {
			background-color: #00e75b;
		}
	}
</css>

<css scope="#id:view">
	& {
		position: fixed;
		z-index: 20;
		overflow: hidden;

		transition: all .5s;

		& > .content {
			width: 100%;
			height: calc(100% - 110px);

			padding: 20px;

			& > div {
				height: 100%;
			}
		}
	}
</css>