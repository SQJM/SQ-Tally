<template>
	<div #id="bar">
		<img #id="btn" @click="exit" class="btn" src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMjgiIGhlaWdodD0iMTI4IiB2aWV3Qm94PSIwIDAgMjQgMjQiPjxwYXRoIGZpbGw9IiM2NjY2NjYiIGQ9Im04LjgyIDEybDcuNzE1IDcuNzE2cS4yMi4yMi4yMTguNTI4dC0uMjI0LjUyOXEtLjIyMS4yMjEtLjUyOS4yMjF0LS41MjktLjIyMUw3LjgzIDEzLjEzNnEtLjI0My0uMjQyLS4zNTQtLjU0cS0uMTEyLS4yOTgtLjExMi0uNTk2dC4xMTItLjU5NnQuMzU0LS41NGw3LjY0LTcuNjQ0cS4yMjEtLjIyMS41MzItLjIxOHEuMzEuMDAzLjUzMS4yMjR0LjIyMi41Mjl0LS4yMjIuNTI4eiIvPjwvc3ZnPg=="/>
		<h3 #id="title" class="title"></h3>
	</div>
</template>

<global>
	const {
		$btn,
		$title
	} = $id();

	const UiData = magic_define_ui_data( {
		title : ""
	} );
</global>

<event>
	exit = () => {
		use_event( "exit" );
	}
</event>

<interface once>
	setTitle = ( title = UiData.title ) => {
		$title.textContent = title;
	}
</interface>

<css scope="#id:bar" default-theme>
	& {
		background-color: #00e75b;

		.title {
			color: #e5fafb;
		}
	}
</css>

<css scope="#id:bar">
	& {
		width: 100%;
		height: 110px;

		padding-top: 20px;

		display: flex;
		align-items: center;
		justify-content: center;

		.title {
			font-size: 1.2rem;

			margin-left: auto;
			margin-right: auto;
		}

		.btn {
			width: 30px;
			height: 30px;

			position: absolute;
			left: 30px;
		}
	}
</css>