<import
	root="ui"
>
	<top-bar/>
	<content/>
	<bottom-bar/>
</import>

<template>
	<div #id="main">
		<top-bar/>
		<content #id="content"/>
		<bottom-bar #id="bb"/>
	</div>
	<style id="app-animation-style"></style>
</template>

<script>
	MagicUi.init();

    Setting.init();
    App.start();
    $id( "bb" ).interface.init( $id( "content" ) );
    setTimeout( () => {
        App.animationVisibility();
    }, 1000 );
</script>

<css scope="#id:main">
	& {
		width: 100%;
		height: 100%;
	}
</css>