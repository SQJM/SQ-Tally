const magic_ui_version = '1.0.0';
const MagicUi = ( () => {
    if ( !magic ) {
        throw new Error( "magic not defined" );
    }
    if ( magic_version !== magic_ui_version ) {
        throw new Error( "The magic version is different from the MagicUi version" );
    }

    // 代码错误
    const Code_Error = {
        // 参数不匹配
        ParameterMismatch : ( ...arg ) => {
            return new Error( `CODE Error : <${ arg }> Parameter mismatch` );
        },
        // 不存在的项
        NotExistItem : ( ...arg ) => {
            return new Error( `CODE Error : <${ arg }> Not exist item` );
        }
    }

    const Place = {
        top : {
            left : 0,
            center : 1,
            right : 2
        },
        center : {
            left : 3,
            center : 4,
            right : 5
        },
        bottom : {
            left : 6,
            center : 7,
            right : 8
        }
    };

    /**
     * 用于判断各种数据类型的工具类
     */
    class Judge {

        /**
         * 验证字符串是否符合常规
         * @param {string} data 待验证数据
         * @param {Set} invalidChars 存储违法字符的数组
         * @param type
         * @returns {boolean} 验证结果
         */
        static isValidString( data, {
            invalidChars = null,
            type = "text"
        } = {} ) {
            // 定义合法字符的正则表达式
            const regex = {
                text : () => /^[a-zA-Z0-9-_()!@#$%^&*=+?<>:;.\[\]-\u4e00-\u9fa5]+$/.test( data ),
                file : () => !/[:\\*\/"<>@?\n]/.test( data )
            };

            const result = regex[ type ];
            if ( !result ) throw Code_Error.ParameterMismatch( type );

            if ( result( data ) ) {
                return true;
            } else {
                if ( Judge.isSet( invalidChars ) ) {
                    forEnd( data, ( e ) => {
                        if ( !result.test( e ) ) {
                            invalidChars.add( e );
                        }
                    } );
                }
                return false;
            }
        }

        /**
         * 判断给定的参数是否为字符串类型
         * @returns {boolean} 如果参数是字符串类型,则返回 true;否则返回 false
         * @param args
         */
        static isString( ...args ) {
            return Judge.is( it => ( typeof it === 'string' || it instanceof String ), ...args );
        }

        /**
         * 判断给定的参数是否为 null
         * @returns {boolean} 如果参数是 null,则返回 true;否则返回 false
         * @param args
         */
        static isNull( ...args ) {
            return Judge.is( it => ( it === null ), ...args );
        }

        /**
         * 判断给定的参数是否为 undefined
         * @returns {boolean} 如果参数是 undefined,则返回 true;否则返回 false
         * @param args
         */
        static isUndefined( ...args ) {
            return Judge.is( it => ( typeof it === 'undefined' ), ...args );
        }

        /**
         * 判断给定的参数是否为 NaN
         * @returns {boolean} 如果参数是 NaN,则返回 true;否则返回 false
         * @param args
         */
        static isNaN( ...args ) {
            return Judge.is( it => ( Number.isNaN( it ) ), ...args );
        }

        /**
         * 判断给定的参数是否为函数类型
         * @returns {boolean} 如果参数是函数类型,则返回 true;否则返回 false
         * @param args
         */
        static isFunction( ...args ) {
            return Judge.is( it => ( typeof it === 'function' || it instanceof Function ), ...args );
        }

        /**
         * 判断给定的参数是否为自定义类型(通过构造函数定义)
         * @returns {boolean} 如果参数是通过构造函数定义的自定义类型,则返回 true;否则返回 false
         * @param customType
         * @param args
         */
        static isCustomType( customType, ...args ) {
            return Judge.is( it => ( it instanceof customType ), ...args );
        }

        /**
         * 判断给定的参数是否为类class类型
         * @returns {boolean} 如果参数是类类型,则返回 true;否则返回 false
         * @param args
         */
        static isClass( ...args ) {
            return Judge.is( it => ( typeof it === 'function' && /^\s*class\s+/.test( it.toString() ) ), ...args );
        }

        /**
         * 判断给定的参数是否为普通对象即非数组`非函数`非 null 的对象
         * @returns {boolean} 如果参数是普通对象,则返回 true;否则返回 false
         * @param args
         */
        static isPlainObject( ...args ) {
            return Judge.is( it => ( Object.prototype.toString.call( it ) === '[object Object]' ), ...args );
        }

        /**
         * 判断给定的参数是否为数组类型
         * @returns {boolean} 如果参数是数组类型,则返回 true;否则返回 false
         * @param args
         */
        static isArray( ...args ) {
            return Judge.is( it => ( Array.isArray( it ) ), ...args );
        }

        /**
         * 判断给定的参数是否为 Set 类型
         * @returns {boolean} 如果参数是 Set 类型,则返回 true;否则返回 false
         * @param args
         */
        static isSet( ...args ) {
            return Judge.is( it => ( it instanceof Set ), ...args );
        }

        /**
         * 判断给定的参数是否为 Map 类型
         * @returns {boolean} 如果参数是 Map 类型,则返回 true;否则返回 false
         * @param args
         */
        static isMap( ...args ) {
            return Judge.is( it => ( it instanceof Map ), ...args );
        }

        /**
         * 判断给定的参数是否为数字类型
         * @returns {boolean} 如果参数是数字类型,则返回 true;否则返回 false
         * @param args
         */
        static isNumber( ...args ) {
            return Judge.is( it => ( typeof it === 'number' || it instanceof Number || Number.isInteger( it ) ), ...args );
        }

        /**
         * 判断给定的参数是否为布尔类型
         * @returns {boolean} 如果参数是布尔类型,则返回 true;否则返回 false
         * @param args
         */
        static isBoolean( ...args ) {
            return Judge.is( it => ( typeof it === 'boolean' || it instanceof Boolean ), ...args );
        }

        /**
         * 判断给定的参数是否为负数
         * @returns {boolean} 如果参数是负数,则返回 true;否则返回 false
         * @param args
         */
        static isNegative( ...args ) {
            return Judge.is( it => ( it < 0 ), ...args );
        }

        /**
         * 判断给定的参数是否为正数
         * @returns {boolean} 如果参数是正数,则返回 true;否则返回 false
         * @param args
         */
        static isPositive( ...args ) {
            return Judge.is( it => ( it > 0 ), ...args );
        }

        /**
         * 判断给定的参数是否为对象类型包括普通对象,数组,null等,并检测对象是否包含指定属性
         * @param {any} obj - 要检查的参数
         * @param {...string} props - 要检测的属性列表
         * @returns {boolean} 如果参数是对象类型且包含指定属性,则返回 true;否则返回 false
         */
        static isObject( obj, ...props ) {
            if ( typeof obj !== 'object' || obj === null ) {
                return false;
            }

            if ( props.length === 0 ) return true;

            return props.every( prop => obj.hasOwnProperty( prop ) );
        }

        /**
         * 判断给定的参数是否为空对象
         * @returns {boolean} 如果参数是空对象,则返回 true;否则返回 false
         * @param args
         */
        static isEmptyObject( ...args ) {
            return Judge.is( it => ( typeof it === 'object' && it !== null && Object.keys( it ).length === 0 ), ...args );
        }

        /**
         * 判断给定的参数是否为 HTMLElement 类型即 DOM 元素
         * @returns {boolean} 如果参数是 HTMLElement 类型,则返回 true;否则返回 false
         * @param args
         */
        static isHTMLElement( ...args ) {
            return Judge.is( it => ( it && typeof it === 'object' && it.nodeType && typeof it.style === 'object' && typeof it.ownerDocument === 'object' ), ...args );
        }

        /**
         * 判断给定的参数是否为 DocumentFragment 类型
         * @returns {boolean} 如果参数是 DocumentFragment 类型,则返回 true;否则返回 false
         * @param args
         */
        static isDocumentFragment( ...args ) {
            return args.some( it => it && typeof it === 'object' && it.nodeType === Node.DOCUMENT_FRAGMENT_NODE );
        }

        /**
         * 判断给定的参数是否为 childNodes
         * @returns {boolean} 如果参数是 childNodes,则返回 true;否则返回 false
         * @param args
         */
        static isChildNodes( ...args ) {
            return args.some( it => {
                const isNodeList = it instanceof NodeList;
                const allItemsAreNodes = Array.from( it ).every( item => item instanceof Node );
                return isNodeList && allItemsAreNodes;
            } );
        }

        /**
         * 判断给定的元素是否为指定的 ui
         * @returns {boolean} 如果参数是 是指定的 ui ,则返回 true;否则返回 false
         * @param targetUi 指定的 ui 名字
         * @param args
         */
        static isElementIsSpecifiedUi( targetUi, ...args ) {
            targetUi = targetUi.replace( /[^a-zA-Z]/g, '' ).toLowerCase();
            return args.some( it => it.hasAttribute( "m-name" ) && it.getAttribute( "m-name" ).replace( /[^a-zA-Z]/g, '' ).toLowerCase() === targetUi );
        }

        /**
         * 判断当前页面是否处于全屏状态
         * @returns {boolean} 如果页面处于全屏状态,则返回 true;否则返回 false
         */
        static isFullScreen() {
            return !!( document.fullscreenElement || document.mozFullScreenElement || document.webkitFullscreenElement || document.msFullscreenElement );
        }

        /**
         * 判断变量是否有内容或数据
         * @returns {Boolean} 布尔值
         * @param args
         */
        static isTrue( ...args ) {
            return Judge.is( it => ( it !== null && it !== void 0 && it !== false ), ...args );
        }

        /**
         * 判断变量是否为 false
         * @returns {Boolean} 布尔值
         * @param args
         */
        static isFalse( ...args ) {
            return Judge.is( it => ( it === null || it === void 0 || it === false ), ...args );
        }

        /**
         * 判断变量是否为空字符串
         * @returns {Boolean} 布尔值
         * @param args
         */
        static isEmptyString( ...args ) {
            return Judge.is( it => ( Judge.isString( it ) && it.trim() === '' ), ...args );
        }

        /**
         * 判断给定的值是否为对象中的一个值
         * @param {any} value - 需要检查的值
         * @param {Object} obj - 对象,其属性值将被检查
         * @returns {Boolean} 如果`value`是`obj`中的一个值,则返回`true`;否则返回`false`
         */
        static isValueInObject( value, obj ) {
            return Object.values( obj ).includes( value );
        }

        /**
         * 判断一个数组是否包含不属于另一个数组中的元素
         * @param {Array} arr1 - 第一个数组
         * @param {Array} arr2 - 第二个数组
         * @returns {boolean} 如果 arr1 包含不属于 arr2 的元素,则返回 true:否则返回 false
         */
        static isContainsExtraItems( arr1, arr2 ) {
            const set = new Set( arr2 );

            for ( let item of arr1 ) {
                if ( !set.has( item ) ) {
                    return true; // arr1 包含不属于 arr2 的元素
                }
            }

            return false;
        }

        /**
         * 表单验证函数
         * @param {string} data 待验证数据
         * @param {string} mode 验证模式,可选值为 "password"`"idCard"`"phone" 和 "email"
         * @returns {boolean} 验证结果,true 表示验证通过,false 表示验证失败
         */
        static formValidation( data, mode ) {
            let is;
            if ( mode !== "" ) {
                if ( mode === "password" ) {
                    is = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$/;
                } else if ( mode === "idCard" ) {
                    is =
                        /^[1-9]\d{5}(18|19|20)\d{2}(0[1-9]|1[012])(0[1-9]|[12]\d|3[01])\d{3}[\dX]$/;
                } else if ( mode === "phone" ) {
                    is = /^[1][3-9]\d{9}$/;
                } else if ( mode === "email" ) {
                    is = /^([\w.%+-]+)@([\w-]+\.)+([\w]{2,})$/i;
                }
                return is.test( data );
            } else {
                return false;
            }
        }

        static IS( callback = () => { }, err = () => { }, ...args ) {
            for ( const it of args ) {
                const result = callback( it );
                if ( !result ) {
                    err( it );
                    return false;
                }
            }
            return true;
        }

        static is( callback = () => { }, ...args ) {
            return Judge.IS( callback, () => {}, ...args );
        }
    }

    /**
     * 创建HTML元素
     * @param {Object} options - 元素选项
     * @returns {HTMLElement} - 新创建的HTML元素
     */
    function createElement( {
                                tagName = "div",
                                id = null,
                                className = null,
                                classList = [],
                                attribute = [],
                                text = null,
                                textContent = "",
                                html = null,
                                child = null,
                                callback = () => { }
                            } = {} ) {
        const element = document.createElement( tagName );

        if ( id ) element.id = id;

        if ( Judge.isArray( classList ) ) {
            forEnd( classList, ( e ) => {
                element.classList.add( e );
            } );
        }
        if ( Judge.isString( className ) ) {
            element.className = className;
        }
        if ( Judge.isArray( attribute ) ) {
            forEnd( attribute, ( e ) => {
                if ( Judge.isArray( e ) ) {
                    e[ 1 ] ? element.setAttribute( e[ 0 ], e[ 1 ] ) : element.setAttribute( e[ 0 ], "" );
                } else {
                    element.setAttribute( e, "" );
                }
            } );
        } else if ( Judge.isString( attribute ) ) {
            element.setAttribute( attribute, "" );
        }

        if ( textContent ) {
            element.textContent = textContent;
        } else if ( text ) {
            element.innerText = text;
        } else if ( html ) {
            element.innerHTML = html;
        }

        if ( child )
            if ( Judge.isArray( child ) && child.length > 1 ) {
                forEnd( child, ( e ) => {
                    e && element.appendChild( e );
                } );
            } else if ( Judge.isHTMLElement( child ) || Judge.isDocumentFragment( child ) ) {
                element.appendChild( child );
            }
        if ( callback ) callback( element );
        return element;
    }

    /**
     * 遍历数组或指定长度的范围,基于条件执行操作,支持正序或逆序遍历
     * @returns {any|null} - 满足条件的元素（对于数组）或索引（对于数字）; 如果没有找到匹配项,则返回 `null`
     */
    function forEnd( iterable, condition, {
        start = 0,
        skip = null,
        isReversal = false,
        autoReplace = false,
        endCallback = () => {},
        end = null
    } = {} ) {
        if ( !Array.isArray( iterable ) && !Number.isInteger( iterable ) && !iterable[ 0 ] ) return null;
        if ( skip === null ) skip = [];
        let result = null;
        const max = end !== null ? end : ( Number.isInteger( iterable ) ? iterable : iterable.length );

        const iterate = ( start, end, step ) => {
            for ( let index = start; index !== end; index += step ) {
                if ( skip.includes( index ) ) continue;
                const element = Number.isInteger( iterable ) ? index : iterable[ index ];
                const value = condition( element, index, result );
                if ( autoReplace ) iterable[ index ] = value;
                if ( value === true ) {
                    result = element;
                    break;
                } else if ( value === "continue" ) {
                    continue;
                } else if ( value === "break" ) {
                    break;
                }
            }
        };

        if ( isReversal ) {
            iterate( max - 1, start - 1, -1 );
        } else {
            iterate( start, max, 1 );
        }

        endCallback( result );
        return result;
    }

    /**
     * 遍历对象
     */
    function traverseObject( obj, callback, old ) {
        for ( const key in obj ) {
            if ( obj.hasOwnProperty( key ) ) {
                const value = obj[ key ];
                if ( value && ( typeof value === 'object' ) && !Array.isArray( value ) ) {
                    old = obj;
                    traverseObject( value, callback, old );
                } else if ( Array.isArray( value ) ) {
                    for ( const i in value ) {
                        const item = value[ i ];
                        if ( item && typeof item === 'object' ) {
                            old = obj;
                            traverseObject( item, callback, old );
                        } else {
                            if ( callback( key, item, { parentObject : old } ) === false ) return;
                        }
                    }
                } else {
                    if ( callback( key, value, { parentObject : old } ) === false ) return;
                }
            }
        }
    }

    /**
     * 触发指定元素上的事件
     */
    function eventTrigger( element, eventName, btn = 0 ) {
        if ( element ) {
            element.dispatchEvent( new MouseEvent( eventName, {
                bubbles : true,     // 事件是否冒泡
                cancelable : true,  // 是否可以被取消
                view : window,      // 与事件相关的抽象视图
                button : btn        // 按下哪个鼠标键
            } ) );
            return true;
        }
        return false;
    }

    /**
     * @class VitalEvent
     * 用于监听一个元素是否被从 document 中移除
     * 如果元素被移除,则自动调用结束函数
     */
    class VitalEvent {
        constructor( element, init = () => { }, end = () => { } ) {
            if ( !Judge.isFunction( init, end ) ) throw Code_Error.ParameterMismatch( init, end );
            if ( !Judge.isHTMLElement( element ) ) throw Code_Error.ParameterMismatch( element );

            this._intervalId = null;
            this.end = end;

            init();

            this._intervalId = setInterval( () => {
                if ( !document.contains( element ) ) this.dispose();
            }, 1000 );
        }

        dispose() {
            if ( this._intervalId ) {
                clearInterval( this._intervalId );
                this._intervalId = null;
            }
            this.end();
        }
    }

    /**
     * 修正控件内部元素的位置,确保不超出控件的边界范围
     * @returns {number[]} 返回修正后的元素坐标 [y, x]
     */
    function RangeCorrection( [ x = null, y = null ], element, Control = AppMain ) {
        const {
            width : ControlW,
            height : ControlH
        } = Control.getClientRects();
        const {
            width : elementW,
            height : elementH
        } = element.getClientRects();
        let resultX = null, resultY = null;

        // 修正 X 轴坐标
        if ( x && x + elementW >= ControlW ) {
            resultX = ControlW - elementW;
        }

        // 修正 Y 轴坐标
        if ( y && y + elementH >= ControlH ) {
            resultY = ControlH - elementH;
        }

        return {
            x : resultX || 0,
            y : resultY || 0
        };
    }

    function JsonToElement( elementObjectArray = [] ) {
        function ObjectToElement( obj ) {
            try {
                const tagName = Object.keys( obj ).at( 0 );
                const element = document.createElement( tagName );
                const v = obj[ tagName ];
                Object.keys( v ).forEach( ( key ) => {
                    const prop = v[ key ];
                    if ( key.at( 0 ) === '@' ) {
                        element.setAttribute( key.substring( 1, key.length ), prop );
                    } else if ( key === '#text' ) {
                        element.textContent = prop;
                    } else if ( key === 'child' ) {
                        toElement( prop, element );
                    }
                } );
                return element;
            } catch ( e ) {
                return null;
            }
        }

        function toElement( array, root ) {
            array.forEach( elementObject => {
                const result = ObjectToElement( elementObject );
                if ( result ) {
                    root.appendChild( result );
                }
            } );
            return root;
        }

        if ( Array.isArray( elementObjectArray ) ) {
            return toElement( elementObjectArray, document.createDocumentFragment() );
        } else if ( typeof elementObjectArray === 'object' ) {
            return ObjectToElement( elementObjectArray );
        }
        return null;
    }

    function ElementToJson( childNodes ) {
        let root = {};

        function getTextNodes( element ) {
            let text = "";
            element.childNodes.forEach( node => {
                if ( node.nodeType === Node.TEXT_NODE ) {
                    text = node.textContent;
                }
            } );
            return text;
        }

        function elementToJson( element, obj ) {
            if ( element.nodeType === Node.TEXT_NODE ) return;
            const tagName = element.tagName.toLowerCase();
            obj[ tagName ] = {
                "child" : []
            };
            obj[ tagName ][ "#text" ] = getTextNodes( element );
            for ( let attr of element.attributes ) {
                obj[ tagName ][ `@${ attr.name }` ] = attr.value;
            }
            if ( element.childNodes.length > 0 ) {
                fn( element.childNodes, obj[ tagName ][ "child" ] );
            }
            return obj;
        }

        function fn( childNodes, array ) {
            childNodes.forEach( e => {
                if ( e.nodeType === Node.TEXT_NODE ) return;
                array.push( elementToJson( e, {} ) );
            } );
            return array;
        }

        if ( childNodes.length > 1 ) {
            root = [];
            return fn( childNodes, root );
        } else if ( childNodes.length === 1 ) {
            return elementToJson( childNodes.item( 0 ), root );
        } else {
            return root;
        }
    }

    class Draggable {
        #target;
        #limit;
        #callback;
        #freeMove;
        #y;
        #x;
        #startY;
        #startX;
        #element;
        #state;
        #vitalEvent;

        _onPointerDown( event ) {
            if (
                event.button === 2
                ||
                !this.#state
                ||
                !this.#callback( {
                    name : "start",
                    target : event.target
                } )
            ) return;

            event.stopPropagation();
            event.preventDefault();

            const targetRect = this.#target.getBoundingClientRect();
            const rect = event.target.getBoundingClientRect();
            this.#startX = rect.x - targetRect.x + ( ( event.offsetX || ( event.touches && event.touches[ 0 ].offsetX ) ) || 0 );
            this.#startY = rect.y - targetRect.y + ( ( event.offsetY || ( event.touches && event.touches[ 0 ].offsetY ) ) || 0 );

            document.addEventListener( "mousemove", this._onPointerMove );
            document.addEventListener( "touchmove", this._onPointerMove );
            document.addEventListener( "mouseup", this._onPointerUp );
            document.addEventListener( "touchend", this._onPointerUp );
        }

        _onPointerMove( event ) {
            const x = ( ( event.pageX || ( event.touches && event.touches[ 0 ].pageX ) ) || 0 ) - this.#startX,
                y = ( ( event.pageY || ( event.touches && event.touches[ 0 ].pageY ) ) || 0 ) - this.#startY;
            this.setXY( x, y );
        }

        _onPointerUp( event ) {
            if ( event.button === 2 ) return;
            document.removeEventListener( "mousemove", this._onPointerMove );
            document.removeEventListener( "touchmove", this._onPointerMove );
            document.removeEventListener( "mouseup", this._onPointerUp );
            document.removeEventListener( "touchend", this._onPointerUp );

            this.#callback( {
                name : "end"
            } );
        }

        constructor( element = null, {
            target = null,
            callback = () => { },
            limit = null,
            freeMove = false,
            state = true
        } ) {
            if ( !element ) throw "not element";
            if ( !target ) target = element;

            this.#element = element;
            this.#target = target;
            this.#callback = callback;
            this.#limit = limit;
            this.#freeMove = freeMove;
            this.#state = state;

            this.#x = 0;
            this.#y = 0;
            this.#startX = 0;
            this.#startY = 0;

            this._onPointerDown = this._onPointerDown.bind( this );
            this._onPointerMove = this._onPointerMove.bind( this );
            this._onPointerUp = this._onPointerUp.bind( this );

            this.#element.addEventListener( "mousedown", this._onPointerDown, { passive : false } );
            this.#element.addEventListener( "touchstart", this._onPointerDown, { passive : false } );

            this.__resize = () => {
                if ( this.#freeMove ) return;
                this.setXY( this.#x, this.#y );
            }

            this.#vitalEvent = new VitalEvent( this.#element, () => {
                window.addEventListener( 'resize', this.__resize );
            }, () => {
                window.removeEventListener( 'resize', this.__resize );
            } );
        }

        isExist() {
            return document.contains( this.#element ) && document.contains( this.#target )
        }

        setState( state ) {
            this.#state = state;
        }

        setElement( element ) {
            if ( !element ) return;
            this.#element.removeEventListener( "mousedown", this._onPointerDown );
            this.#element.removeEventListener( "touchstart", this._onPointerDown );
            this.#element = element;
            this.#element.addEventListener( "mousedown", this._onPointerDown, { passive : false } );
            this.#element.addEventListener( "touchstart", this._onPointerDown, { passive : false } );

            this.#vitalEvent && this.#vitalEvent.dispose();
            this.#vitalEvent = new VitalEvent( this.#element, () => {
                window.addEventListener( 'resize', this.__resize );
            }, () => {
                window.removeEventListener( 'resize', this.__resize );
            } );
        }

        setCallback( callback ) {
            this.#callback = callback;
        }

        setTargetElement( target ) {
            if ( !target ) target = this.#element;
            this.#target = target;
        }

        setLimit( limit ) {
            this.#limit = limit;
            this.setXY(
                this.#x,
                this.#y
            );
        }

        setXY( x = 0, y = 0 ) {
            if ( this.#limit ) {
                const {
                    top = -Infinity,
                    bottom = Infinity,
                    left = -Infinity,
                    right = Infinity
                } = this.#limit;

                if ( y <= top ) {
                    y = top;
                }
                if ( y >= bottom ) {
                    y = bottom;
                }
                if ( x <= left ) {
                    x = left;
                }
                if ( x >= right ) {
                    x = right;
                }
            }

            if ( !this.#callback( {
                name : "move",
                x : x,
                y : y
            } ) ) return;

            if ( !this.#freeMove ) {
                const {
                    width : w,
                    height : h
                } = document.getElementById( "app" ).getBoundingClientRect();
                const {
                    width : ew,
                    height : eh
                } = this.#target.getBoundingClientRect();
                if ( y + eh >= h ) y = h - eh;
                if ( x + ew >= w ) x = w - ew;
                if ( y <= 0 ) y = 0;
                if ( x <= 0 ) x = 0;
            }
            this.#x = Math.floor( x ) || 0;
            this.#y = Math.floor( y ) || 0;
            this.#target.style.transform = `translate3d(${ this.#x }px, ${ this.#y }px, 0)`;
        }

        setX( x ) {
            this.setXY( x, this.#y );
        }

        setY( y ) {
            this.setXY( this.#x, y );
        }
    }

    {
        /**
         * 扩展 HTMLElement 原型的 css 方法,设置当前元素的样式
         * @param {Object<string, string>|string} style - 表示 CSS 样式属性和值的键值对对象或要设置的 CSS 样式属性
         * @param {string} [value] - 当第一个参数为字符串时表示对应 CSS 样式属性的值
         * @return {HTMLElement} 返回当前 HTML 元素本身以便实现链式调用
         */
        HTMLElement.prototype.css = function ( style, value ) {
            if ( Judge.isObject( style ) ) {
                for ( let property in style ) {
                    this.style[ property ] = style[ property ];
                }
            } else if ( Judge.isString( style ) ) {
                this.style[ style ] = value;
            } else {
                throw Code_Error.ParameterMismatch( style, value );
            }

            return this;
        }
    }

    const Mask = ( () => {
        const MessageLayer_top_left = createElement( { className : "left" } );
        const MessageLayer_top_center = createElement( { className : "center" } );
        const MessageLayer_top_right = createElement( { className : "right" } );
        const MessageLayer_top = createElement( {
            className : "top",
            child : [
                MessageLayer_top_left,
                MessageLayer_top_center,
                MessageLayer_top_right
            ]
        } );

        const MessageLayer_center_left = createElement( { className : "left" } );
        const MessageLayer_center_center = createElement( { className : "center" } );
        const MessageLayer_center_right = createElement( { className : "right" } );
        const MessageLayer_center = createElement( {
            className : "center",
            child : [
                MessageLayer_center_left,
                MessageLayer_center_center,
                MessageLayer_center_right
            ]
        } );

        const MessageLayer_bottom_left = createElement( { className : "left" } );
        const MessageLayer_bottom_center = createElement( { className : "center" } );
        const MessageLayer_bottom_right = createElement( { className : "right" } );
        const MessageLayer_bottom = createElement( {
            className : "bottom",
            child : [
                MessageLayer_bottom_left,
                MessageLayer_bottom_center,
                MessageLayer_bottom_right
            ]
        } );

        const MessageLayer = createElement( {
            className : "message",
            child : [
                MessageLayer_top,
                MessageLayer_center,
                MessageLayer_bottom
            ]
        } );

        const ActivityLayer = createElement( { className : "activity" } );
        const MaskLayer = createElement( {
            id : "app-mask-layer",
            child : [
                ActivityLayer,
                MessageLayer
            ]
        } );

        return {
            MaskLayer,
            Activity : ActivityLayer,
            Message : {
                element : MessageLayer,
                top : {
                    left : MessageLayer_top_left,
                    center : MessageLayer_top_center,
                    right : MessageLayer_top_right
                },
                center : {
                    left : MessageLayer_center_left,
                    center : MessageLayer_center_center,
                    right : MessageLayer_center_right
                },
                bottom : {
                    left : MessageLayer_bottom_left,
                    center : MessageLayer_bottom_center,
                    right : MessageLayer_bottom_right
                }
            }
        }
    } )();

    const _previa = {
        widget : {
            flags : {
                Button : {
                    "hide" : 0x001,
                    "switch" : 0x010,
                    "close" : 0x100
                }
            }
        },
        feedback : {
            message : {
                EventLevel : {
                    error : "error",
                    warning : "warning",
                    info : "info",
                    log : "log",
                    pass : "pass"
                }
            }
        }
    };

    function init() {
        console.log( "magic-ui v" + magic_ui_version );

        document.addEventListener( 'keydown', function ( event ) {
            if ( event.key === 'Tab' ) {
                event.preventDefault();
            }
        } );

        document.body.appendChild( Mask.MaskLayer );
    }

    return {
        Mask,
        feedback : {
            message : ( obj, callback = () => {} ) => {
                if ( typeof obj === "function" ) {
                    obj( magic.importM( "magic-ui/ui/feedback/message" ) );
                    return;
                }
                const msg = magic.importM( "magic-ui/ui/feedback/message", obj );
                msg.interface[ "show" ]();
                callback( msg );
            }
        },
        vicewin : {
            activity : ( obj, callback = () => {} ) => {
                if ( typeof obj === "function" ) {
                    const activity = magic.importM( "magic-ui/ui/vicewin/activity" );
                    Mask.Activity.appendChild( activity );
                    obj( activity );
                    return activity;
                }
                const activity = magic.importM( "magic-ui/ui/vicewin/activity", obj );
                Mask.Activity.appendChild( activity );
                callback( activity );
                return activity;
            }
//            dialog : ( obj, callback = () => {} ) => {
//                if ( typeof obj === "function" ) {
//                    return magic.importM( "magic-ui/ui/vicewin/dialog", null ).init( _m => {
//                        Mask.Activity.appendChild( _m.element );
//                        obj( _m );
//                    } );
//                }
//                return magic.importM( "magic-ui/ui/vicewin/dialog", obj ).init( _m => {
//                    Mask.Activity.appendChild( _m.element );
//                    callback( _m );
//                } );
//            }
        },
        forEnd,
        traverseObject,
        Judge,
        Code_Error,
        createElement,
        JsonToElement,
        Place,
        RangeCorrection,
        eventTrigger,
        ElementToJson,
        Draggable,
        VitalEvent,
        init,
        previa : _previa
    }
} )();
