<template>
	<div #id="container">
		<div #id="box" class="box">
			<span #id="icon" class="icon mdi mdi-alert-circle-outline"></span>
			<p #id="text" class="text"></p>
			<span #id="close" @click="close_click" class="close mdi mdi-window-close"></span>
		</div>
	</div>
</template>

<global>
	const { EventLevel } = MagicUi.previa.feedback.message;

	const {
		$container,
		$box,
		$icon,
		$text,
		$close
	} = $id();

	let _show_time_id = null;

	const UiData = magic_define_ui_data( {
		id : "",
		eventLevel : EventLevel.info,
		text : "hello world",
		endTime : 3000,
		place : "top-center",
		size : "4",
		max : 3,
		closeButton : false
	} );

	function _end() {
		$container.removeAttribute( "m-run" );
		$box.setAttribute( "m-end", "" );
		$box.addEventListener( "animationend", () => {
			$container.remove();
		} );
	}
</global>

<event>
	close_click = () => {
		clearTimeout( _show_time_id );
		_end();
	}
</event>

<interface once>
	setID = ( id = UiData.id ) => {
		if ( id.length < 1 ) id = UiData.text;
		UiData.id = id;
		$container.setAttribute( "m-message-id", UiData.id );
	};

	setMax = ( max = UiData.max ) => {
		UiData.max = max;
	};

	setText = ( text = UiData.text ) => {
		UiData.text = text;
		$text.textContent = text;
	};

	setEndTime = ( time = UiData.endTime ) => {
		UiData.endTime = time;
	};

	setFontSize = ( size = UiData.size ) => {
		UiData.size = size;
		$container.setAttribute( "m-size", UiData.size );
	};

	setEventLevel = ( level = UiData.eventLevel ) => {
		UiData.eventLevel = level;
		$container.setAttribute( "m-event-level", UiData.eventLevel );
	};

	setCloseButton = ( bool = UiData.closeButton ) => {
		UiData.closeButton = bool;
		$container.setAttribute( "m-close-button", UiData.closeButton );
	};
</interface>

<interface>
	show = ( place = UiData.place ) => {
		const places = place.split( "-" );
		if ( places.length <= 1 ) return;
		const r = places.at( 0 );
		const c = places.at( 1 );

		let resultContainer;
		let result;

		if ( r === "top" )
			resultContainer = MagicUi.Mask.Message.top;
		else if ( r === "center" )
			resultContainer = MagicUi.Mask.Message.center;
		else if ( r === "bottom" )
			resultContainer = MagicUi.Mask.Message.bottom;

		if ( c === "left" ) result = resultContainer.left;
		else if ( c === "center" ) result = resultContainer.center;
		else if ( c === "right" ) result = resultContainer.right;

		const olds = MagicUi.Mask.Message.element.querySelectorAll( `*[m-message-id="${ UiData.id }"][m-run]` );
		if ( olds.length >= UiData.max ) {
			olds.item( 0 ).interface[ "close" ]();
		}
		$container.setAttribute( "m-run", "" );
		result.appendChild( $container );

		_show_time_id = setTimeout( () => { _end() }, UiData.endTime );
	}

	close = () => {
		clearTimeout( _show_time_id );
		_end();
	}
</interface>

<css scope="#id:container" default-theme>
	& {
		animation: m-scale-bounce .5s;

		& > .box[m-end] {
			animation: m-jelly-scale 1s reverse;
		}

		&[m-event-level] > .box {
			border-radius: 6px;
			box-shadow: 0 0 3px #d8d8d8;
			border: 1.5px solid #a6a6a6;

			color: #fff;

			& > .close {
				border-radius: 90px;

				color: #333;

				&:hover {
					color: #ffffff;
					background-color: rgba(0, 0, 0, 0.1);
				}
			}

			& > .icon {
				font-size: 20px;
			}
		}

		&[m-event-level="error"] > .box {
			background-color: #ff0000;

			& > .icon::before {
				content: "\F05D6";
			}
		}

		&[m-event-level="warning"] > .box {
			background-color: #ffae00;

			& > .icon::before {
				content: "\F002A";
			}
		}

		&[m-event-level="info"] > .box {
			background-color: #000000;

			& > .icon::before {
				content: "\F02FD";
			}
		}

		&[m-event-level="log"] > .box {
			background-color: #00ffff;

			& > .icon::before {
				content: "\F1085";
			}
		}

		&[m-event-level="pass"] > .box {
			background-color: #00d93a;

			& > .icon::before {
				content: "\0F0133";
			}
		}
	}
</css>

<css scope="#id:container">
	& {
		display: flex;
		align-items: center;
		justify-content: center;

		box-sizing: border-box;

		width: max-content;
		max-width: 95%;

		padding: 5px;

		&[m-size] {
			&[m-size="1"] {
				font-size: xx-small;
			}

			&[m-size="2"] {
				font-size: x-small;
			}

			&[m-size="3"] {
				font-size: small;
			}

			&[m-size="4"] {
				font-size: medium;
			}

			&[m-size="5"] {
				font-size: large;
			}

			&[m-size="6"] {
				font-size: x-large;
			}

			&[m-size="7"] {
				font-size: xx-large;
			}

			&[m-size="8"] {
				font-size: xxx-large;
			}
		}

		& > .box {
			box-sizing: border-box;

			padding: 4px 8px 4px 8px;

			display: inline-flex;
			align-items: center;
			justify-content: center;
			gap: 5px;

			& > .text {
				margin: 0;
			}

			& > .close {
				align-items: center;
				justify-content: center;

				width: 22px;
				height: 22px;

				-webkit-app-region: no-drag;

				pointer-events: all;

				font-size: 1rem;
			}
		}

		&[m-close-button="true"] > .box > .close {
			display: flex;
		}

		&[m-close-button="false"] > .box > .close {
			display: none;
		}
	}
</css>