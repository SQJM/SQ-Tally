<template inline>
	<dialog #id="dialog"></dialog>
</template>

<global>
    const {
		Place,
		Judge,
		Draggable
	} = MagicUi;

	const UiData = magic_define_ui_data( {
		draggableState : true
	} );

	const {
		$dialog
	} = $id();

	let _draggable = new Draggable( $dialog, {
		target : $dialog,
		callback : () => true,
		freeMove : false
	} );

</global>

<interface once timing="render">
	setContent = ( content = $dialog.childNodes.item( 0 ) ) => {
		if ( Judge.isHTMLElement( content ) || Judge.isDocumentFragment( content ) ) {
			$dialog.childNodes.forEach( c => {
				c.remove();
			} );
			$dialog.appendChild( content );
		}
	};
</interface>

<interface>
	setDraggableCallback = ( callback = () => true ) => {
		_draggable.setCallback( callback );
	};

	setDraggable = ( element, target ) => {
		_draggable.setElement( element );
		_draggable.setTargetElement( target );
	};

	setDraggableState = ( state = UiData.draggableState ) => {
		UiData.draggableState = ( typeof state === "string" ) ? state === "true" : state;
		_draggable.setState( UiData.draggableState );
	};

	setLimit = ( limit ) => {
		_draggable.setLimit( limit );
	};

	setX = ( x ) => {
		_draggable.setX( x );
	};

	setY = ( y ) => {
		_draggable.setY( y );
	};

	setXY = ( x, y ) => {
		_draggable.setXY( x, y );
	};

	setPlace = ( place = Place.center.center ) => {
		const {
			width : W,
			height : H
		} = document.getElementById( "app" ).getBoundingClientRect();
		const {
			width : w,
			height : h
		} = $dialog.getBoundingClientRect();

		const halfW = W / 2;
		const fullWidth = W - w;
		const halfH = H / 2;
		const fullHeight = H - h;

		const positionMap = {
			[ Place.top.left ] : {
				x : 0,
				y : 0
			},
			[ Place.top.center ] : {
				x : halfW - w / 2,
				y : 0
			},
			[ Place.top.right ] : {
				x : fullWidth,
				y : 0
			},
			[ Place.center.left ] : {
				x : 0,
				y : halfH - h / 2
			},
			[ Place.center.center ] : {
				x : halfW - w / 2,
				y : halfH - h / 2
			},
			[ Place.center.right ] : {
				x : fullWidth,
				y : halfH - h / 2
			},
			[ Place.bottom.left ] : {
				x : 0,
				y : fullHeight
			},
			[ Place.bottom.center ] : {
				x : halfW - w / 2,
				y : fullHeight
			},
			[ Place.bottom.right ] : {
				x : fullWidth,
				y : fullHeight
			}
		};

		const position = positionMap[ place ] || positionMap[ Place.center.center ];

		call.interface( "setXY", position.x, position.y );
	};

	show = () => {
		$dialog.setAttribute( "open", "" );
	};

	showModal = () => {
		$dialog.showModal();
	};

	hide = () => {
		$dialog.removeAttribute( "open" );
	};

	close = () => {
		call.interface( "hide" );
		$dialog.remove();
	};
</interface>

<css scope="#id:dialog">
	& {
		pointer-events: all;

		margin: 0;
		padding: 0;

		overflow: hidden;

		position: relative;

		transform: translate3d(0, 0, 0);

		width: 100px;
		height: 100px;
	}
</css>