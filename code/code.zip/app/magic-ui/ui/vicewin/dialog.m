<import
	root="magic-ui/ui/"
>
	<module:widget>
		<title-bar/>
	</module:widget>
</import>

<template>
	<div #id="box">
		<title-bar
			#id="title-bar"
			#listen:close="_close"
			class="title-bar"
			:flags:size="1"
			:drag="false"
		/>
		<div #id="content" class="content"></div>
		<div #id="bottom" class="bottom"></div>
	</div>
</template>

<global>
	const UiData = magic_define_ui_data( {
		id : "",
		resizeOperation : false
	} );

	const {
		$box,
		$titleBar,
		$content,
		$bottom
	} = $id();

	const _act = MagicUi.vicewin.activity();

	_act

	function _close() {
		use_event( "close" );

		_act.interface[ "close" ]();
	}
</global>

<script>
    _act.interface.setDraggable( $titleBar, _act );

    _act.interface.setDraggableCallback( ( event ) => {
        if ( event.name === "start" ) {
            return !MagicUi.Judge.isElementIsSpecifiedUi( "magic-ui/ui/widget/flags", event.target.parentMNode );
        }
        return true;
    } );

    $titleBar.interface.setButton( MagicUi.previa.widget.flags.Button.close );

    magic.exportInterface( this, $titleBar, {
        setTitleText : nop
    } );

    magic.exportInterface( this, _act, {
        setX : nop,
        setY : nop,
        setXY : nop,
        show : nop,
        setLimit : nop,
        setPlace : nop,
        setDraggableState : nop,
        hide : () => {
            $box.removeAttribute( "m-modal" );
        }
    } );
</script>

<interface once>
	setID = ( id = UiData.id ) => {
		UiData.id = id;
		$box.setAttribute( "m-dialog-id", UiData.id );
	};

	setResizeOperation = ( opr = UiData.resizeOperation ) => {
		UiData.resizeOperation = opr;
		opr ? $box.setAttribute( "m-resize", opr ) : $box.removeAttribute( "m-resize" );
	};
</interface>

<interface>
	close = () => {
		m.interface.use[ "hide" ]();
		$box.remove();
	};

	showModal = () => {
		m.interface.use[ "show" ]();
		$box.setAttribute( "m-modal", "" );
	};

	setContent = ( content ) => {
		$content.appendChild( content );
	};

	isModal = () => {
		return $box.hasAttribute( "m-modal" );
	};
</interface>

<css scope="#id:box" default-theme>
	&[m-modal] {
		background-color: rgba(0, 0, 0, 0.05);
	}

	& > .activity {
		border-radius: 8px;

		& > .title-bar > .center > .title-text {
			font-weight: lighter;
		}
	}
</css>

<css scope="#id:box">
	& {
		position: fixed;
		top: 0;
		left: 0;

		width: 100%;
		height: 100%;
	}

	& > .activity {
		min-height: 30px;
		min-width: 250px;

		max-width: 100dvw;
		max-height: 100dvh;

		display: flex;
		flex-direction: column;

		& > .content {
			width: 100%;
			height: 100%;
		}
	}

	&[m-modal] {
		-webkit-app-region: no-drag;

		pointer-events: all;
	}

	&[m-resize] {
		&[m-resize="both"] > .activity {
			resize: both;
		}

		&[m-resize="vertical"] > .activity {
			resize: vertical;
		}

		&[m-resize="horizontal"] > .activity {
			resize: horizontal;
		}
	}
</css>