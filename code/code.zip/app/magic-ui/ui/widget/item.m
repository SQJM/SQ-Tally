<template inline>
	<div #id="item" m-item></div>
</template>

<global>
	const UiData = magic_define_ui_data( {
		text : null
	} );

	const {
		$item
	} = $id();
</global>

<script>
</script>

<interface once>
	setText = ( str = UiData.text ) => {
		if ( !str ) return;
		$item.textContent = str;
	}
</interface>

<interface>
	setHTML = ( h ) => {
		$item.innerHTML = h;
	}

	getText = () => {
		return $item.textContent;
	}
</interface>

<css scope="">
</css>