<template>
	<div #id="flags" @click="click" class="flags">
		<span #id="hide" class="hide mdi-set">&#xF0374;</span>
		<span #id="switch" class="switch mdi-set">&#xF14FC;</span>
		<span #id="close" class="close mdi-set">&#xF0156;</span>
	</div>
</template>

<global>
	const { Button } = MagicUi.previa.widget.flags;

	const UiData = magic_define_ui_data( {
		switchState : false,
		size : "1",
		button : Button.hide | Button.close | Button.switch
	} );

	const {
		$flags,
		$hide,
		$close,
		$switch
	} = $id();
</global>

<event>
	click = ( event ) => {
		const target = event.target;

		if ( target === $hide ) {
			use_event( "hide" );
		} else if ( target === $switch ) {
			UiData.switchState = !UiData.switchState;
			call.interface( "setSwitchState" );
			use_event( "switch", UiData.switchState );
		} else if ( target === $close ) {
			use_event( "close" );
		}
	}
</event>

<interface once>
	setSwitchState = ( state = UiData.switchState ) => {
		UiData.switchState = state;

		if ( UiData.switchState ) {
			$switch.innerHTML = "&#xF0555;";
			$switch.classList.add( "m-rotate-90" );
		} else {
			$switch.innerHTML = "&#xF14FC;";
			$switch.classList.remove( "m-rotate-90" );
		}
	};

	setFlagsSize = ( size = UiData.size ) => {
		UiData.size = size;
		$flags.setAttribute( "m-size", UiData.size );
	};

	setButton = ( button = UiData.button ) => {
		UiData.button = button;

		$hide.setAttribute( "show", ( UiData.button & Button.hide ) !== 0 );
		$switch.setAttribute( "show", ( UiData.button & Button.switch ) !== 0 );
		$close.setAttribute( "show", ( UiData.button & Button.close ) !== 0 );
	};
</interface>

<css scope="#id:flags" default-theme>
	& {
		span {
			transition: background-color .2s;

			cursor: pointer;

			&:hover {
				background-color: rgba(255, 255, 255, 0.8);
			}

			&.close:hover {
				background-color: rgba(255, 0, 0, 0.8);
				color: #fff;
			}
		}
	}
</css>

<css scope="#id:flags">
	& {
		width: 100%;
		height: 100%;

		user-select: none;

		display: flex;
		align-items: center;
		justify-content: flex-end;

		& > span {
			flex: 0 auto;

			display: flex;
			align-items: center;
			justify-content: center;

			-webkit-app-region: no-drag;

			&[show="false"] {
				display: none;
			}
		}
	}

	&[m-size] {
		&[m-size="1"] {
			max-width: 90px;

			& > span {
				width: 30px;
				height: 30px;

				font-size: 1.2rem;
			}
		}

		&[m-size="2"] {
			max-width: 120px;

			& > span {
				width: 40px;
				height: 40px;

				font-size: 1.3rem;
			}
		}

		&[m-size="3"] {
			max-width: 150px;

			& > span {
				width: 50px;
				height: 50px;

				font-size: 1.4rem;
			}
		}

		&[m-size="4"] {
			max-width: 180px;

			& > span {
				width: 60px;
				height: 60px;

				font-size: 1.5rem;
			}
		}
	}
</css>