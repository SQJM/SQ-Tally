<import
	root="magic-ui/ui"
>
	<module:widget>
		<flags/>
	</module:widget>
</import>

<template>
	<div #id="bar">
		<img #id="icon" class="icon"/>
		<div #id="center" class="center">
			<h1 #id="title-text" class="title-text"></h1>
			<div #id="container" class="container"></div>
		</div>
		<flags #id="flags"
			   #listen:close="listen_close"
			   #listen:hide="listen_hide"
			   #listen:switch="listen_switch"
		/>
	</div>
</template>

<global>
	const UiData = magic_define_ui_data( {
		headline : {
			text : "",
			color : ""
		},
		size : "normal",
		drag : true,
		icon : {
			src : ""
		}
	} );

	const {
		$bar,
		$icon,
		$center,
		$titleText,
		$container,
		$flags
	} = $id();

	function listen_hide( event ) {
		use_event( "hide", event );
	}

	function listen_switch( event ) {
		use_event( "switch", event );
	}

	function listen_close( event ) {
		use_event( "close", event );
	}
</global>

<interface once>
	setSize = ( size = UiData.size ) => {
		UiData.size = size;
		$bar.setAttribute( `m-${ size }`, "" );
	};

	setDrag = ( drag = UiData.drag ) => {
		UiData.drag = drag;
		drag ? $bar.setAttribute( "m-drag", "" ) : $bar.removeAttribute( "m-drag" );
	};

	setIconSrc = ( src = UiData.icon.src ) => {
		UiData.icon.src = src;
		src.trim().length > 0 ? $icon.setAttribute( "src", src ) : $icon.setAttribute( "src", "no-src" );
	};

	setTitleText = ( text = UiData.headline.text ) => {
		UiData.headline.text = text;
		$titleText.textContent = text;
	};

	setTitleTextColor = ( color = UiData.headline.color ) => {
		UiData.headline.color = color;
		$titleText.style.color = color;
	};
</interface>

<css scope="#id:bar" default-theme>
	& {
		background-color: #e5fafb;
		backdrop-filter: blur(10px);

		box-shadow: 0 0 3px #d8d8d8;
	}
</css>

<css scope="#id:bar">
	* {
		margin: 0;
		padding: 0;
	}

	&[m-drag] {
		-webkit-app-region: drag;
	}

	&[m-normal] {
		height: 30px;
		min-height: 30px;
		width: 100%;
	}

	& {
		box-sizing: border-box;

		display: flex;
		align-items: center;

		padding-left: 10px;

		gap: 10px;
	}

	& > .icon {
		flex: 0 auto;

		height: 35px;
		width: 35px;

		pointer-events: none;

		display: flex;

		&[src="no-src"] {
			display: none;
		}
	}

	& > .center {
		overflow: hidden;

		white-space: nowrap;
		text-overflow: ellipsis;

		width: 100%;

		display: flex;
		align-items: center;
		gap: 10px;

		.title-text {
			width: 100%;

			font-size: 1.1rem;
			text-wrap: nowrap;

			overflow: hidden;

			white-space: nowrap;
			text-overflow: ellipsis;
		}

		.container {
			-webkit-app-region: no-drag;
		}
	}

	& > .flags {
		flex: 0 auto;
	}
</css>