<template>
	<div #id="box">
		<input
			#id="input"
			@compositionstart="compositionstart"
			@compositionend="compositionend"
			@input="input"
			class="input">
	</div>
</template>

<global>
	const UiData = magic_define_ui_data( {
		placeholder : "",
		type : "text",
		max : null,
		min : null,
		maxlength : null,
		minlength : null,
		lazyChangeTime : 50,
		value : "",
		readonly : false
	} );

	let _time_id_lazy_change = null,
		_is_composing = false;

	const {
		$input
	} = $id();

	const ExamineSizeLimit = ( value ) => {
		const length = ( `${ value }` ).length;
		const size = parseInt( value );

		const max = parseInt( UiData.max );
		const min = parseInt( UiData.min );

		const result = {
			max : true,
			min : true
		};

		if ( UiData.type === "text" ) {
			( length > max ) && ( result.max = false );
			( length < min ) && ( result.min = false );
		} else if ( UiData.type === "number" ) {
			( size > max ) && ( result.max = false );
			( size < min ) && ( result.min = false );
		}
		return result;
	};
</global>

<script>
    const InputHead = () => {
        const value = $input.value;
        const Limit = ExamineSizeLimit( value );

        const event = {
            value : value,
            limit : Limit
        };

        if ( !Limit.max || !Limit.min ) return use_event( "limitError", event );

        use_event( "input", event );
        clearTimeout( _time_id_lazy_change );

        UiData.value = value;

        use_event( "change", event );
        _time_id_lazy_change = setTimeout( () => {
            use_event( "lazyChange", event );
        }, UiData.lazyChangeTime );
    };

    if ( UiData.maxlength )
        $input.setAttribute( "maxlength", UiData.maxlength );
    if ( UiData.minlength )
        $input.setAttribute( "minlength", UiData.minlength );
</script>

<event>
	compositionstart = () => {
		_is_composing = true;
	}

	compositionend = () => {
		_is_composing = false;
		InputHead();
	}

	input = () => {
		if ( _is_composing ) return;
		InputHead();
	};
</event>

<interface once>
	setReadonly = ( bool = UiData.readonly ) => {
		UiData.readonly = bool;
		bool && $input.setAttribute( "readonly", "" );
	};

	setPlaceholder = ( placeholder = UiData.placeholder ) => {
		UiData.placeholder = placeholder;
		$input.setAttribute( "placeholder", UiData.placeholder );
	};

	setMax = ( max = UiData.max ) => {
		if ( !max ) return;
		UiData.max = max;
	};

	setMin = ( min = UiData.min ) => {
		if ( !min ) return;
		UiData.min = min;
	};

	setValue = ( value = UiData.value ) => {
		UiData.value = value;

		if ( typeof UiData.value === "number" ) {
			$input.value = parseInt( value );
		} else {
			$input.value = UiData.value;
		}
	};
</interface>

<interface>
	getValue = () => {
		return UiData.value;
	};

	setLazyChangeTime = ( lazyChangeTime ) => {
		UiData.lazyChangeTime = lazyChangeTime;
	};

	appValue = ( value = UiData.value ) => {
		UiData.value += value;

		if ( typeof UiData.value === "number" ) {
			$input.value += parseInt( value );
		} else {
			$input.value += UiData.value;
		}
	};
</interface>

<css scope="#id:box" default-theme>
	& {
		border: 1.5px solid;
		border-radius: 4px;

		& > .input {
			border: none;
			border-radius: 4px;

			padding: 0;
		}
	}
</css>

<css scope="#id:box">
	& {
		box-sizing: border-box;

		display: inline-flex;
		align-items: center;

		width: 240px;
		height: 32px;
	}

	& > .input {
		display: inline-block;

		padding: 4px;

		width: 100%;
		height: 100%;

		outline: none;
	}
</css>