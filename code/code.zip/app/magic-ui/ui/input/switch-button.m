<template>
	<input @click="click" #id="switch" size="2" type="checkbox"/>
</template>

<script start>
	const UiData = magic_define_ui_data( {
        state : false
    } );

    let _freeze = false,
        _state = false;

    const {
        $switch
    } = $id();
</script>

<event>
	click = ( event ) => {
		if ( _freeze ) {
			event.preventDefault();
			return;
		}
		_state = !_state;

		call.interface( "setState", _state );

		use_event( "switch", _state );
	}
</event>

<interface once>
	setState = ( bool = UiData.state ) => {
		_state = !!bool;
		$switch.checked = _state;
	};
</interface>

<interface>
	setFreeze = ( bool ) => {
		_freeze = bool;
	};

	getState = () => {
		return _state;
	};

	trigger = () => {
		$switch.click();
	};
</interface>

<css scope="#id:switch" default-theme>
	& {
		cursor: pointer;

		&::before {
			background-color: #fff;
			box-shadow: inset 0 0 2px #6b6b6b80;
			border-radius: 90px;
		}

		&::after {
			background-color: #ffffff;
			box-shadow: 1px 1px 2px #3f3f3f4d;
			border-radius: 90px;
		}

		&:checked::after {
			box-shadow: 0 0 3px #888888;
		}

		&:checked::before {
			background-color: #b5e4ff;
		}
	}
</css>

<css scope="#id:switch">
	& {
		position: relative;
		display: flex;
		width: 40px;
		height: 20px;

		margin: 2px;

		&::before {
			transition: all .25s;
			content: " ";
			width: calc(100% + 1px);
			height: calc(100% + 1px);
			position: absolute;
			top: -0.7px;
		}

		&::after {
			transition: all .2s;
			content: " ";
			width: calc(50% + 1px);
			height: calc(100% + 1px);
			position: absolute;
			top: -0.7px;
		}

		&:checked::after {
			transform: translate3d(100%, 0, 0px);
		}

		&.min {
			height: 15px;

			&::after {
				width: 50%;
				height: 125%;
				transform: translate3d(0, -11%, 0px);
			}

			&:checked::after {
				transform: translate3d(100%, -11%, 0px);
			}
		}

		&[size="2"] {
			width: 52.5px;
			height: 25px;

			&.w-min {
				height: 20px;
			}
		}
	}
</css>