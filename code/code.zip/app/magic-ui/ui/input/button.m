<template>
	<button
		#id="button"
		@click="click"
		class="button"></button>
</template>

<global>
	const UiData = magic_define_ui_data( {
		text : "",
		html : null,
		font : {
			icon : null,
			size : "1rem"
		}
	} );

	let _freeze = false;

	const {
		$button
	} = $id();
</global>

<event>
	click = ( event ) => {
		if ( _freeze ) return;
		use_event( "click", event );
	}
</event>

<interface once>
	setFontSize = ( size = UiData.font.size ) => {
		UiData.font.size = size;
		$button.style.fontSize = UiData.font.size;
	};

	setText = ( text = UiData.text ) => {
		UiData.text = text;
		$button.textContent = UiData.text;
	};

	setHtml = ( html = UiData.html ) => {
		if ( html ) {
			UiData.html = html;
			$button.innerHTML = UiData.html;
		}
	};

	setFontIcon = ( icon = UiData.font.icon, remove = false ) => {
		if ( icon && !remove ) {
			UiData.font.icon = icon;
			$button.classList.add( "mdi" );
			$button.classList.add( UiData.font.icon );
		} else if ( icon && remove ) {
			UiData.font.icon = null;
			$button.classList.remove( "mdi" );
			$button.classList.remove( icon );
		}
	};
</interface>

<interface>
	setFreeze = ( bool ) => {
		_freeze = bool;
	};
</interface>

<css scope="#id:button" default-theme>
	& {
		text-wrap: nowrap;
		padding: 2px 4px 2px 4px;
		background-color: #f0f9ff;
		border-radius: 5px;
		border: 1.5px solid #e0e8ed;
	}

	&:hover {
		background-color: #e5edf4;
	}

	&:active {
		background-color: #f2faff;
	}
</css>