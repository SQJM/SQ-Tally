<template inline>
	<div #id="list" @mousedown="mousedown" class="list-view"></div>
</template>

<global>
	const UiData = magic_define_ui_data( {
		direction : "column",
		warp : false,
		item : {
			gap : ""
		},
		select : 0,
		def_select : true,
		multiple : false,
		repetition : false
	} );

	const {
		$list
	} = $id();

	function _getTargetItem( element ) {
		if ( !$list.contains( element ) || element === $list ) return null;
		if ( element.parentNode === $list ) return element;
		else return _getTargetItem( element.parentNode );
	}

	function _selectItem( item, target ) {
		if ( !$list.contains( item ) ) return false;

		if ( UiData.multiple ) {
			if ( _isSelect( item ) )
				_removeSelectItem( item );
			else
				item.setAttribute( "m-select", "" );
		} else {
			_getAllItem().forEach( im => {
				if ( _isSelect( im ) ) _removeSelectItem( im );
			} );
			item.setAttribute( "m-select", "" );
		}
		use_event( "select", item, target );
	}

	function _selectItemStopBubbling( item, target ) {
		if ( !$list.contains( item ) ) return false;

		use_event( "select_stop_bubbling", item, target );
	}

	function _removeSelectItem( item ) {
		if ( !$list.contains( item ) ) return false;
		item.removeAttribute( "m-select", "" );
	}

	function _getAllItem() {
		return $list.childNodes;
	}

	function _isSelect( item ) {
		return item.hasAttribute( "m-select" );
	}
</global>

<event>
	mousedown = ( event ) => {
		const target = event.target;
		const item = _getTargetItem( target );

		if ( target.hasAttribute( "m-stop-bubbling" ) ) return _selectItemStopBubbling( item, target );

		if ( target === $list || !$list.contains( target ) || ( !UiData.repetition && ( _isSelect( item ) ) ) ) return;

		_selectItem( item, target );
	}
</event>

<interface once timing="render">
	selectItem = ( item = UiData.select ) => {
		if ( UiData.def_select === "false" ) {
			UiData.def_select = true;
			return;
		}
		if ( typeof item === "number" ) {
			item = _getAllItem().item( item );
		}
		if ( item instanceof HTMLElement ) {
			return _selectItem( item );
		}
	}
</interface>

<interface once>
	setMultiple = ( multiple = UiData.multiple ) => {
		if ( typeof multiple === "string" )
			UiData.multiple = multiple === "true";
		else
			UiData.multiple = !!multiple;
	};

	setDirection = ( direction = UiData.direction ) => {
		UiData.direction = direction;

		$list.setAttribute( `m-${ direction }`, "" );
	};

	setWarp = ( warp = UiData.warp ) => {
		UiData.warp = warp;

		if ( warp )
			$list.setAttribute( "m-warp", "" );
		else
			$list.removeAttribute( "m-warp" );
	};

	setItemGap = ( gap = UiData.item.gap ) => {
		UiData.item.gap = gap;

		$list.style.gap = gap;
	};
</interface>

<interface>
	_render = () => {
		//console.log( "渲染结束", $list.childNodes )
	}

	length = () => {
		return _getAllItem().length;
	}

	getAll = () => {
		return _getAllItem();
	}

	getSelect = () => {
		const r = call.interface( "getSelectAll" );
		if ( UiData.multiple ) return r;
		return r[ 0 ];
	}

	getSelectAll = () => {
		return Array.from( _getAllItem() ).filter( e => _isSelect( e ) );
	}

	clear = () => {
		$list.innerHTML = null;
	}

	removeAllSelect = () => {
		_getAllItem().forEach( im => _removeSelectItem( im ) );
	}
</interface>

<css scope="#id:list" default-theme>
	& > *[m-item] {
		padding: 4px;
		background-color: rgb(255, 255, 255);

		cursor: pointer;

		&:hover {
			background-color: rgba(0, 0, 0, 0.1);
		}

		&[m-select] {
			background-color: rgba(0, 0, 0, 0.2);
		}

		&[disabled]:hover {
			filter: grayscale(100%);
			cursor: no-drop;
		}
	}
</css>

<css scope="#id:list">
	& {
		&[m-warp] {
			flex-wrap: wrap;
		}

		&[m-row] {
			flex-direction: row;
		}

		&[m-column] {
			flex-direction: column;
		}

		&[m-row][m-reverse] {
			flex-direction: row-reverse;
		}

		&[m-column][m-reverse] {
			flex-direction: column-reverse;
		}

		& {
			display: flex;

			& > *[m-item] {
				&[m-hide] {
					display: none !important;
				}
			}
		}
	}
</css>